import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import odeint
from scipy.optimize import root, minimize, root_scalar, minimize_scalar

def potencial(x,y):
    return 0.5*x**2+0.5*(y**2)+(x**2)*y-(y**3)/3

xi = np.linspace(-1,1,200)
yi = np.linspace(-1,1,200)
xx,yy = np.meshgrid(xi,yi)
slika_potenciala = potencial(xx,yy)
plt.figure(0)
plt.contour(xx,yy,slika_potenciala,levels=12)
plt.contourf(xx,yy,slika_potenciala,levels=12,alpha=0.8)
plt.colorbar()
plt.xlabel('x')
plt.ylabel('y')
plt.savefig("potencial.pdf", bbox_inches="tight")


def fun(y):
    return (1/6 -0.5*y**2 +1/3 *y**3)/(0.5+y)

xi = np.linspace(-1.5,1.5,200)
print(xi)
yi = np.linspace(-1.5,1.5,200)
print(yi)
X=np.sqrt(fun(yi))

xx,yy = np.meshgrid(xi,yi)
slika_potenciala = potencial(xx,yy)

plt.figure(1)
plt.contour(xx,yy,slika_potenciala, [0,1/10,1/8,1/6,1/5])
plt.colorbar()
plt.contourf(xx,yy,slika_potenciala,levels=12,alpha=0.8)
plt.colorbar()
plt.xlabel('x')
plt.ylabel('y')
plt.savefig("potencial_1.pdf", bbox_inches="tight")
plt.show()

