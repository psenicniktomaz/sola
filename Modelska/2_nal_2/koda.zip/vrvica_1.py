import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import ode


######## initial function
def f(t,y,beta): # x,y,alpha,F respectively
    return [np.cos(y[2]),np.sin(y[2]),
            (np.cos(y[2])+beta*y[0]*np.sin(y[2]))/y[3],
            np.sin(y[2])-beta*y[0]*np.cos(y[2])]



###### some initial conditions to start with

P0=[0,0,-1.5707963865389782, 0.8999999987323029] # inittial conditions
s_i=0 # initial s=0
s_f=1 # final s=1
ds=0.001 # step of integration

r = ode(f).set_integrator("dopri5")
r.set_initial_value(P0, s_i).set_f_params(4)

X = [P0[0]]
Y = [P0[1]]
alpha = [P0[2]]
F = [P0[3]]
s = [0]

while r.successful() and r.t < s_f:
    r.integrate(r.t + ds)
    X.append(r.y[0])
    Y.append(r.y[1])
    alpha.append(r.y[2])
    F.append(r.y[3])
    s.append(r.t)

plt.figure(0)
plt.plot(X,Y)
plt.show()