import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import odeint
from scipy.optimize import root, minimize, root_scalar, minimize_scalar


def najdi_periorbite(H, guess=(0,1.5)):
    """Sprejme energijo H, **kwargs: guess=(y0,alfa0)
    """
    def poincare_kvadrant(trajektorija):
        x = trajektorija.x
        y = trajektorija.y
        v = trajektorija.v
        poincare_v = []
        poincare_y = []
        for ((index_1, i), (index_2 , j) ) in zip(enumerate(x[:-1]), enumerate(x[1:])):
            if np.sign(i) == 0:
                poincare_v.append(v[index_1])
                poincare_y.append(y[index_1])
                continue
            elif np.sign(j) == 0:
                poincare_v.append(v[index_2])
                poincare_y.append(y[index_2])
                continue
            elif np.sign(i) != np.sign(j):
                x1,y1,v1 = i, y[index_1], v[index_1]
                x2,y2,v2 = j, y[index_2], v[index_2]
                k = x2-x1
                t = x1/k
                py = (y2-y1)*t+y1
                pv = (v2-y1)*t+v1
                if py >= 0 and pv >= 0:
                    poincare_y.append(py)
                    poincare_v.append(pv)
        from collections import namedtuple
        Rezultat = namedtuple("Poincarejev_presek", ["y","v"])
        return Rezultat(np.array([poincare_y]), np.array([poincare_v]))
    def povrsina(arej):
        y,alfa = arej
        traj = trajektorija(y=y,alfa=alfa, ND=1000, TS=0.1, H=H)
        presek = poincare_kvadrant(traj)
        return np.var(presek.y)*np.var(presek.v)
    def najdi_maximalni_dovoljeni_y(H):
        def funk(y):
            return 2*H-y**2+2/3*y**3
        return root_scalar(funk, x0=0,x1=1).root
    maksy = najdi_maximalni_dovoljeni_y(H)
    return minimize(povrsina, x0=guess, bounds=((0,maksy),(None, None)),method="CG").x


def trajektorija(y=0, alfa=np.pi / 4, H=0.1, ND=1000, TS=0.1):
    from collections import namedtuple
    rezultat = namedtuple("Rezultat", ["x", "y", "u", "v", "par"])
    """Sprejme y,alfa,H=0.01,
    vrne [koordinate_x, koordinate_y]."""
    omegakvadrat = 2 * H - y ** 2 + 2 / 3 * y ** 3
    assert omegakvadrat > 0, "Zvečaj H ali zmanjšaj y"
    w = np.sqrt(omegakvadrat)
    u = w * np.cos(alfa)
    v = w * np.sin(alfa)
    INPUT = np.array([0, y, u, v])  # [x0,y0,u0,v0]

    # ND = 1000 #Čas opazovanja
    def diff_eqs(INP, t):
        '''The main set of equations'''
        Y = np.zeros(4)
        x, y, u, v = INP
        Y[0] = u
        Y[1] = v
        Y[2] = -x - 2 * x * y
        Y[3] = -y - x ** 2 + y ** 2
        return Y  # For odeint

    t_start = 0.0;
    t_end = ND;
    t_inc = TS
    t_range = np.arange(t_start, t_end + t_inc, t_inc)
    RES = odeint(diff_eqs, INPUT, t_range)
    xi = RES[:, 0]
    yi = RES[:, 1]
    from collections import namedtuple
    rezultat = namedtuple("Rezultat", ["x", "y", "u", "v", "slovar_parametrov"])
    return rezultat(RES[:, 0], RES[:, 1], RES[:, 2], RES[:, 3], {"y": y, "alfa": alfa, "H": H, "ND": ND, "TS": TS})

y,alfa=najdi_periorbite(0.05, guess=(-0.2,1.57))
print(y,alfa)