import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import odeint
from scipy.optimize import root, minimize, root_scalar, minimize_scalar

def potential(x, y):
    return 0.5 * x ** 2 + 0.5 * (y ** 2) + (x ** 2) * y - (y ** 3) / 3

def trajektorija(y, alpha , t_end):
    T = H- potential(0,y)
    assert T > 0, "kinetična energija je negativna, povečaj H"
    v=np.sin(alpha)*np.sqrt(2*T)
    u=np.cos(alpha)*np.sqrt(2*T)
    INPUT = np.array([0, y, u, v])  # [x0,y0,u0,v0]

    def diff_eqs(INP, t):
        '''The main set of equations'''
        Y = np.zeros(4)
        x, y, u, v = INP
        Y[0] = u
        Y[1] = v
        Y[2] = -x - 2 * x * y
        Y[3] = -y - x ** 2 + y ** 2
        return Y  # For odeint

    t_start = 0.0
    t_range = np.arange(t_start, t_end + dt/2 , dt)
    RES = odeint(diff_eqs, INPUT, t_range)
    x = RES[:, 0]
    y = RES[:, 1]
    u = RES[:, 2]
    v = RES[:, 3]
    return x,y,u,v

def streljaj(arej): ##arej=[y,alpha,t_end]
    x=arej[0]
    x=0
    y_0=arej[1]
    y=y_0
    alpha=arej[2]
    #t_end=arej[3]
    print('začetni parametri:',x,y,alpha,t_end)
    ### finding max_y and min_y to have movement in the region E<1/6
    def maks_y(Y):
        return H-(Y**2)/2 + (Y**3)/3
    y_max=root(maks_y,0.001).x[0]
    y_min=root(maks_y,0.001).x[0]
    ### just making sure the kinetic energy is not to big
    if y > y_max:
        y=y%y_max
    elif y < y_min:
        y=y%y_min
    print(y)
    T = H- potential(0,y)
    print(T)
    assert T > 0, "kinetična energija je negativna, povečaj H ali zmanjšaj y"
    if np.abs(alpha)> 2*np.pi:
        if alpha >0:
            alpha=alpha%(2*np.pi)
        else:
            alpha=-(-alpha%(2*np.pi))
    print('vmesni parametri:',x,y,alpha,t_end)
    v=np.sin(alpha)*np.sqrt(2*T)
    u=np.cos(alpha)*np.sqrt(2*T)
    INPUT = np.array([0, y, u, v])  # [x0,y0,u0,v0]

    def diff_eqs(INP, t):
        '''The main set of equations'''
        Y = np.zeros(4)
        x, y, u, v = INP
        Y[0] = u
        Y[1] = v
        Y[2] = -x - 2 * x * y
        Y[3] = -y - x ** 2 + y ** 2
        return Y  # For odeint

    t_start = 0.0
    t_range = np.arange(t_start, t_end + dt/2 , dt)
    RES = odeint(diff_eqs, INPUT, t_range)
    x = RES[:, 0]
    y = RES[:, 1]
    u = RES[:, 2]
    v = RES[:, 3]
    print('končni parametri:',x[-1],y[-1],np.arccos(u[-1]/np.sqrt((u[-1]**2)*(v[-1]**2))),t_end)
    return [x[-1],y_0-y[-1],alpha-np.arccos(u[-1]/np.sqrt((u[-1]**2)*(v[-1]**2)))]


def najdi(streljaj):
    return root(streljaj,[0,y_0,alpha],options={'xtol': 1e-6}).x # [0,y_0,alpha,t_end] is initial guess

###### some parameters for trajectory
x_0=0
y_0=0.099
alpha=2
H=0.01
dt=0.001
t_end=40

X= najdi(streljaj)
