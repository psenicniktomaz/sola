import numpy as np
import matplotlib.pyplot as plt

from scipy.integrate import odeint
from scipy.optimize import root


#plt.style.use("ggplot")
#plt.rcParams['font.family'] = "serif"
#plt.rc('text', usetex=True)
#np.set_printoptions(precision=4)

y_f = 0.8
TS = 1e-6


def streljaj(arej, *args):
    """Sprejme [alfa0, F0] in args=(beta).
    Vrne [x_final, y_final-y_f]."""
    alfa0, F0 = arej
    x0 = 0
    y0 = 0
    INPUT = np.array([x0, y0, alfa0, F0])

    ND = 1  # Čas opazovanja

    def diff_eqs(INP, t):
        '''The main set of equations'''
        Y = np.zeros(4)
        x, y, alfa, F = INP
        Y[0] = np.cos(alfa)
        Y[1] = np.sin(alfa)
        Y[2] = (beta * x * np.sin(alfa) + np.cos(alfa)) / F
        Y[3] = -beta * x * np.cos(alfa) + np.sin(alfa)
        return Y  # For odeint

    t_start = 0.0;
    t_end = ND;
    t_inc = TS
    t_range = np.arange(t_start, t_end + t_inc, t_inc)
    RES = odeint(diff_eqs, INPUT, t_range)
    x_final = RES[-1, 0]
    y_final = RES[-1, 1]
    print(alfa0,F0)
    return [x_final, y_final - y_f]


def najdi_alfa_F(streljaj, beta):
    """Vrne [alfa_0, F_0] za dano beta."""
    return root(streljaj, [-0.7, 0.1], args=(beta),options={'xtol': 1e-6}).x


def streljaj_trajektorija(arej, *args):
    """Sprejme [alfa0, F0] in args=(beta).
    Vrne obliko [xi, yi]."""
    alfa0, F0 = arej
    x0 = 0
    y0 = 0
    INPUT = np.array([x0, y0, alfa0, F0])

    ND = 1  # Čas opazovanja

    def diff_eqs(INP, t):
        '''The main set of equations'''
        Y = np.zeros(4)
        x, y, alfa, F = INP
        Y[0] = np.cos(alfa)
        Y[1] = np.sin(alfa)
        Y[2] = (beta * x * np.sin(alfa) + np.cos(alfa)) / F
        Y[3] = -beta * x * np.cos(alfa) + np.sin(alfa)
        return Y  # For odeint

    t_start = 0.0;
    t_end = ND;
    t_inc = TS
    t_range = np.arange(t_start, t_end + t_inc, t_inc)
    RES = odeint(diff_eqs, INPUT, t_range)
    xi = RES[:, 0]
    yi = RES[:, 1]
    return [xi, yi]


beta=3
alfa0, F0 = najdi_alfa_F(streljaj, beta)
print(alfa0,F0)
xi, yi = streljaj_trajektorija([alfa0, F0], beta)
plt.figure(0)
plt.plot(xi, yi -y_f, label=r"$\beta=$%s" %str(beta))
#plt.show()

