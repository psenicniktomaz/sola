import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import odeint
from scipy.optimize import root



y_f = 0.8
ds = 1e-6
def streljaj(initial_guess):
    """Sprejme [alfa0, F0] in args=(beta).
    Vrne [x_final, y_final-y_f]."""
    alfa0, F0 = initial_guess
    x0 = 0
    y0 = 0
    INPUT = np.array([x0, y0, alfa0, F0])
    print(INPUT)
    L = 1  # Čas opazovanja

    def diff_eqs(INP, t):
        '''The main set of equations'''
        Y = np.zeros(4)
        x, y, alfa, F = INP
        Y[0] = np.cos(alfa)
        Y[1] = np.sin(alfa)
        Y[2] = (beta * x * np.sin(alfa) + np.cos(alfa)) / F
        Y[3] = -beta * x * np.cos(alfa) + np.sin(alfa)
        return Y  # For odeint

    s_i = 0.0
    s_f = L
    s = np.arange(s_i, s_f + ds, ds)
    RES = odeint(diff_eqs, INPUT, s)
    x_final = RES[-1, 0] # -1 last in RES and 0 for first element
    y_final = RES[-1, 1] # -1 last in RES and 1 for second element
    #rint(x_final,y_final,RES[0,2],RES[0,3])
    return [x_final, y_final - y_f]

def najdi_alfa_F(streljaj,beta):
    """Vrne [alfa_0, F_0] za dano beta."""
    return root(streljaj,[0, 1],options={'xtol': 1e-6}).x # [0,1] is initial guess

def streljaj_trajektorija(initial_guess):
    """Sprejme [alfa0, F0] in args=(beta).
    Vrne [x_final, y_final-y_f]."""
    alfa0, F0 = initial_guess
    x0 = 0
    y0 = 0
    INPUT = np.array([x0, y0, alfa0, F0])
    print(INPUT)
    L = 1  # Čas opazovanja

    def diff_eqs(INP, t):
        '''The main set of equations'''
        Y = np.zeros(4)
        x, y, alfa, F = INP
        Y[0] = np.cos(alfa)
        Y[1] = np.sin(alfa)
        Y[2] = (beta * x * np.sin(alfa) + np.cos(alfa)) / F
        Y[3] = -beta * x * np.cos(alfa) + np.sin(alfa)
        return Y  # For odeint

    s_i = 0.0
    s_f = L
    s = np.arange(s_i, s_f + ds, ds)
    RES = odeint(diff_eqs, INPUT, s)
    xi = RES[:, 0]
    yi = RES[:, 1]
    return [xi, yi]



#alfa0, F0 = najdi_alfa_F(streljaj, beta)
#print(alfa0, F0)
'''def fun(x):
    print(x)
    return [x[0],x[1]-3.2]
X=root(fun, [0,1]); print(X)
print(X.x)
alfa0,F0= X.x
print(alfa0,F0)'''

##### this works but we will use different code
'''X=root(streljaj, [0,1],options={'xtol': 1e-10}); print(X)
print(X.x)
alfa0,F0= X.x
print(alfa0,F0)'''

B=np.arange(20,50,1)
x0=[0,1]
for beta in B:
    print(x0)
    alfa0, F0 = root(streljaj,x0,options={'xtol': 1e-6}).x
    xi, yi = streljaj_trajektorija([alfa0, F0])
    plt.figure(0)
    plt.plot(xi, yi -y_f)
    x0=[alfa0,F0]

plt.figure(0)
plt.legend()
plt.grid()
#plt.axis('equal')
plt.savefig('vrvica_7.pdf')