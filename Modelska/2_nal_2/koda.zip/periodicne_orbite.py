import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import odeint
from scipy.optimize import root, minimize, root_scalar, minimize_scalar

def potential(x, y):
    return 0.5 * x ** 2 + 0.5 * (y ** 2) + (x ** 2) * y - (y ** 3) / 3

def trajektorija(y, alpha):
    print('y pred preobrazbo',y)
    ### finding max_y and min_y to have movement in the region E<1/6
    def maks_y(Y):
        return H-(Y**2)/2 + (Y**3)/3
    y_max=root(maks_y,0.001).x[0]
    y_min=root(maks_y,-0.001).x[0]
    print('y_max:',y_max,'\ty_min:',y_min)
    ### just making sure the kinetic energy is not to big
    if y > y_max:
        y=y%y_max
    elif y < y_min:
        y=y%y_min
    print('dobljen y:',y)
    T = H- potential(0,y)
    print('kinetična:',T)
    assert T > 0, "kinetična energija je negativna, povečaj H ali zmanjšaj y"
    print('alpha pred preobrazbo',alpha)
    if np.abs(alpha)> 2*np.pi:
        if alpha >0:
            alpha=alpha%(2*np.pi)
        else:
            alpha=-(-alpha%(2*np.pi))
    print('alpha po preobrazbi',alpha)
    v=np.sin(alpha)*np.sqrt(2*T)
    u=np.cos(alpha)*np.sqrt(2*T)
    INPUT = np.array([0, y, u, v])  # [x0,y0,u0,v0]

    def diff_eqs(INP, t):
        '''The main set of equations'''
        Y = np.zeros(4)
        x, y, u, v = INP
        Y[0] = u
        Y[1] = v
        Y[2] = -x - 2 * x * y
        Y[3] = -y - x ** 2 + y ** 2
        return Y  # For odeint

    t_start = 0.0
    t_range = np.arange(t_start, t_end + dt/2 , dt)
    RES = odeint(diff_eqs, INPUT, t_range)
    x = RES[:, 0]
    y = RES[:, 1]
    u = RES[:, 2]
    v = RES[:, 3]
    return x,y,u,v

def streljaj(array):
    y_i=array[0]
    alpha=array[1]
    print('y pred preobrazbo',y_i)
    ### finding max_y and min_y to have movement in the region E<1/6
    def maks_y(Y):
        return H-(Y**2)/2 + (Y**3)/3
    y_max=root(maks_y,0.001).x[0]
    y_min=root(maks_y,-0.001).x[0]
    print('y_max:',y_max,'\ty_min:',y_min)
    ### just making sure the kinetic energy is not to big
    if y_i > y_max:
        y_i=y_i%y_max
    elif y_i < y_min:
        y_i=y_i%y_min
    print('dobljen y:',y_i)
    T = H- potential(0,y_i)
    print('kinetična:',T)
    assert T > 0, "kinetična energija je negativna, povečaj H ali zmanjšaj y"
    print('alpha pred preobrazbo',alpha)
    if np.abs(alpha)> 2*np.pi:
        if alpha >0:
            alpha=alpha%(2*np.pi)
        else:
            alpha=-(-alpha%(2*np.pi))
    print('alpha po preobrazbi',alpha)
    v_i=np.sin(alpha)*np.sqrt(2*T)
    u_i=np.cos(alpha)*np.sqrt(2*T)
    print('začetni hitrosti:',u_i,v_i)
    INPUT = np.array([0, y_i, u_i, v_i])  # [x0,y0,u0,v0]

    def diff_eqs(INP, t):
        '''The main set of equations'''
        Y = np.zeros(4)
        x, y, u, v = INP
        Y[0] = u
        Y[1] = v
        Y[2] = -x - 2 * x * y
        Y[3] = -y - x ** 2 + y ** 2
        return Y  # For odeint

    t_start = 0.0
    t_range = np.arange(t_start, t_end + dt/2 , dt)
    RES = odeint(diff_eqs, INPUT, t_range)
    x = RES[:, 0]
    y = RES[:, 1]
    u = RES[:, 2]
    v = RES[:, 3]

    def presek(x,y,u,v):
        k = []
        for i in range(len(x) - 1):
            if np.sign(x[i]) * np.sign(x[i + 1]) < 0:
                k.append(i)
        y_presek = np.zeros(len(k))
        u_presek = np.zeros(len(k))
        v_presek = np.zeros(len(k))
        alpha_presek = np.zeros(len(k))
        for i in range(len(k)):
            y_presek[i] = (y[k[i]] + y[k[i] + 1]) / 2
            u_presek[i] = (u[k[i]] + u[k[i] + 1]) / 2
            v_presek[i] = (v[k[i]] + v[k[i] + 1]) / 2
            alpha_presek[i]= np.arccos(u_presek[i]/np.sqrt(u_presek[i]**2 + v_presek[i]**2))
        print('preseki',y_presek,u_presek,v_presek,alpha_presek)
        if np.sign(y_i * y_presek[-1]) == 1:
            return y_presek[-1], alpha_presek[-1]
        else:
            return y_presek[-2], alpha_presek[-2]
    preseki=presek(x,y,u,v)
    return [y_i-preseki[0], alpha-preseki[1]]

def najdi(streljaj):
    return root(streljaj,x0=[y_0,alpha_0]).x # [y_0,alpha] is initial guess
##### change only the initial conditions and it will converge
##### pictures are saved respectivuly
x_0=0 # x_0 is fixed at 0
H=0.07
y_0=-0.3
alpha_0=2
dt=0.001
t_end=60

def maks_y(Y):
    return H - (Y ** 2) / 2 + (Y ** 3) / 3

y1_max=root(maks_y,0.001).x[0]
y1_min=root(maks_y,-0.001).x[0]
y_0,alpha_0=najdi(streljaj)
print(alpha_0)
if y_0 > y1_max:
    y_0 = y_0 % y1_max
elif y_0 < y1_min:
    y_0 = y_0 % y1_min
X=trajektorija(y_0,alpha_0)
plt.figure(1)
plt.plot(X[0],X[1])
plt.plot([X[0][0],X[0][-1]],[X[1][0],X[1][-1]],'o',color='black',markersize=2)
plt.axis("equal")
plt.xlabel('x')
plt.ylabel('y')
plt.title(r'H=%s, $\alpha_{0}=$%.7s, $y_{0}$=%.7s, $t$=%s, $dt$=%s'%(str(H),str(alpha_0),str(y_0),str(t_end),str(dt)))
plt.savefig('periodicne_orbite_14.pdf')

t_end=4000
X=trajektorija(y_0,alpha_0)
plt.figure(2)
plt.plot(X[0],X[1])
plt.plot([X[0][0],X[0][-1]],[X[1][0],X[1][-1]],'o',color='black',markersize=2)
plt.axis("equal")
plt.xlabel('x')
plt.ylabel('y')
plt.title(r'H=%s, $\alpha_{0}=$%.7s, $y_{0}$=%.7s, $t$=%s, $dt$=%s'%(str(H),str(alpha_0),str(y_0),str(t_end),str(dt)))
plt.savefig('periodicne_orbite_14_daljsa.pdf')
plt.show()


'''def presek(array):
    x=array[0]
    y=array[1]
    u=array[2]
    v=array[3]
    k=[]
    for i in range(len(x)-1):
        if np.sign(x[i]) *np.sign(x[i+1]) <0:
            k.append(i)
    y_presek=np.zeros(len(k))
    u_presek=np.zeros(len(k))
    v_presek=np.zeros(len(k))
    alpha_presek = np.zeros(len(k))
    for i in range(len(k)):
        y_presek[i] = (y[k[i]] + y[k[i] + 1]) / 2
        u_presek[i] = (u[k[i]] + u[k[i] + 1]) / 2
        v_presek[i] = (v[k[i]] + v[k[i] + 1]) / 2
        alpha_presek[i] = np.arccos(u_presek[i] / np.sqrt(u_presek[i] ** 2 + v_presek[i] ** 2))
    print('preseki', y_presek, u_presek, v_presek, alpha_presek)
    if np.sign(y_0*y_presek[-1])==1:
        return y_presek[-1], alpha_presek[-1]
    else:
        return y_presek[-2], alpha_presek[-2]

print(presek(X))'''
##### finding y_max and y_min for a given H at x=0
'''def maks_y(Y):
    return H - (Y ** 2) / 2 + (Y ** 3) / 3
y_max=[]
y_min=[]
HH=np.arange(0,1/6 +0.0005,0.001)
for H in HH:
    y_max.append(root(maks_y,0.001).x[0])
    y_min.append(root(maks_y,-0.001).x[0])

plt.figure(100)
plt.plot(HH,y_max)
plt.plot(HH,y_min)
plt.show()
plt.close()'''