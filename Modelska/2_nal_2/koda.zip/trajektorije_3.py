import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import odeint
from scipy.optimize import root, minimize, root_scalar, minimize_scalar

def potential(x, y):
    return 0.5 * x ** 2 + 0.5 * (y ** 2) + (x ** 2) * y - (y ** 3) / 3

def trajektorija(y, alpha , t_end):
    T = H- potential(0,y)
    assert T > 0, "kinetična energija je negativna, povečaj H"
    v=np.sin(alpha)*np.sqrt(2*T)
    u=np.cos(alpha)*np.sqrt(2*T)
    INPUT = np.array([0, y, u, v])  # [x0,y0,u0,v0]

    def diff_eqs(INP, t):
        '''The main set of equations'''
        Y = np.zeros(4)
        x, y, u, v = INP
        Y[0] = u
        Y[1] = v
        Y[2] = -x - 2 * x * y
        Y[3] = -y - x ** 2 + y ** 2
        return Y  # For odeint

    t_start = 0.0
    t_range = np.arange(t_start, t_end + dt/2 , dt)
    RES = odeint(diff_eqs, INPUT, t_range)
    x = RES[:, 0]
    y = RES[:, 1]
    u = RES[:, 2]
    v = RES[:, 3]
    return x,y,u,v

def streljaj(arej): ##vrne zadnje x[-1],y[-1],u[-1],v[-1]
    x=x_0
    y=arej[0]
    alpha=arej[1]
    t_end=arej[2]
    if t_end < 0 and np.abs(t_end)>400:
        t_end=150
    elif t_end < 0:
        t_end=-1*t_end

    T = H- potential(x,y)
    if T<0:
        y=y_0
        T = H - potential(x, y)
    print(T)
    assert T > 0, "kinetična energija je negativna, povečaj H"
    if np.abs(alpha)> 2*np.pi:
        alpha=alpha%(2*np.pi)
    v=np.sin(alpha)*np.sqrt(2*T)
    u=np.cos(alpha)*np.sqrt(2*T)
    INPUT = np.array([x, y, u, v])  # [x0,y0,u0,v0]

    #print('začetni približki: ',x,y,u,v)
    #print('začetni alfa in čas:', t_end,alpha)

    def diff_eqs(INP, t):
        '''The main set of equations'''
        Y = np.zeros(4)
        x, y, u, v = INP
        Y[0] = u
        Y[1] = v
        Y[2] = -x - 2 * x * y
        Y[3] = -y - x ** 2 + y ** 2
        return Y  # For odeint

    t_start = 0.0
    t_range = np.arange(t_start, t_end + dt/2 , dt)
    RES = odeint(diff_eqs, INPUT, t_range)
    x = RES[:, 0]
    y = RES[:, 1]
    u = RES[:, 2]
    v = RES[:, 3]
    #print('končni rezultat: ',x[-1],y[-1],u[-1],v[-1])
    #print('alpha=',alpha)
    #print('čas=',t_end)
    return [y[0]-y[-1],alpha-np.arccos(u[-1]/np.sqrt((u[-1]**2)*(v[-1]**2))),t_end -t_end]

def najdi(streljaj):
    return root(streljaj,[y_0,alpha_0,t_end],options={'xtol': 1e-6}).x # [x_0,y_0,alpha,t_end] is initial guess


###### some parameters for trajectory
x_0=0
y_0=0.099
alpha_0=0
H=0.15
dt=0.001
t_end=40


X= najdi(streljaj)

'''traj = trajektorija(x=x_0,y=y_0,alpha=alpha,t_end=t_end)
print(traj[0])

x=traj[0]
y=traj[1]
plt.figure(0)
plt.plot(x,y)
plt.plot([x_0,traj[0][-1]],[y_0,traj[1][-1]],'o',color='black',markersize=2)
plt.axis("equal")
plt.show()'''