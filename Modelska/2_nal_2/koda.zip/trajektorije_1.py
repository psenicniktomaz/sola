import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import odeint


from scipy.optimize import root, minimize, root_scalar, minimize_scalar


def potential(x, y):
    return 0.5 * x ** 2 + 0.5 * (y ** 2) + (x ** 2) * y - (y ** 3) / 3

def trajektorija(y, x, alpha, t_end):
    T = H- potential(x,y)
    assert T > 0, "kinetična energija je negativna, povečaj H"
    v=np.sin(alpha)*np.sqrt(2*T)
    u=np.cos(alpha)*np.sqrt(2*T)
    INPUT = np.array([x, y, u, v])  # [x0,y0,u0,v0]

    def diff_eqs(INP, t):
        '''The main set of equations'''
        Y = np.zeros(4)
        x, y, u, v = INP
        Y[0] = u
        Y[1] = v
        Y[2] = -x - 2 * x * y
        Y[3] = -y - x ** 2 + y ** 2
        return Y  # For odeint

    t_start = 0.0
    t_range = np.arange(t_start, t_end + dt/2 , dt)
    RES = odeint(diff_eqs, INPUT, t_range)
    print(RES[0])
    print(RES[1])
    from collections import namedtuple
    rezultat = namedtuple("Rezultat", ["x", "y", "u", "v", "slovar_parametrov"])
    return rezultat(RES[:, 0], RES[:, 1], RES[:, 2], RES[:, 3], {"x": x, "y": y, "H": H, "alpha_0": alpha, "t_end": t_end, "dt": dt})

###### some parameters for trajectory
x_0=0.309
y_0=0.099
alpha=0
H=0.12
dt=0.001
t_end=4000

traj = trajektorija(x=x_0,y=y_0,alpha=alpha,t_end=t_end)
print(traj.x)
print(traj[0])
print(traj.y)
print(traj[1])
print(traj[1][-1])
fig, ax = plt.subplots()
ax.plot(traj.x, traj.y, linewidth=0.2)
ax.plot([x_0,traj[0][-1]],[y_0,traj[1][-1]],'o',color='black',markersize=2)
ax.set_aspect("equal")
plt.title(r"""Testna orbita,
parametri: $x_0={{{x}}}$, $y_0={{{y}}}$, $H={{{H}}}$, $\alpha_0$=${{{alpha_0}}}$""".format(**traj.slovar_parametrov))
#plt.savefig("2-4-testna-orbita_daljsa.pdf", bbox_inches="tight")
plt.show()