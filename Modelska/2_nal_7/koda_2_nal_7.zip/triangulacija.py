import numpy as np
from scipy.spatial import Delaunay
from scipy.spatial import delaunay_plot_2d

import matplotlib.pyplot as plt

#generating points for triangulation
def lik():
    #outer edge points
    N=10
    R_x=[]
    R_y=[]
    R=[]
    for i in range(N+1):
        R_x.append(0.5 + 0.5* np.cos(i*np.pi/N))
        R_y.append(0.5*np.sin(i*np.pi/N))
        R.append([R_x[i],R_y[i]])
    R=np.array(R)
    h=2/N
    x=np.arange(h,1,h)
    X=[]
    for i in range(len(x)):
        X.append([x[i],0])
    X=np.array(X)

    #inner points
    y=h
    inn=[]
    while y <0.5:
        x=-np.sqrt(0.25 -y**2)+2*h/3
        while (x**2 +y**2) <0.25:
            inn.append([x+0.5,y])
            x=x+h
        y=y+h
    inn=np.array(inn)


    points=np.concatenate((X,R,inn))
    return points

#print(lik())


tri=Delaunay(lik())
nodes=tri.simplices #we get the nodes of triangles

print(nodes)
print(nodes[1][1])



'''delaunay_plot_2d(tri)
plt.axis('equal')

plt.show()'''