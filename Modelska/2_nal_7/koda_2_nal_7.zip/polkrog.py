import numpy as np
from scipy.spatial import Delaunay
from scipy.spatial import delaunay_plot_2d
import matplotlib.pyplot as plt

N=30
#generating points for triangulation
def polkrog():

    #inner points
    '''y=h
    inn=[]
    while y <0.5:
        x=-np.sqrt(0.25 -y**2)+2*h/3
        while (x**2 +y**2) <0.25:
            inn.append([x+0.5,y])
            x=x+h
        y=y+h
    inn=np.array(inn)'''

    R_inn=[]
    h=0.5/(N+1)
    r=np.arange(0.5-h, 0, -h)
    k=0
    for j in r:
        h_phi=np.pi/(2*N-1-k)
        phi=np.arange(h_phi/2, np.pi, h_phi)
        R_x = []
        R_y = []
        for i in range(2*N-1-k):
            R_x.append(0.5 + j * np.cos(phi[i]))
            R_y.append(j * np.sin(phi[i]))
            R_inn.append([R_x[i], R_y[i]])
        k=k+1

    R_inn.append([0.5,0.02]) #just another point in the middle

    # outer edge points
    x = np.arange(1, N - 1, 1) / (N - 1)
    X = []
    for i in range(len(x)):
        X.append([x[i], 0])
    X = np.array(X)

    R_x = []
    R_y = []
    R = []
    for i in range(0,2*N,1):
        R_x.append(0.5 + 0.5 * np.cos(i * np.pi / (2*N-1)))
        R_y.append(0.5 * np.sin(i * np.pi / (2*N-1)))
        R.append([R_x[i], R_y[i]])
    R = np.array(R)

    '''2*N points on the radii of circle and N points on y=0 axis
    total of 2*N + N -2 outer edge points'''

    points=np.concatenate((R_inn,X,R))

    return points

tri=Delaunay(polkrog())
nodes=tri.simplices #we get the nodes of triangles
points=polkrog() #coordinates of the points
print(points)
print(nodes)


M=len(points)

K=np.zeros((M,M))
F=np.zeros(M)
T=len(nodes)
k=0
for i in range(T):
    l,m,n= nodes[k][0],nodes[k][1],nodes[k][2] #x1, x2 and x3 nodes of triangle; not the coordinates
    #print(l,m,n)
    Pe=[[1 ,points[l][0], points[l][1]],
        [1 ,points[m][0], points[m][1]],
        [1 ,points[n][0], points[n][1]]] #matrix with 1,x1,x2,x3,y1,y2,y3
    Pe=np.array(Pe) #matrix for a triangle
    jac_det=np.linalg.det(Pe) # 2 * area of the triangle

    #computing local stiffness matrix elements
    A11=((points[m][1]-points[n][1])**2 +(points[n][0]-points[m][0])**2)/jac_det
    A12=((points[m][1]-points[n][1])*(points[n][1]-points[l][1]) +
         (points[n][0]-points[m][0])*(points[l][0]-points[n][0]))/jac_det
    A13=((points[m][1]-points[n][1])*(points[l][1]-points[m][1]) +
         (points[n][0]-points[m][0])*(points[m][0]-points[l][0]))/jac_det
    A22=((points[n][1]-points[l][1])*(points[n][1]-points[l][1]) +
         (points[l][0]-points[n][0])*(points[l][0]-points[n][0]))/jac_det
    A23=((points[n][1]-points[l][1])*(points[l][1]-points[m][1]) +
         (points[l][0]-points[n][0])*(points[m][0]-points[l][0]))/jac_det
    A33=((points[l][1]-points[m][1])**2 + (points[m][0]-points[l][0])**2)/jac_det
    #print('A11:',A11,'\nA12:',A12, '\nA12:',A13,'\nA22:',A22,'\nA23:',A23,'\nA33: ', A33)

    K[l][l]= K[l][l]+A11
    K[l][m]=K[l][m]+ A12; K[m][l]=K[m][l]+A12
    K[l][n]=K[l][n]+ A13; K[n][l]=K[n][l]+A13
    K[m][m]= K[m][m]+A22
    K[m][n]=K[m][n]+A23 ; K[n][m]=K[n][m]+ A23
    K[n][n]=K[n][n]+A33
    #print(K[0][0], K[1][1],K[1][0],K[0][1])


    Fe=jac_det/3 #in truth 1/6 but it's easier to consider 1/2 here
    '''F[l]=F[l] + ((points[m][0]-points[l][0])*(points[n][1]-points[l][1]) -
         (points[n][0]-points[l][0])*(points[m][1]-points[l][1]))/6
    F[m]=F[m] + ((points[n][0]-points[m][0])*(points[l][1]-points[m][1]) -
        (points[l][0]-points[m][0])*(points[n][1]-points[m][1]))/6
    F[n]=F[n] + ((points[l][0]-points[n][0])*(points[m][1]-points[n][1]) -
         (points[m][0]-points[n][0])*(points[l][1]-points[n][1]))/6'''
    F[l]=F[l] + Fe
    F[m]=F[m] + Fe
    F[n]=F[n] + Fe
    k=k+1


b=np.arange(M - 2*N - N +2 ,M,1) #boundary nodes

Fb=F
for i in b:
    Fb[i]=0
Kb=K

for i in range(len(points)):
    for j in b:
        Kb[i][j]=0
        Kb[j][i]=0
for i in b:
    Kb[i][i]=1

print(Kb)
print(Fb)

Phi=np.linalg.solve(Kb,Fb)
print(Phi)


X=[]
Y=[]
for i in range(len(points)):
    X.append(points[i][0])
    Y.append((points[i][1]))

plt.figure(0)
plt.tricontourf(X,Y,Phi,levels=15)
plt.colorbar()
plt.axis('equal')
#plt.show()



delaunay_plot_2d(tri)
plt.axis('equal')
plt.show()