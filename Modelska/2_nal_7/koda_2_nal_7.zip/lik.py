import numpy as np
from scipy.spatial import Delaunay
from scipy.spatial import delaunay_plot_2d
import matplotlib.pyplot as plt

N=14 #not working for any arbitrary number, problem is in lik
''' number of boundary points not the same as len(b) - b is found in
the last 1/4 of the code

but works just fine for N=2,3,9,10,11,14; those were tested
not working for N= 4, 7,8
'''

def lik():
    U=[]

    #inner points
    #left side
    h_y=0.5/(N+1)
    h_x=0.25/(N+1)
    x=np.arange(h_x, 0.249, h_x)
    y=np.arange(0.25, 0.751,h_y)
    for i in x:
        for j in y:
            U.append([i,j])

    #right side
    x = np.arange(0.75+h_x, 1, h_x)
    for i in x:
        for j in y:
            U.append([i, j])


    #bottom side
    h_x = 0.5 / (N +1)
    h_y = 0.25 / (N + 1)
    x = np.arange(0.25, 0.76, h_x)
    y = np.arange(h_y,0.249 , h_y)
    for i in x:
        for j in y:
            U.append([i, j])

    #bottom left
    h_x=0.25/(N+1)
    h_y=0.25/(N+1)
    for i in range(N):
        h_xx= (0.25-(i+1)*h_x)/(N+1)
        h_yy= (0.25-(i+1)*h_y)/(N+1)
        X_min=(i+1)*h_x
        Y_max=(i+1)*h_y
        x=np.arange(X_min+h_xx,0.249,h_xx)
        y=np.arange(0.25 - h_yy, Y_max +0.001 ,-h_yy)
        for j in range(N):
            U.append([x[j],y[j]])

    # bottom right
    h_x = 0.25 / (N + 1)
    h_y = 0.25 / (N + 1)
    for i in range(N):
        h_xx = (0.25 - (i + 1) * h_x) / (N + 1)
        h_yy = (0.25 - (i + 1) * h_y) / (N + 1)
        X_min = (i + 1) * h_x
        Y_min =(i + 1) * h_y
        x = np.arange(0.75 + h_xx, 0.999, h_xx)
        y = np.arange(Y_min +h_yy,0.249, h_yy)
        for j in range(N):
            U.append([x[j], y[j]])

    # upper right
    h_x = 0.25 / (N + 1)
    h_y = 0.25 / (N + 1)
    for i in range(N):
        h_xx = (0.25 - (i + 1) * h_x) / (N + 1)
        h_yy = (0.25 - (i + 1) * h_y) / (N + 1)
        X_min = (i + 1) * h_x
        Y_max = (i + 1) * h_y
        x = np.arange(X_min + h_xx, 0.249, h_xx)
        y = np.arange(0.25 - h_yy, Y_max + 0.001, -h_yy)
        for j in range(N):
            U.append([-x[j]+1, -y[j]+1])
    for i in range(N):
        U.append([0.75, 0.75 +h_y*(i+1)])

    #upper left
    # bottom right
    h_x = 0.25 / (N + 1)
    h_y = 0.25 / (N + 1)
    for i in range(N):
        h_xx = (0.25 - (i + 1) * h_x) / (N + 1)
        h_yy = (0.25 - (i + 1) * h_y) / (N + 1)
        X_min = (i + 1) * h_x
        Y_min = (i + 1) * h_y
        x = np.arange(0.75 + h_xx, 0.999, h_xx)
        y = np.arange(Y_min + h_yy, 0.249, h_yy)
        for j in range(N):
             U.append([-x[j]+1, -y[j]+1])
    for i in range(N):
        U.append([0.25, 0.75 +h_y*(i+1)])


    #middle left
    h_x = 0.25 / (N + 1)
    h_y = 0.25 / (N + 1)
    x=np.arange(0.25 + h_x, 0.499, h_x)
    for j in range(N):
        y=-x +np.ones(N)*(1.25 -h_y*(1+j))
        for i in range(N):
            U.append([x[i],y[i]])

    #middle right
    x = np.arange(0.5 + h_x, 0.749, h_x)
    for j in range(N):
        y = x + np.ones(N) * (0.25 - h_y * (1 + j))
        for i in range(N):
            U.append([x[i], y[i]])

    #middle
    y=np.arange(0.75 - h_y, 0.501,-h_y)
    for i in range(N):
        U.append([0.5,y[i]])

    # outer edge points
    h_y=0.5/(N-1)
    y=np.arange(0.25,0.751,h_y)
    for i in y:
        U.append([0,i])
        U.append([1,i])

    h_x=h_y
    x=np.arange(0.25,0.751,h_x)
    for i in x:
        U.append([i,0])

    #all are the triangles
    h_x=0.25/(N-1)
    h_y=h_x
    x=np.arange(0+h_x,0.251,h_x)
    y=np.arange(0.25-h_y,-0.01,-h_y)
    for i in range(len(x)):
        U.append([x[i],y[i]])


    x = np.arange(0.75 + h_x, 1.01, h_x)
    y = np.arange(0 + h_y, 0.251, h_y)
    for i in range(len(x)):
        U.append([x[i], y[i]])


    x = np.arange(h_x, 0.24, h_x)
    y = np.arange(0.75 + h_y, 1, h_y)
    for i in range(len(x)):
        U.append([x[i], y[i]])

    x = np.arange(0.25 + h_x, 0.499, h_x)
    y = np.arange(1- h_y, 0.75, -h_y)
    for i in range(len(x)):
        U.append([x[i], y[i]])


    x = np.arange(0.5 + h_x, 0.74, h_x)
    y = np.arange(0.75 + h_y, 1, h_y)
    for i in range(len(x)):
        U.append([x[i], y[i]])


    x = np.arange(0.75 + h_x, 1, h_x)
    y = np.arange(1 - h_y, 0.751, -h_y)
    for i in range(len(x)):
        U.append([x[i], y[i]])

    U.append([0.5,0.75])
    U.append([0.25,1])
    U.append([0.75,1])

    #inner edge points
    h_y=0.5/(N-1)
    y=np.arange(0.25,0.751,h_y)
    for i in y:
        U.append([0.25,i])
        U.append([0.75,i])

    h_x = h_y
    x = np.arange(0.25+h_x, 0.75, h_x)
    for i in x:
        U.append([i, 0.25])


    h_x=0.25/(N-1)
    h_y=h_x
    x = np.arange(0.25 + h_x, 0.499, h_x)
    y = np.arange(0.75- h_y, 0.499, -h_y)
    for i in range(len(x)):
        U.append([x[i], y[i]])

    x = np.arange(0.5 + h_x, 0.749, h_x)
    y = np.arange(0.5 + h_y, 0.749, h_y)
    for i in range(len(x)):
        U.append([x[i], y[i]])

    U.append([0.5,0.5])

    return U


tri=Delaunay(lik())
points=lik() #coordinates of the points
print(len(points))
print(points)

nodes=tri.simplices #we get the nodes of triangles
M=len(points)

K=np.zeros((M,M))
F=np.zeros(M)
T=len(nodes)
k=0
for i in range(T):
    l,m,n= nodes[k][0],nodes[k][1],nodes[k][2] #x1, x2 and x3 nodes of triangle; not the coordinates
    #print(l,m,n)
    Pe=[[1 ,points[l][0], points[l][1]],
        [1 ,points[m][0], points[m][1]],
        [1 ,points[n][0], points[n][1]]] #matrix with 1,x1,x2,x3,y1,y2,y3
    Pe=np.array(Pe) #matrix for a triangle
    jac_det=np.linalg.det(Pe) # 2 * area of the triangle

    #computing local stiffness matrix elements
    A11=((points[m][1]-points[n][1])**2 +(points[n][0]-points[m][0])**2)/jac_det
    A12=((points[m][1]-points[n][1])*(points[n][1]-points[l][1]) +
         (points[n][0]-points[m][0])*(points[l][0]-points[n][0]))/jac_det
    A13=((points[m][1]-points[n][1])*(points[l][1]-points[m][1]) +
         (points[n][0]-points[m][0])*(points[m][0]-points[l][0]))/jac_det
    A22=((points[n][1]-points[l][1])*(points[n][1]-points[l][1]) +
         (points[l][0]-points[n][0])*(points[l][0]-points[n][0]))/jac_det
    A23=((points[n][1]-points[l][1])*(points[l][1]-points[m][1]) +
         (points[l][0]-points[n][0])*(points[m][0]-points[l][0]))/jac_det
    A33=((points[l][1]-points[m][1])**2 + (points[m][0]-points[l][0])**2)/jac_det
    #print('A11:',A11,'\nA12:',A12, '\nA12:',A13,'\nA22:',A22,'\nA23:',A23,'\nA33: ', A33)

    K[l][l]= K[l][l]+A11
    K[l][m]=K[l][m]+ A12; K[m][l]=K[m][l]+A12
    K[l][n]=K[l][n]+ A13; K[n][l]=K[n][l]+A13
    K[m][m]= K[m][m]+A22
    K[m][n]=K[m][n]+A23 ; K[n][m]=K[n][m]+ A23
    K[n][n]=K[n][n]+A33
    #print(K[0][0], K[1][1],K[1][0],K[0][1])


    Fe=jac_det/3 #in truth 1/6 but it's easier to consider 1/2 here
    '''F[l]=F[l] + ((points[m][0]-points[l][0])*(points[n][1]-points[l][1]) -
         (points[n][0]-points[l][0])*(points[m][1]-points[l][1]))/6
    F[m]=F[m] + ((points[n][0]-points[m][0])*(points[l][1]-points[m][1]) -
        (points[l][0]-points[m][0])*(points[n][1]-points[m][1]))/6
    F[n]=F[n] + ((points[l][0]-points[n][0])*(points[m][1]-points[n][1]) -
         (points[m][0]-points[n][0])*(points[l][1]-points[n][1]))/6'''
    F[l]=F[l] + Fe
    F[m]=F[m] + Fe
    F[n]=F[n] + Fe
    k=k+1



b=np.arange(M - 14*N +12,M,1) #boundary nodes
print(len(b))
print(b)


Fb=F
for i in b:
    Fb[i]=0
Kb=K

for i in range(len(points)):
    for j in b:
        Kb[i][j]=0
        Kb[j][i]=0
for i in b:
    Kb[i][i]=1

print(Kb)
print(Fb)

Phi=np.linalg.solve(Kb,Fb)
print(Phi)


X=[]
Y=[]
for i in range(len(points)):
    X.append(points[i][0])
    Y.append((points[i][1]))

plt.figure(0)
plt.tricontourf(X,Y,Phi,levels=15)
plt.colorbar()
plt.axis('equal')


delaunay_plot_2d(tri)
plt.axis('equal')
plt.show()
