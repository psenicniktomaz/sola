import numpy as np
from scipy.spatial import Delaunay
from scipy.spatial import delaunay_plot_2d
import matplotlib.pyplot as plt


m=30
n=30
M=m
N=n

def pravokotnik():
    h_m = 1 / (m-1)
    h_n = 1 / (n-1)
    x = np.arange(1, m-1,1)/(m-1); y = np.arange(1, n-1,1)/(n-1)  # excludes boundary nodes
    U=[]
    for i in range(len(x)):
        for j in range(len(y)):
            U.append([x[i],y[j]])

    #boundary nodes
    #left
    y = np.arange(0, n, 1) / (n - 1)
    for i in range(len(y)):
        U.append([0, y[i]])

    # top
    for i in range(len(x)):
        U.append([x[i], 1])

    #right
    for i in range(len(y)):
        U.append([1, y[i]])
    #bottom
    x = np.arange(1, m - 1, 1) / (m - 1)
    for i in range(len(x)):
        U.append([x[i], 0])

    return U

#print(pravokotnik())

tri=Delaunay(pravokotnik(),furthest_site=False) #triangulation
nodes=tri.simplices #we get the nodes of triangles
#print(nodes)
points=pravokotnik() #coordinates of the points
#print(points)

K=np.zeros((n*m,n*m))
F=np.zeros(n*m)
T=len(nodes)
k=0
for i in range(T):
    l,m,n= nodes[k][0],nodes[k][1],nodes[k][2] #x1, x2 and x3 nodes of triangle; not the coordinates
    #print(l,m,n)
    Pe=[[1 ,points[l][0], points[l][1]],
        [1 ,points[m][0], points[m][1]],
        [1 ,points[n][0], points[n][1]]] #matrix with 1,x1,x2,x3,y1,y2,y3
    Pe=np.array(Pe) #matrix for a triangle
    jac_det=np.linalg.det(Pe) # 2 * area of the triangle

    #computing local stiffness matrix elements
    A11=((points[m][1]-points[n][1])**2 +(points[n][0]-points[m][0])**2)/jac_det
    A12=((points[m][1]-points[n][1])*(points[n][1]-points[l][1]) +
         (points[n][0]-points[m][0])*(points[l][0]-points[n][0]))/jac_det
    A13=((points[m][1]-points[n][1])*(points[l][1]-points[m][1]) +
         (points[n][0]-points[m][0])*(points[m][0]-points[l][0]))/jac_det
    A22=((points[n][1]-points[l][1])*(points[n][1]-points[l][1]) +
         (points[l][0]-points[n][0])*(points[l][0]-points[n][0]))/jac_det
    A23=((points[n][1]-points[l][1])*(points[l][1]-points[m][1]) +
         (points[l][0]-points[n][0])*(points[m][0]-points[l][0]))/jac_det
    A33=((points[l][1]-points[m][1])**2 + (points[m][0]-points[l][0])**2)/jac_det
    #print('A11:',A11,'\nA12:',A12, '\nA12:',A13,'\nA22:',A22,'\nA23:',A23,'\nA33: ', A33)

    K[l][l]= K[l][l]+A11
    K[l][m]=K[l][m]+ A12; K[m][l]=K[m][l]+A12
    K[l][n]=K[l][n]+ A13; K[n][l]=K[n][l]+A13
    K[m][m]= K[m][m]+A22
    K[m][n]=K[m][n]+A23 ; K[n][m]=K[n][m]+ A23
    K[n][n]=K[n][n]+A33
    #print(K[0][0], K[1][1],K[1][0],K[0][1])


    Fe=jac_det/3 #in truth 1/6 but it's easier to consider 1/2 here
    '''F[l]=F[l] + ((points[m][0]-points[l][0])*(points[n][1]-points[l][1]) -
         (points[n][0]-points[l][0])*(points[m][1]-points[l][1]))/6
    F[m]=F[m] + ((points[n][0]-points[m][0])*(points[l][1]-points[m][1]) -
        (points[l][0]-points[m][0])*(points[n][1]-points[m][1]))/6
    F[n]=F[n] + ((points[l][0]-points[n][0])*(points[m][1]-points[n][1]) -
         (points[m][0]-points[n][0])*(points[l][1]-points[n][1]))/6'''
    F[l]=F[l] + Fe
    F[m]=F[m] + Fe
    F[n]=F[n] + Fe
    k=k+1


b=np.arange(M*N -2*(N+M) +4,M*N,1) #boundary nodes
#print(b)
#print(K)
#print(F)

Fb=F
for i in b:
    Fb[i]=0
Kb=K

for i in range(len(points)):
    for j in b:
        Kb[i][j]=0
        Kb[j][i]=0
for i in b:
    Kb[i][i]=1

print(Kb)
print(Fb)

Phi=np.linalg.solve(Kb,Fb)
print(Phi)


X=[]
Y=[]
for i in range(len(points)):
    X.append(points[i][0])
    Y.append((points[i][1]))

plt.figure(0)
plt.tricontourf(X,Y,Phi,levels=15)
plt.colorbar()
plt.axis('equal')
#plt.show()



delaunay_plot_2d(tri)
plt.axis('equal')
plt.show()