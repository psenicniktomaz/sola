import numpy as np
from scipy.spatial import Delaunay
from scipy.spatial import delaunay_plot_2d
import matplotlib.pyplot as plt



m=3
n=4
M=m
N=n

def pravokotnik():
    h_m = 1 / (m-1)
    h_n = 1 / (n-1)
    x = np.arange(1, m-1,1)/(m-1); y = np.arange(1, n-1,1)/(n-1)  # excludes boundary nodes
    U=[]
    for i in range(len(x)):
        for j in range(len(y)):
            U.append([x[i],y[j]])

    #boundary nodes
    #left
    y = np.arange(0, n, 1) / (n - 1)
    for i in range(len(y)):
        U.append([0, y[i]])

    # top
    for i in range(len(x)):
        U.append([x[i], 1])

    #right
    for i in range(len(y)):
        U.append([1, y[i]])
    #bottom
    x = np.arange(1, m - 1, 1) / (m - 1)
    for i in range(len(x)):
        U.append([x[i], 0])

    return U

#print(pravokotnik())

tri=Delaunay(pravokotnik())
nodes=tri.simplices #we get the nodes of triangles
#print(nodes)
points=pravokotnik()
#print(points)

K=np.zeros((n*m,n*m))
F=np.zeros(n*m)
T=len(nodes)
k=0
for i in range(T):
    l,m,n= nodes[k][0],nodes[k][1],nodes[k][2]
    Pe=[[1 ,points[l][0], points[l][1]],
        [1 ,points[m][0], points[m][1]],
        [1 ,points[n][0], points[n][1]]]
    Pe=np.array(Pe) #matrix for a triangle
    S=np.linalg.det(Pe)/2 #area of the triangle
    C=np.linalg.inv(Pe)
    grad=C[1:3,:] #element matrix of slopes b,c in grad
    Ke=S*np.matmul(np.transpose(grad),grad)
    K[l][l]= K[l][l]+Ke[0][0]; K[m][l]=K[m][l]+ Ke [0][1]; K[n][l]=K[n][l]+ Ke [0][2]
    K[l][m]= K[l][m]+Ke[1][0]; K[m][m]=K[m][m]+ Ke [1][1]; K[n][m]=K[n][m]+ Ke [1][2]
    K[l][n]= K[l][n]+Ke[2][0]; K[m][n]=K[m][n]+ Ke [2][1]; K[n][n]=K[n][n]+ Ke [2][2]

    Fe=S/3
    F[l]=F[l] + Fe
    F[m]=F[m] + Fe
    F[n]=F[n] + Fe
    k=k+1


b=np.arange(M*N -2*(N+M) +4,M*N,1)
#print(b)
#print(K)
print(F)

Fb=F
for i in b:
    Fb[i]=0
Kb=K

for i in range(len(points)):
    for j in b:
        Kb[i][j]=0
        Kb[j][i]=0
for i in b:
    Kb[i][i]=1

print(Kb)
print(Fb)

Phi=np.linalg.solve(Kb,F)
print(Phi)




delaunay_plot_2d(tri)
plt.axis('equal')
plt.show()