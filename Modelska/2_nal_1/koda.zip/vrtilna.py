import numpy as np
from scipy.integrate import ode
import matplotlib.pyplot as plt


# Get current size
fig_size = plt.rcParams["figure.figsize"]
#print("Current size:", fig_size)
#Set figure width to 8 and height to 4.8
fig_size[0] = 8    #povečamo našo slikico (menda je osnova(6.4,4.8)
fig_size[1] = 6
plt.rcParams["figure.figsize"] = fig_size
#print("Current size:", fig_size)

def f(t,y):
    return [y[2], y[3], -y[0]/((y[0]*y[0] + y[1]*y[1])**(3/2)),
            -y[1]/((y[0]*y[0] + y[1]*y[1])**(3/2))]

def jac(t,y):
    return [[0,0,1,0],
           [0,0,0,1],
           [(2*y[0]*y[0]-y[1]*y[1])/((y[0]*y[0]+y[1]*y[1])**(5/2)),3*y[0]*y[1]/((y[0]*y[0]+y[1]*y[1])**(5/2)),0,0],
           [(-y[0]*y[0]+2*y[1]*y[1])/((y[0]*y[0]+y[1]*y[1])**(5/2)),3*y[0]*y[1]/((y[0]*y[0]+y[1]*y[1])**(5/2)),0,0]]

T=[80,90,100,110,120]
v0=[0.6,1,1.3,1.4,1.6]

l=len(T)

for i in range(l):
    dt=0.001
    P0=[1,0,0,v0[i]] # x0,y0,u0,v0
    x0=np.float(P0[0])
    y0=np.float(P0[3])
    t0=0

    #t1=T[i]
    t1=100
    r = ode(f, jac).set_integrator("dopri5")
    r.set_initial_value(P0, t0)

    X = [P0[0]]
    Y = [P0[1]]
    U=[P0[2]]
    V=[P0[3]]
    t = [0]

    while r.successful() and r.t < t1:
        r.integrate(r.t + dt)
        X.append(r.y[0])
        Y.append(r.y[1])
        U.append(r.y[2])
        V.append(r.y[3])
        t.append(r.t)

    X = np.array(X)
    Y = np.array(Y)
    V = np.array(V)
    U = np.array(U)

    dT = str(dt)

    #### vrtilna
    vrtilna=X*V-Y*U

    plt.figure(0)
    plt.plot(t,vrtilna,label='v0 =%s' %(str(P0[3])))
    print('del',i)

    gama0=X[0]*V[0]-Y[0]*U[0]
    gama=np.delete(vrtilna,0)
    T=np.delete(t,0)

    plt.figure(1)
    plt.semilogy(T,np.abs(gama -gama0),label='v0 =%s' %(str(P0[3])))


plt.figure(0)
plt.xlabel('t')
plt.ylabel(r'$\Gamma$')
plt.legend(bbox_to_anchor=(1, 1.05),prop={'size': 12}, borderaxespad=1,frameon=False)
plt.savefig('vrtilna.pdf',bbox_inches='tight')

plt.figure(1)
plt.xlabel('t')
plt.ylabel(r'$|\Gamma - \Gamma_{0}|$')
plt.legend(bbox_to_anchor=(1, 1.05),prop={'size': 12}, borderaxespad=1,frameon=False)
plt.savefig('vrtilna_razlika.pdf',bbox_inches='tight')