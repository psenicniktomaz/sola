import numpy as np
from scipy.integrate import ode
import matplotlib.pyplot as plt


# Get current size
fig_size = plt.rcParams["figure.figsize"]
#print("Current size:", fig_size)
#Set figure width to 8 and height to 4.8
fig_size[0] = 8    #povečamo našo slikico (menda je osnova(6.4,4.8)
fig_size[1] = 6
plt.rcParams["figure.figsize"] = fig_size
#print("Current size:", fig_size)

v0=0.3
TT=15
def f(t,y):
    return [y[2], y[3], -y[0]/((y[0]*y[0] + y[1]*y[1])**(3/2))
        -(y[0] +TT -2*v0*t)/(((y[0] - 2*v0*t +TT)**2 + (y[1] - 1.5)**2)**(3/2)),
            -y[1]/((y[0]*y[0] + y[1]*y[1])**(3/2)) -
            (y[1]-1.5)/(((y[0] - 2*v0*t +TT)**2 + (y[1] - 1.5)**2)**(3/2))]

def jac(t,y):
    return [[0,0,1,0],
           [0,0,0,1],
           [(2*y[0]*y[0]-y[1]*y[1])/((y[0]*y[0]+y[1]*y[1])**(5/2)),3*y[0]*y[1]/((y[0]*y[0]+y[1]*y[1])**(5/2)),0,0],
           [(-y[0]*y[0]+2*y[1]*y[1])/((y[0]*y[0]+y[1]*y[1])**(5/2)),3*y[0]*y[1]/((y[0]*y[0]+y[1]*y[1])**(5/2)),0,0]]

dt=0.001
P0=[1,0,0,-v0] # x0,y0,u0,v0
x0=np.float(P0[0])
y0=np.float(P0[3])
t0=0

t1=TT/v0

r = ode(f).set_integrator("dopri5")
r.set_initial_value(P0, t0)

X = [P0[0]]
Y = [P0[1]]
U = [P0[2]]
V = [P0[3]]
t = [0]

while r.successful() and r.t < t1:
    r.integrate(r.t + dt)
    X.append(r.y[0])
    Y.append(r.y[1])
    U.append(r.y[2])
    V.append(r.y[3])
    t.append(r.t)

X = np.array(X)
Y = np.array(Y)
V = np.array(V)
U = np.array(U)
t=np.array(t)

plt.figure(0)
plt.plot(X,Y)
plt.quiver(1,0, 0, -1)
plt.xlabel('x')
plt.ylabel('y')
plt.plot(1,0,'o',color='black')
plt.plot(0,0,'o',color='yellow',markersize=20)
plt.grid()
plt.savefig('tri_telesa2_prva1.pdf')


### energija
T=0.5*(U**2 +V**2)
V1=1/np.sqrt(X**2 +Y**2)
V2=1/np.sqrt((X -2*v0*t +TT)**2 +(Y-1.5)**2)

plt.figure(1)
plt.xlabel('t')
plt.ylabel('"energija"')
plt.title('pozitivna smer kroženja v0=%s pri čas. koraku dt=%s' %(str(v0),str(dt)))
#plt.plot(t,T,label='kinetična',alpha=0.6)
#plt.plot(t,V1,label='pot. sr. zvezde',alpha=0.6)
plt.plot(t,T-V1,label='T-V1', alpha=0.6)
#plt.plot(t,T-V1-V2,label='E=T-V1-V2',alpha=0.6)
#plt.plot(t,T-V2,label='T-V2',alpha=0.6)
plt.legend(loc=0,prop={'size': 12}, borderaxespad=1,frameon=False)
plt.grid()
plt.savefig('tri_telesa2_druga1.pdf')
plt.show()