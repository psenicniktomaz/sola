import numpy as np
from scipy.integrate import ode
import matplotlib.pyplot as plt


# Get current size
fig_size = plt.rcParams["figure.figsize"]
#print("Current size:", fig_size)
#Set figure width to 8 and height to 4.8
fig_size[0] = 8    #povečamo našo slikico (menda je osnova(6.4,4.8)
fig_size[1] = 6
plt.rcParams["figure.figsize"] = fig_size
#print("Current size:", fig_size)

def f(t,y):
    return [y[2], y[3], -y[0]/((y[0]*y[0] + y[1]*y[1])**(3/2)),
            -y[1]/((y[0]*y[0] + y[1]*y[1])**(3/2))]

def jac(t,y):
    return [[0,0,1,0],
           [0,0,0,1],
           [(2*y[0]*y[0]-y[1]*y[1])/((y[0]*y[0]+y[1]*y[1])**(5/2)),3*y[0]*y[1]/((y[0]*y[0]+y[1]*y[1])**(5/2)),0,0],
           [(-y[0]*y[0]+2*y[1]*y[1])/((y[0]*y[0]+y[1]*y[1])**(5/2)),3*y[0]*y[1]/((y[0]*y[0]+y[1]*y[1])**(5/2)),0,0]]
dt=0.001
###### plot 1
P0=[1,0,0,0.7] # x0,y0,u0,v0
x0=np.float(P0[0])
y0=np.float(P0[3])
t0=0

t1=80

r = ode(f, jac).set_integrator("dopri5")
r.set_initial_value(P0, t0)

x = []
y = []
t = []

while r.successful() and r.t < t1:
    # print(r.t+dt, r.integrate(r.t+dt))
    r.integrate(r.t + dt)
    x.append(r.y[0])
    y.append(r.y[1])
    t.append(r.t)

x = np.array(x)
y = np.array(y)
dT = str(dt)

obhodi=[]
X=[]
k=0
for i in range(1,len(x)-1,1):
    if x[i] > 0 and y[i-1] < 0 and y[i+1] > 0:
        X.append(x[i])
        k+=1
        obhodi.append(k)
X=np.array(X)
X=np.abs(1-X)

plt.figure(0)
plt.semilogy(obhodi,X, label=' v=%s' % (str(P0[3])))
print('del z %s' % dT)



###### plot 2
P0=[1,0,0,1] # x0,y0,u0,v0
x0=np.float(P0[0])
y0=np.float(P0[3])
t0=0

t1=140

r = ode(f, jac).set_integrator("dopri5")
r.set_initial_value(P0, t0)

x = []
y = []
t = []

while r.successful() and r.t < t1:
    # print(r.t+dt, r.integrate(r.t+dt))
    r.integrate(r.t + dt)
    x.append(r.y[0])
    y.append(r.y[1])
    t.append(r.t)

x = np.array(x)
y = np.array(y)
dT = str(dt)

obhodi=[]
X=[]
k=0
for i in range(1,len(x)-1,1):
    if x[i] > 0 and y[i-1] < 0 and y[i+1] > 0:
        X.append(x[i])
        k+=1
        obhodi.append(k)
X=np.array(X)
X=np.abs(1-X)

plt.figure(0)
plt.semilogy(obhodi,X, label=' v=%s' % (str(P0[3])))
print('del z %s' % dT)


###### plot 3
P0=[1,0,0,1.3] # x0,y0,u0,v0
x0=np.float(P0[0])
y0=np.float(P0[3])
t0=0

t1=880

r = ode(f, jac).set_integrator("dopri5")
r.set_initial_value(P0, t0)

x = []
y = []
t = []

while r.successful() and r.t < t1:
    # print(r.t+dt, r.integrate(r.t+dt))
    r.integrate(r.t + dt)
    x.append(r.y[0])
    y.append(r.y[1])
    t.append(r.t)

x = np.array(x)
y = np.array(y)
dT = str(dt)

obhodi=[]
X=[]
k=0
for i in range(1,len(x)-1,1):
    if x[i] > 0 and y[i-1] < 0 and y[i+1] > 0:
        X.append(x[i])
        k+=1
        obhodi.append(k)
X=np.array(X)
X=np.abs(1-X)

plt.figure(0)
plt.semilogy(obhodi,X, label=' v=%s' % (str(P0[3])))
print('del z %s' % dT)

plt.figure(0)
#plt.grid()
plt.legend(loc=0,prop={'size': 12},frameon=False)
plt.xlabel('#. obhod')
plt.ylabel(r'|x$_{0}$ - x|')
plt.savefig('povratek2.pdf',bbox_inches='tight')