import numpy as np
from scipy.integrate import ode
import matplotlib.pyplot as plt


# Get current size
fig_size = plt.rcParams["figure.figsize"]
#print("Current size:", fig_size)
#Set figure width to 8 and height to 4.8
fig_size[0] = 8    #povečamo našo slikico (menda je osnova(6.4,4.8)
fig_size[1] = 6
plt.rcParams["figure.figsize"] = fig_size
#print("Current size:", fig_size)

def f(t,y):
    return [y[2], y[3], -y[0]/((y[0]*y[0] + y[1]*y[1])**(3/2)),
            -y[1]/((y[0]*y[0] + y[1]*y[1])**(3/2))]

def jac(t,y):
    return [[0,0,1,0],
           [0,0,0,1],
           [(2*y[0]*y[0]-y[1]*y[1])/((y[0]*y[0]+y[1]*y[1])**(5/2)),3*y[0]*y[1]/((y[0]*y[0]+y[1]*y[1])**(5/2)),0,0],
           [(-y[0]*y[0]+2*y[1]*y[1])/((y[0]*y[0]+y[1]*y[1])**(5/2)),3*y[0]*y[1]/((y[0]*y[0]+y[1]*y[1])**(5/2)),0,0]]

#plot 1
P0=[1,0,0,1] # x0,y0,u0,v0
x0=np.float(P0[0])
y0=np.float(P0[3])
t0=0

t1=100
dt=0.1

r=ode(f,jac).set_integrator("dopri5")
r.set_initial_value(P0, t0)



x=[]
y=[]
t=[]

while r.successful() and r.t < t1:
    #print(r.t+dt, r.integrate(r.t+dt))
    r.integrate(r.t+dt)
    x.append(r.y[0])
    y.append(r.y[1])
    t.append(r.t)

x=np.array(x)
y=np.array(y)
dT=str(dt)
razdalja= np.sqrt(x**2 +y**2)-1
plt.figure(0)
plt.semilogy(t,razdalja,label='dt=%s' %dT)
print('del z %s' %dT)



plt.figure(0)
plt.grid()
plt.xlabel('t')
plt.legend(bbox_to_anchor=(1.21, 1.),prop={'size': 12},frameon=False)
plt.savefig('samplefig.pdf',bbox_inches='tight')
