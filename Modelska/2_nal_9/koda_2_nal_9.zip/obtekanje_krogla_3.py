import numpy as np
import matplotlib.pyplot as plt

# in local panel
def normal_velocity(r_loc, r1,r2):
    l=np.sqrt(np.dot(r1-r2,r1-r2))
    if r_loc[1] == 0 and -l / 2 <= r_loc[0] <= l / 2:
        u = 0.5
    elif r_loc[1] == 0 and r_loc[0] < -l / 2:
        u = 0
    elif r_loc[1] == 0 and r_loc[0] > l / 2:
        u = 0
    else:
        a =(np.arctan((r_loc[0] + l / 2) / r_loc[1]) - np.arctan((r_loc[0] - l / 2) / r_loc[1]))
        u = (1 / (2 * np.pi))*a
    return u

# in local panel
def tangent_velocity(r_loc, r1,r2):
    l=np.sqrt(np.dot(r1-r2,r1-r2))
    b=np.log(((r_loc[0]+l/2)**2 +(r_loc[1])**2)/((r_loc[0] -l/2)**2 + (r_loc[1])**2))
    u = (1 / (4 * np.pi))*b
    return u


N=6 # number of panels
R_0=0.5 # radii of circle
a=1
b=1

#v_infty=[0.5,np.sqrt(3)/2] # vector o fluid speed at infinity
v_infty=[1,0] # vector o fluid speed at infinity
#v_infty=[0,1] # vector o fluid speed at infinity
#v_infty=[np.sqrt(2)/2,np.sqrt(2)/2] # vector o fluid speed at infinity

# creating nodes on a circle
h_phi=2*np.pi /N
phi=np.arange(0,2*np.pi +h_phi/2, h_phi)
x=a*R_0*np.cos(phi)
y=b*R_0*np.sin(phi)



R=[] # nodes of panels
M=len(x)
for i in range(M):
    R.append([x[i],y[i]])
R=np.array(R)
print('nodes:\n',R)

r=[] # mid points of panels
for i in range(M-1):
    r.append([(R[i][0]+R[i+1][0])/2,(R[i][1]+R[i+1][1])/2 ])
r=np.array(r)
print('midpoints of panels: \n',r)


# tangents of panels in clocwise direction; region is on the right
# list is in anti-clockwise series
t=[]
for i in range(M-1):
    l = np.sqrt(np.dot(R[i + 1] - R[i], R[i + 1] - R[i]))
    t.append([(R[i+1][0]- R[i][0])/l,(R[i+1][1]-R[i][1])/l])
t=-np.array(t)
print('tangents of panels\n',t)

# normals of panels in anti-clockwise direction
n=[]
for i in range(M-1):
    n.append([-t[i][1],t[i][0]])
n=np.array(n)
print('normals of panels\n',n)



# calculating Vij matrix
# local normal velocities on panels from v_infty
v_loc_n=[]
NN=[]
for i in range(M-1):
    v_loc_n.append(np.dot(v_infty,n[i]))
    NN.append((phi[i]+phi[i+1])/2)
v_loc_n=np.array(v_loc_n)
NN=np.array(NN)
print('local normal velocities\n',v_loc_n)

'''plt.figure(1)
plt.plot(NN,v_loc_n,'o-')
plt.xlabel(r'$\varphi$')
plt.ylabel(r'$v_{ \perp , Loc.}$')
plt.grid()'''

plt.figure(2)
plt.plot(R[:,0],R[:,1],'o-',markersize=2) # plots panels
plt.quiver(r[:,0],r[:,1],-v_loc_n[:]*n[:,0],-v_loc_n[:]*n[:,1])
plt.grid()
plt.axis('equal')



r_lab=np.array([1,0]) # first time programming
print('local vectors of point observation before rotation')
R_loc=[]
for j in range(M - 1):
    r_loc = r_lab - r[j]
    print('j=%d  ' %j,r_loc)
    R_loc.append([np.dot(r_loc,t[j]),np.dot(r_loc,n[j])])
R_loc=np.array(R_loc)
print('local vectors of point observation\n',R_loc)



'''V=np.zeros((M-1,M-1))
for i in range(1):
    for j in range(M-1):
        R_loc=r[i]-r[j]
        r_loc = [np.dot(R_loc,t[j]),
             np.dot(R_loc,n[j])]
        print('r_loc:',r_loc)
        v_normal =normal_velocity(r_loc, r1=R[j], r2=R[j+1])
        v_tangent= tangent_velocity(r_loc, r1=R[j], r2=R[j+1])
        v_loc=[v_tangent,v_normal]
        print('v_loc:',v_loc)
        v_lab=[np.dot(v_loc,t[i]),np.dot(v_loc,n[i])]
        print('v_lab:',v_lab)
        V[i][j]=np.dot(v_lab,n[i])

print('Matrix V:\n',V)
sigma=np.linalg.solve(V,-v_loc_n)
print('sigma:\n',sigma)

i=0
v_x=0
v_y=0
for j in range(M - 1):
    r_loc = r[i] - r[j]
    sin = t[j][1]
    cos = t[j][0]
    r_loc = [cos * r_loc[0] + sin * r_loc[1],
             -sin * r_loc[0] + cos * r_loc[1]]
    # print(r_loc)
    v_normal = normal_velocity(r_loc, r1=R[j], r2=R[j + 1])*sigma[j]
    # print(v_normal)
    v_tangent = tangent_velocity(r_loc, r1=R[j], r2=R[j + 1])*sigma[j]
    # print(v_tangent)
    v_loc = [v_tangent, v_normal]
    # print(v_loc)
    v_lab = [cos * v_loc[0] - sin * v_loc[1],
             +sin * v_loc[0] + cos * v_loc[1]]
    v_x_loc=np.dot(v_lab,n[i])
    v_y_loc=np.dot(v_lab,t[i])
    v_x += v_x_loc
    v_y += v_y_loc
    # print(v_lab)

print(v_x,v_y)'''
# calculating Vij matrix

V=np.zeros((M-1,M-1))
for i in range(1):
    for j in range(3,4,1):
        r_loc=r[i]-r[j]
        print('r_loc=',r_loc)
        sin=t[j][1]
        cos=t[j][0]
        r_loc = [cos * r_loc[0] +  sin* r_loc[1],
             -sin * r_loc[0] + cos * r_loc[1]]
        print('r_loc=',r_loc)
        v_normal =normal_velocity(r_loc=r_loc, r1=R[j], r2=R[j+1])
        print('v_normal=',v_normal)
        v_tangent= tangent_velocity(r_loc=r_loc, r1=R[j], r2=R[j+1])
        l=np.sqrt(np.dot(R[j]-R[j+1],R[j]-R[j+1]))
        #print('l=', l)
        #a =(np.arctan((r_loc[0] + l / 2) / r_loc[1]) - np.arctan((r_loc[0] - l / 2) / r_loc[1]))
        #vv=(1/(2*np.pi))*a
        #print('hitrost=',vv)
        v_loc=[v_tangent,v_normal]
        v_lab=[cos * v_loc[0] -  sin* v_loc[1],
             +sin * v_loc[0] + cos * v_loc[1]]
        V[i][j]=np.dot(v_lab,n[i])
        print('v_loc=',v_loc)
        print('v_lab=',v_lab)

print('Matrix V:\n',V)
#sigma=np.linalg.solve(V,-0.5*v_loc_n)
#print(sigma)


print(normal_velocity(r_loc=r_loc,r1=R[3],r2=R[4]))
plt.show()
'''m=103 # n+1 number of points aranged between -d and d
d=1.5
h=2*d/m
X=np.arange(-d,d+h/2,h)
Y=np.arange(-d,d+h/2,h)
RR=[]
for i in range(len(X)):
    for j in range(len(Y)):
        RR.append([X[i],Y[j]])
RR=np.array(RR)

# calculation of velocity in laboratory system
v=[]
for i in range(len(RR)):
    v_x=0
    v_y=0
    if (RR[i][0] / a) ** 2 + (RR[i][1] / b) ** 2 < R_0 ** 2:
        v.append([0, 0])
    else:
        for j in range(M-1):
            r_loc=RR[i]-r[j]
            sin=t[j][1]
            cos=t[j][0]
            r_loc = [cos * r_loc[0] +  sin* r_loc[1],
                 -sin * r_loc[0] + cos * r_loc[1]]
            v_normal =normal_velocity(r_loc, r1=R[j], r2=R[j+1])*sigma[j]
            v_tangent= tangent_velocity(r_loc, r1=R[j], r2=R[j+1])*sigma[j]
            v_loc=[v_tangent,v_normal]
            v_lab=[cos * v_loc[0] -  sin* v_loc[1],
                 +sin * v_loc[0] + cos * v_loc[1]]
            v_x+= v_lab[0]
            v_y+=v_lab[1]
        v.append([v_x +v_infty[0],v_y+v_infty[1]])
v=np.array(v)

plt.figure(0)
plt.tricontourf(RR[:,0],RR[:,1],np.sqrt(v[:,0]**2 +v[:,1]**2),levels=20)
plt.colorbar()
#plt.tricontour(RR[:,0],RR[:,1],np.sqrt(v[:,0]**2 +v[:,1]**2),levels=20)
plt.axis('equal')



m=21 # n+1 number of points aranged between -d and d
d=1.5
h=2*d/m
X=np.arange(-d,d+h/2,h)
Y=np.arange(-d,d+h/2,h)
RR=[]
for i in range(len(X)):
    for j in range(len(Y)):
        RR.append([X[i],Y[j]])
RR=np.array(RR)

# calculation of velocity in laboratory system
v=[]
for i in range(len(RR)):
    v_x=0
    v_y=0
    if (RR[i][0] / a) ** 2 + (RR[i][1] / b) ** 2 < R_0 ** 2:
        v.append([0, 0])
    else:
        for j in range(M-1):
            r_loc=RR[i]-r[j]
            sin=t[j][1]
            cos=t[j][0]
            r_loc = [cos * r_loc[0] +  sin* r_loc[1],
                 -sin * r_loc[0] + cos * r_loc[1]]
            v_normal =normal_velocity(r_loc, r1=R[j], r2=R[j+1])*sigma[j]
            v_tangent= tangent_velocity(r_loc, r1=R[j], r2=R[j+1])*sigma[j]
            v_loc=[v_tangent,v_normal]
            v_lab=[cos * v_loc[0] -  sin* v_loc[1],
                 +sin * v_loc[0] + cos * v_loc[1]]
            v_x+= v_lab[0]
            v_y+=v_lab[1]
        v.append([v_x +v_infty[0],v_y+v_infty[1]])
v=np.array(v)


plt.figure(0)
plt.quiver(RR[:,0],RR[:,1],v[:,0],v[:,1])
plt.axis('equal')
plt.show()'''