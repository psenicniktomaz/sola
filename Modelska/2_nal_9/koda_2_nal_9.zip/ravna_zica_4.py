import numpy as np
import matplotlib.pyplot as plt


NN=[50,75,100,150,200,250, 300, 400,800]# dobimo N-1 panelov
NNN=[]
charge_sum=[]
for N in NN:
    h=1/(N-1)

    def loc_green(r_loc, r1,r2): # nevermind if there is a warning divide by zero, calculates as it should
        l=np.sqrt(np.dot(r1-r2,r1-r2))
        a=r_loc[1]*(np.arctan((r_loc[0]+l/2)/r_loc[1])- np.arctan((r_loc[0]-l/2)/r_loc[1]))
        b=((r_loc[0]+l/2)/2)*np.log((r_loc[0]+l/2)**2 + r_loc[1]**2)
        c=((r_loc[0] -l/2)/2)*np.log((r_loc[0] -l/2)**2 + r_loc[1]**2)
        if r_loc[1]==0 and r_loc[0]+l/2 ==0 and r_loc[0] -l/2 !=0:
            u=(1/(2*np.pi))*(-l -c)
        elif r_loc[1] == 0 and r_loc[0] + l / 2 == 0 and r_loc[0] - l / 2 == 0:
            u = (1 / (2 * np.pi)) * (-l)
        elif r_loc[1] != 0 and r_loc[0] + l / 2 == 0 and r_loc[0] - l / 2 == 0:
            u = (1 / (2 * np.pi)) * (-l +a)
        elif r_loc[1] != 0 and r_loc[0] + l / 2 != 0 and r_loc[0] - l / 2 == 0:
            u = (1 / (2 * np.pi)) * (-l +a +b)
        elif r_loc[1] != 0 and r_loc[0] + l / 2 == 0 and r_loc[0] - l / 2 != 0:
            u = (1 / (2 * np.pi)) * (-l + a -c)
        elif r_loc[1] != 0 and r_loc[0] + l / 2 != 0 and r_loc[0] - l / 2 != 0:
            u = (1 / (2 * np.pi)) * (-l + a + b-c)
        elif r_loc[1] == 0 and r_loc[0] + l / 2 != 0 and r_loc[0] - l / 2 != 0:
            u = (1 / (2 * np.pi)) * (-l + b -c)
        elif r_loc[1] == 0 and r_loc[0] + l / 2 != 0 and r_loc[0] - l / 2 == 0:
            u = (1 / (2 * np.pi)) * (-l + b)
            '''u=(1/(2*np.pi))*(-l + r_loc[1]*(np.arctan((r_loc[0]+l/2)/r_loc[0])- np.arctan((r_loc[0]-l/2)/r_loc[0]))
                         +((r_loc[0]+l/2)/2)*np.log((r_loc[0]+l/2)**2 + r_loc[1]**2)
                         - ((r_loc[0] -l/2)/2)*np.log((r_loc[0] -l/2)**2 + r_loc[1]**2))'''
        return u

    # x and y nodes of panels
    # R vector of nodes

    x=np.arange(1,0 -h/2,-h)
    x=0.5*(np.cos(np.pi *x))
    y=[0]*N
    R=[]
    for i in range(N):
        R.append([x[i],y[i]])
    R=np.array(R)
    #print('nodes  of panels\n',R)


    # vector r of midpoints of panels
    r=[]
    for i in range(N-1):
        r.append([(x[i+1]+x[i])/2,(y[i+1]+y[i])/2])
    r=np.array(r)
    #print('mid points of panels\n',r)

    # phi of rotation
    phi=[]
    for i in range(N-1):
        phi.append(np.arctan((R[i+1][1]-R[i][1])/(R[i+1][0]-R[i][0])))
    phi=np.array(phi)
    #print('angles of panels',phi)

    #computing matrix G_ij
    G=np.zeros((N-1,N-1))
    for i in range(N-1):
        for j in range(N-1):
            r_loc=r[i]-r[j]
            r_loc = [np.cos(phi[j]) * r_loc[0] + np.sin(phi[j]) * r_loc[1],
                     -np.sin(phi[j]) * r_loc[0] + np.cos(phi[j]) * r_loc[1]]
            u_loc =loc_green(r_loc, r1=R[j], r2=R[j+1])
            G[i][j]=u_loc

    #print('matrix G_ij:\n',G)

    # charge density
    u=np.ones(N-1)
    sigma=np.dot(np.linalg.inv(G),u)

    plt.figure(1)
    plt.plot(r[:,0],sigma, label='N=%d' %N,alpha=0.5)

    plt.figure(2)
    charge=[]
    for i in range(len(sigma)):
        charge.append(sigma[i]*(np.abs(R[i][0]-R[i+1][0])))
    charge=np.array(charge)
    print(np.sum(charge))
    plt.plot(r[:,0],charge,label='N=%d' %N,alpha=0.5)

    charge_sum.append(np.sum(charge))
    NNN.append(N)

plt.figure(1)
plt.grid()
plt.xlabel(r'$ l $')
plt.ylabel(r'$ \sigma $')
plt.legend(loc=0,frameon=False)
plt.savefig('ravna_zica_4_sigma.pdf')

plt.figure(2)
plt.grid()
plt.xlabel(r'$l$')
plt.ylabel(r'$ \sigma_{i} /l_{i} $')
plt.legend(loc=0,frameon=False)
plt.savefig('ravna_zica_4_charge.pdf')

plt.figure(3)
plt.plot(NNN,charge_sum,'o-')
plt.grid()
plt.ylabel(r'$ naboj/dolzino  $')
plt.xlabel(r'N panelov')
plt.savefig('ravna_zica_4_naboj.pdf')