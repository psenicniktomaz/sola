import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec

w = 1
Y, X = np.mgrid[-w:w:5j, -w:w:5j]
print('Yje \n',Y)
print('X je \n',X)

U = -1 - X**2 + Y
print(U)
V = 1 + X - Y**2
print(V)

#  Varying density along a streamline
plt.figure(0)
plt.streamplot(X, Y, U, V)
plt.show()