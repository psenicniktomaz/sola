import numpy as np
import matplotlib.pyplot as plt

# in local panel
def normal_velocity(r_loc, r1,r2):
    l=np.sqrt(np.dot(r1-r2,r1-r2))
    if r_loc[1] == 0 and -l / 2 <= r_loc[0] <= l / 2:
        u = 0.5
    elif r_loc[1] == 0 and r_loc[0] < -l / 2:
        u = 0
    elif r_loc[1] == 0 and r_loc[0] > l / 2:
        u = 0
    else:
        a =(np.arctan((r_loc[0] + l / 2) / r_loc[1]) - np.arctan((r_loc[0] - l / 2) / r_loc[1]))
        u = (1 / (2 * np.pi))*a
    return u

# in local panel
def tangent_velocity(r_loc, r1,r2):
    l=np.sqrt(np.dot(r1-r2,r1-r2))
    b=np.log(((r_loc[0]+l/2)**2 +(r_loc[1])**2)/((r_loc[0] -l/2)**2 + (r_loc[1])**2))
    u = (1 / (4 * np.pi))*b
    return u

def loc_green(r_loc, r1,r2): # nevermind if there is a warning divide by zero, calculates as it should
    l=np.sqrt(np.dot(r1-r2,r1-r2))
    a=r_loc[1]*(np.arctan((r_loc[0]+l/2)/r_loc[1])- np.arctan((r_loc[0]-l/2)/r_loc[1]))
    b=((r_loc[0]+l/2)/2)*np.log((r_loc[0]+l/2)**2 + r_loc[1]**2)
    c=((r_loc[0] -l/2)/2)*np.log((r_loc[0] -l/2)**2 + r_loc[1]**2)
    if r_loc[1]==0 and r_loc[0]+l/2 ==0 and r_loc[0] -l/2 !=0:
        u=(1/(2*np.pi))*(-l -c)
    elif r_loc[1] == 0 and r_loc[0] + l / 2 == 0 and r_loc[0] - l / 2 == 0:
        u = (1 / (2 * np.pi)) * (-l)
    elif r_loc[1] != 0 and r_loc[0] + l / 2 == 0 and r_loc[0] - l / 2 == 0:
        u = (1 / (2 * np.pi)) * (-l +a)
    elif r_loc[1] != 0 and r_loc[0] + l / 2 != 0 and r_loc[0] - l / 2 == 0:
        u = (1 / (2 * np.pi)) * (-l +a +b)
    elif r_loc[1] != 0 and r_loc[0] + l / 2 == 0 and r_loc[0] - l / 2 != 0:
        u = (1 / (2 * np.pi)) * (-l + a -c)
    elif r_loc[1] != 0 and r_loc[0] + l / 2 != 0 and r_loc[0] - l / 2 != 0:
        u = (1 / (2 * np.pi)) * (-l + a + b-c)
    elif r_loc[1] == 0 and r_loc[0] + l / 2 != 0 and r_loc[0] - l / 2 != 0:
        u = (1 / (2 * np.pi)) * (-l + b -c)
    elif r_loc[1] == 0 and r_loc[0] + l / 2 != 0 and r_loc[0] - l / 2 == 0:
        u = (1 / (2 * np.pi)) * (-l + b)
    return u


N=99 # number of panels
R_0=0.5 # radii of circle
a=1.5
b=1

v_infty=[0,1] # vector o fluid speed at infinity


# creating nodes on a circle
h_phi=2*np.pi /N
phi=np.arange(0,2*np.pi +h_phi/2, h_phi)
x=a*R_0*np.cos(phi)
y=b*R_0*np.sin(phi)


R=[] # nodes of panels
M=len(x)
for i in range(M):
    R.append([x[i],y[i]])
R=np.array(R)
print('nodes:\n',R)


r=[] # mid points of panels
for i in range(M-1):
    r.append([(R[i][0]+R[i+1][0])/2,(R[i][1]+R[i+1][1])/2 ])
r=np.array(r)
print('midpoints of panels: \n',r)


# tangents of panels in clocwise direction; region is on the right
# list is in anti-clockwise series
t=[]
for i in range(M-1):
    l = np.sqrt(np.dot(R[i + 1] - R[i], R[i + 1] - R[i]))
    t.append([(R[i+1][0]- R[i][0])/l,(R[i+1][1]-R[i][1])/l])
t=-np.array(t)
print('tangents of panels\n',t)


# normals of panels in anti-clockwise direction
n=[]
for i in range(M-1):
    n.append([-t[i][1],t[i][0]])
n=np.array(n)
print('normals of panels\n',n)


# calculating Vij matrix
#######################################################

# local normal velocities on panels from v_infty
v_loc_n=[]
NN=[]
for i in range(M-1):
    v_loc_n.append(np.dot(v_infty,n[i]))
    NN.append((phi[i]+phi[i+1])/2)
v_loc_n=np.array(v_loc_n)
NN=np.array(NN)
print('local normal velocities \n',v_loc_n)


plt.figure(1)
plt.plot(NN,v_loc_n,'o-',markersize=3)
plt.xlabel(r'$\varphi$')
plt.ylabel(r'$v_{ \perp , Loc.}$')
plt.grid()
plt.savefig('obtekanje_valj_elipsa_1_vprav1.pdf')

plt.figure(2)
plt.plot(R[:,0],R[:,1],'o-',markersize=3) # plots panels
plt.grid()
plt.quiver(r[:,0],r[:,1],-v_loc_n[:]*n[:,0],-v_loc_n[:]*n[:,1])
plt.axis('equal')
plt.axis([-R_0*a*3/2,R_0*a*3/2, -R_0*b*3/2,R_0*b*3/2])
plt.savefig('obtekanje_valj_elipsa_1_vprav2.pdf')


# Matrix V

V=np.zeros((M-1,M-1))
for i in range(M-1):
    for j in range(M-1):
        r_loc=r[i]-r[j]
        sin=t[j][1]
        cos=t[j][0]
        print(cos, sin)
        r_loc = [cos * r_loc[0] +  sin* r_loc[1],
             -sin * r_loc[0] + cos * r_loc[1]]
        v_normal =normal_velocity(r_loc, r1=R[j], r2=R[j+1])
        v_tangent= tangent_velocity(r_loc, r1=R[j], r2=R[j+1])
        v_loc=[v_tangent,v_normal]
        v_lab=[cos * v_loc[0] -  sin* v_loc[1],
             +sin * v_loc[0] + cos * v_loc[1]]
        V[i][j]=np.dot(v_lab,n[i])

print('Matrix V:\n',V)
sigma=np.linalg.solve(V,-v_loc_n)
print('sigma:\n',sigma)

plt.figure(4)
plt.plot(NN,sigma,'o-',markersize=3)
plt.grid()
plt.xlabel(r'$\varphi$')
plt.ylabel(r'$ \sigma $')
plt.savefig('obtekanje_valj_elipsa_1_sigma.pdf')

#######################
# ploting velocity field using sigma

m=103 # n+1 number of points aranged between -d and d
d=2*R_0*a
h=2*d/m
X=np.arange(-d,d+h/2,h)
Y=np.arange(-d,d+h/2,h)
RR=[]
for i in range(len(X)):
    for j in range(len(Y)):
        RR.append([X[i],Y[j]])
RR=np.array(RR)

# calculation of velocity in laboratory system
# and calculation of velocity potential field
v=[]
U=[]
for i in range(len(RR)):
    v_x=0
    v_y=0
    u_loc = 0
    for j in range(M-1):
        r_loc=RR[i]-r[j]
        sin=t[j][1]
        cos=t[j][0]
        r_loc = [cos * r_loc[0] +  sin* r_loc[1],
             -sin * r_loc[0] + cos * r_loc[1]]
        v_normal =normal_velocity(r_loc, r1=R[j], r2=R[j+1])*sigma[j]
        v_tangent= tangent_velocity(r_loc, r1=R[j], r2=R[j+1])*sigma[j]
        v_loc=[v_tangent,v_normal]
        v_lab=[cos * v_loc[0] -  sin* v_loc[1],
             +sin * v_loc[0] + cos * v_loc[1]]
        v_x+= v_lab[0]
        v_y+=v_lab[1]
        u_loc = u_loc +loc_green(r_loc, r1=R[j], r2=R[j+1])*sigma[j]
    U.append(u_loc)
    v.append([v_x +v_infty[0],v_y+v_infty[1]])
v=np.array(v)
U=np.array(U)

plt.figure(0)
plt.tricontourf(RR[:,0],RR[:,1],np.sqrt(v[:,0]**2 +v[:,1]**2),levels=20,alpha=0.7)
plt.colorbar()
#plt.tricontour(RR[:,0],RR[:,1],np.sqrt(v[:,0]**2 +v[:,1]**2),levels=20)
plt.axis('equal')

plt.figure(3)
plt.tricontourf(RR[:,0],RR[:,1],U,levels=20)
plt.colorbar()
plt.tricontour(RR[:,0],RR[:,1],U,levels=20)
plt.plot(R[:,0],R[:,1],'-') # plots panels
plt.axis('equal')
plt.savefig('obtekanje_valj_elipsa_1_U.pdf')



####################################
# calculating the vector field --> arrows

m=31 # n+1 number of points aranged between -d and d
h=2*d/m
X=np.arange(-d,d+h/2,h)
Y=np.arange(-d,d+h/2,h)
RR=[]
for i in range(len(X)):
    for j in range(len(Y)):
        RR.append([X[i],Y[j]])
RR=np.array(RR)

# calculation of velocity in laboratory system
v=[]
for i in range(len(RR)):
    v_x=0
    v_y=0
    for j in range(M-1):
        r_loc=RR[i]-r[j]
        sin=t[j][1]
        cos=t[j][0]
        r_loc = [cos * r_loc[0] +  sin* r_loc[1],
             -sin * r_loc[0] + cos * r_loc[1]]
        v_normal =normal_velocity(r_loc, r1=R[j], r2=R[j+1])*sigma[j]
        v_tangent= tangent_velocity(r_loc, r1=R[j], r2=R[j+1])*sigma[j]
        v_loc=[v_tangent,v_normal]
        v_lab=[cos * v_loc[0] -  sin* v_loc[1],
                 +sin * v_loc[0] + cos * v_loc[1]]
        v_x+= v_lab[0]
        v_y+=v_lab[1]
    v.append([v_x +v_infty[0],v_y+v_infty[1]])
v=np.array(v)

plt.figure(0)
plt.quiver(RR[:,0],RR[:,1],v[:,0],v[:,1])
plt.axis('equal')
plt.savefig('obtekanje_valj_elipsa_1_v.pdf')