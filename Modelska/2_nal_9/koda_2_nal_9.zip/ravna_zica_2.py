import numpy as np
import matplotlib.pyplot as plt


N=100 # dobimo N-1 panelov
h=1/(N-1)

def loc_green(r_loc, r1,r2): # nevermind if there is a warning divide by zero, calculates as it should
    l=np.sqrt(np.dot(r1-r2,r1-r2))
    a=r_loc[1]*(np.arctan((r_loc[0]+l/2)/r_loc[1])- np.arctan((r_loc[0]-l/2)/r_loc[1]))
    b=((r_loc[0]+l/2)/2)*np.log((r_loc[0]+l/2)**2 + r_loc[1]**2)
    c=((r_loc[0] -l/2)/2)*np.log((r_loc[0] -l/2)**2 + r_loc[1]**2)
    if r_loc[1]==0 and r_loc[0]+l/2 ==0 and r_loc[0] -l/2 !=0:
        u=(1/(2*np.pi))*(-l -c)
    elif r_loc[1] == 0 and r_loc[0] + l / 2 == 0 and r_loc[0] - l / 2 == 0:
        u = (1 / (2 * np.pi)) * (-l)
    elif r_loc[1] != 0 and r_loc[0] + l / 2 == 0 and r_loc[0] - l / 2 == 0:
        u = (1 / (2 * np.pi)) * (-l +a)
    elif r_loc[1] != 0 and r_loc[0] + l / 2 != 0 and r_loc[0] - l / 2 == 0:
        u = (1 / (2 * np.pi)) * (-l +a +b)
    elif r_loc[1] != 0 and r_loc[0] + l / 2 == 0 and r_loc[0] - l / 2 != 0:
        u = (1 / (2 * np.pi)) * (-l + a -c)
    elif r_loc[1] != 0 and r_loc[0] + l / 2 != 0 and r_loc[0] - l / 2 != 0:
        u = (1 / (2 * np.pi)) * (-l + a + b-c)
    elif r_loc[1] == 0 and r_loc[0] + l / 2 != 0 and r_loc[0] - l / 2 != 0:
        u = (1 / (2 * np.pi)) * (-l + b -c)
    elif r_loc[1] == 0 and r_loc[0] + l / 2 != 0 and r_loc[0] - l / 2 == 0:
        u = (1 / (2 * np.pi)) * (-l + b)
        '''u=(1/(2*np.pi))*(-l + r_loc[1]*(np.arctan((r_loc[0]+l/2)/r_loc[0])- np.arctan((r_loc[0]-l/2)/r_loc[0]))
                     +((r_loc[0]+l/2)/2)*np.log((r_loc[0]+l/2)**2 + r_loc[1]**2)
                     - ((r_loc[0] -l/2)/2)*np.log((r_loc[0] -l/2)**2 + r_loc[1]**2))'''
    return u

# x and y nodes of panels
# R vector of nodes
x=np.arange(-0.5,0.5 +h/2,h)
y=[0]*N
R=[]
for i in range(N):
    R.append([x[i],y[i]])
R=np.array(R)
#print('nodes  of panels\n',R)


# vector r of midpoints of panels
r=[]
for i in range(N-1):
    r.append([(x[i+1]+x[i])/2,(y[i+1]+y[i])/2])
r=np.array(r)
#print('mid points of panels\n',r)

# phi of rotation
phi=[]
for i in range(N-1):
    phi.append(np.arctan((R[i+1][1]-R[i][1])/(R[i+1][0]-R[i][0])))
phi=np.array(phi)
#print('angles of panels',phi)

#computing matrix G_ij
G=np.zeros((N-1,N-1))
for i in range(N-1):
    for j in range(N-1):
        r_loc=r[i]-r[j]
        r_loc = [np.cos(phi[j]) * r_loc[0] + np.sin(phi[j]) * r_loc[1],
                 -np.sin(phi[j]) * r_loc[0] + np.cos(phi[j]) * r_loc[1]]
        u_loc =loc_green(r_loc, r1=R[0], r2=R[1])
        G[i][j]=u_loc

#print('matrix G_ij:\n',G)

'''plt.figure(1)
plt.imshow(G,cmap='gray')
plt.colorbar()
plt.show()'''

# charge density
u=np.ones(N-1)
sigma=np.dot(np.linalg.inv(G),u)
#print(sigma)

plt.figure(1)
plt.plot(r[:,0],sigma)

plt.figure(2)
charge=[]
for i in range(len(sigma)):
    charge.append(sigma[i]*(np.abs(R[i][0]-R[i+1][0])))
charge=np.array(charge)
plt.plot(r[:,0],charge)


n=30 # n+1 number of points aranged between -1 and 1
d=1
h=2*d/n
X=np.arange(-d,d+h/2,h)
Y=np.arange(-d,d+h/2,h)
RR=[]
for i in range(len(X)):
    for j in range(len(Y)):
        RR.append([X[i],Y[j]])
RR=np.array(RR)


# potential in laboratory system
U=[]
for i in range(len(RR)):
    u_loc=0
    for j in range(N-1):
        r_loc=RR[i]-r[j]
        r_loc = [np.cos(phi[j]) * r_loc[0] + np.sin(phi[j]) * r_loc[1],
                 -np.sin(phi[j]) * r_loc[0] + np.cos(phi[j]) * r_loc[1]]
        u_loc = u_loc +loc_green(r_loc, r1=R[j], r2=R[j+1])*sigma[j]
    U.append(u_loc)
U=np.array(U)





plt.figure(0)
plt.tricontour(RR[:,0],RR[:,1],U,levels=15)
plt.tricontourf(RR[:,0],RR[:,1],U,levels=15,alpha=0.7)
plt.colorbar()
plt.plot(x,y)


UU=np.zeros((n+1,n+1))
k=0
for i in range(n+1):
    for j in range(n+1):
        UU[i][j]=U[k]
        k+=1
print(UU)
gradx,grady=np.gradient(-UU)
print('grad x: \n',gradx)
print('grad y: \n',grady)

YY, XX=np.meshgrid(X,Y)
print('XX je \n',XX, '\n YY je \n',YY)
plt.figure(0)
plt.quiver(XX,YY,gradx,grady)
#plt.streamplot(YY[0],XX[:,0],grady,gradx)
plt.show()

