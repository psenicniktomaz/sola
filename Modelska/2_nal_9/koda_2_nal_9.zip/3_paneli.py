import numpy as np
import matplotlib.pyplot as plt

N=4 # dobimo N-1 panelov
h=1/(N-1)

def loc_green(r_loc, r1,r2): # nevermind if there is a warning divide by zero, calculates as it should
    l=np.sqrt(np.dot(r1-r2,r1-r2))
    a=r_loc[1]*(np.arctan((r_loc[0]+l/2)/r_loc[1])- np.arctan((r_loc[0]-l/2)/r_loc[1]))
    b=((r_loc[0]+l/2)/2)*np.log((r_loc[0]+l/2)**2 + r_loc[1]**2)
    c=((r_loc[0] -l/2)/2)*np.log((r_loc[0] -l/2)**2 + r_loc[1]**2)
    if r_loc[1]==0 and r_loc[0]+l/2 ==0 and r_loc[0] -l/2 !=0:
        u=(1/(2*np.pi))*(-l -c)
    elif r_loc[1] == 0 and r_loc[0] + l / 2 == 0 and r_loc[0] - l / 2 == 0:
        u = (1 / (2 * np.pi)) * (-l)
    elif r_loc[1] != 0 and r_loc[0] + l / 2 == 0 and r_loc[0] - l / 2 == 0:
        u = (1 / (2 * np.pi)) * (-l +a)
    elif r_loc[1] != 0 and r_loc[0] + l / 2 != 0 and r_loc[0] - l / 2 == 0:
        u = (1 / (2 * np.pi)) * (-l +a +b)
    elif r_loc[1] != 0 and r_loc[0] + l / 2 == 0 and r_loc[0] - l / 2 != 0:
        u = (1 / (2 * np.pi)) * (-l + a -c)
    elif r_loc[1] != 0 and r_loc[0] + l / 2 != 0 and r_loc[0] - l / 2 != 0:
        u = (1 / (2 * np.pi)) * (-l + a + b-c)
    elif r_loc[1] == 0 and r_loc[0] + l / 2 != 0 and r_loc[0] - l / 2 != 0:
        u = (1 / (2 * np.pi)) * (-l + b -c)
    elif r_loc[1] == 0 and r_loc[0] + l / 2 != 0 and r_loc[0] - l / 2 == 0:
        u = (1 / (2 * np.pi)) * (-l + b)
        '''u=(1/(2*np.pi))*(-l + r_loc[1]*(np.arctan((r_loc[0]+l/2)/r_loc[0])- np.arctan((r_loc[0]-l/2)/r_loc[0]))
                     +((r_loc[0]+l/2)/2)*np.log((r_loc[0]+l/2)**2 + r_loc[1]**2)
                     - ((r_loc[0] -l/2)/2)*np.log((r_loc[0] -l/2)**2 + r_loc[1]**2))'''
    return u

# x and y nodes of panels
# R vector of nodes

'''N=10 # dobimo N-1 panelov # it's only an example that works
h=1/(N-1)
x1=np.arange(-0.5,-0.25-h/2,h)
y1=-2*x1 -0.5
x2=np.arange(-0.25,0.25 -h/2,h)
y2=(len(x2))*[0]
y2=np.array(y2)
x3=np.arange(0.25,0.5,h)
y3=1.2*x3 -0.3
N=len(x)
x=np.concatenate((x1,x2))
y=np.concatenate((y1,y2))
x=np.concatenate((x,x3))
y=np.concatenate((y,y3))'''


R=[]
x=[-0.5,-0.25,0.25,0.5]
y=[0.5,0,0,0.3]

for i in range(N):
    R.append([x[i],y[i]])
R=np.array(R)
print('nodes  of panels\n',R)


# vector r of midpoints of panels
r=[]
for i in range(N-1):
    r.append([(x[i+1]+x[i])/2,(y[i+1]+y[i])/2])
r=np.array(r)
print('mid points of panels\n',r)

# r_lab laboratory system point of observation
r_lab=[1,0]

# phi of rotation
phi=[]
for i in range(N-1):
    phi.append(np.arctan((R[i+1][1]-R[i][1])/(R[i+1][0]-R[i][0])))
phi=np.array(phi)
print('angles of panels',phi)

# local vector r_loc , local system point of observation
r_loc=r_lab -r
for i in range(N-1):
    r_loc[i]=[np.cos(phi[i])* r_loc[i][0] + np.sin(phi[i])*r_loc[i][1],-np.sin(phi[i])* r_loc[i][0] + np.cos(phi[i])*r_loc[i][1]]
print('local vectors of point observation\n',r_loc)


u_loc=loc_green(r_loc[0],r1=R[0],r2=R[1])
print(u_loc)

n=100 # n+1 number of points aranged between -1 and 1
d=1
h=2*d/n
X=np.arange(-d,d+h/2,h)
Y=np.arange(-d,d+h/2,h)
RR=[]
for i in range(len(X)):
    for j in range(len(Y)):
        RR.append([X[i],Y[j]])
RR=np.array(RR)

# potential in laboratory system
U=[]
for i in range(len(RR)):
    u_loc=0
    for j in range(0,N-1,1):
        r_loc=RR[i]-r[j]
        r_loc = [np.cos(phi[j]) * r_loc[0] + np.sin(phi[j]) * r_loc[1],
                 -np.sin(phi[j]) * r_loc[0] + np.cos(phi[j]) * r_loc[1]]
        u_loc = u_loc +loc_green(r_loc, r1=R[j], r2=R[j+1])
    U.append(u_loc)
U=np.array(U)
'''U=[]
for i in range(len(RR)):
    r_loc=RR[i]-r[2]
    r_loc=[np.cos(phi[2])* r_loc[0] + np.sin(phi[2])*r_loc[1],-np.sin(phi[2])* r_loc[0] + np.cos(phi[2])*r_loc[1]]
    u_loc =loc_green(r_loc, r1=R[2], r2=R[3])
    U.append(u_loc)
U=np.array(U)'''


plt.figure(0)
plt.tricontour(RR[:,0],RR[:,1],U,levels=15)
plt.tricontourf(RR[:,0],RR[:,1],U,levels=15,alpha=0.7)
plt.colorbar()


plt.figure(0)
plt.plot(x,y)
plt.show()