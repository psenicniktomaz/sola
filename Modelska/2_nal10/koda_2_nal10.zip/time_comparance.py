import numpy as np
import matplotlib.pyplot as plt

f= open("sor.dat","r") #creating file
vrstice=[]
for line in f:
    fields = line.split("\t")
    vrstice.append(fields)
f.close()

vrstice.pop(0)
vrstice.pop(0)

for i in range(len(vrstice)): #samo spremenimo v ustrezni array
    vrstice[i][1]=np.float(vrstice[i][1])
    vrstice[i][0]=np.float(vrstice[i][0])
    vrstice[i][2]=np.float(vrstice[i][2])

sor=np.array(vrstice)
print(sor)

#### reading the second file #########

f= open("sor2.dat","r") #creating file
vrstice=[]
for line in f:
    fields = line.split("\t")
    vrstice.append(fields)
f.close()

vrstice.pop(0)
vrstice.pop(0)

for i in range(len(vrstice)): #samo spremenimo v ustrezni array
    vrstice[i][1]=np.float(vrstice[i][1])
    vrstice[i][0]=np.float(vrstice[i][0])
    vrstice[i][2]=np.float(vrstice[i][2])

sor2=np.array(vrstice)
print(sor2)


f= open("2dFFT_brezutezi_time.dat","r") #creating file
vrstice=[]
for line in f:
    fields = line.split("\t")
    vrstice.append(fields)
f.close()

vrstice.pop(0)
vrstice.pop(0)

for i in range(len(vrstice)): #samo spremenimo v ustrezni array
    vrstice[i][1]=np.float(vrstice[i][1])
    vrstice[i][0]=np.float(vrstice[i][0])

fft=np.array(vrstice)
print(fft)


plt.figure(0)
plt.semilogy(sor[:,0],sor[:,2],'o-',label='Jacobi')
plt.semilogy(sor2[:,0],sor2[:,2],'o-',label=r'SOR - $\omega=1.5$')
plt.semilogy(fft[:,0],fft[:,1],'o-',label='2dFFT')
plt.xlabel(r'#$N$')
plt.ylabel(r'time[s] (Log scale)')
plt.legend(loc=0,frameon=False)
plt.savefig('time_comparance1.pdf')
plt.figure(1)
plt.plot(sor[:,0],sor[:,1],'o-',label='Jacobi')
plt.plot(sor2[:,0],sor2[:,1],'o-',label=r'SOR - $\omega=1.5$')
plt.xlabel(r'#$N$')
plt.ylabel(r'#iteration')
plt.legend(loc=0,frameon=False)
plt.grid()
plt.savefig('time_comparance2.pdf')
