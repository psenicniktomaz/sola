import numpy as np
from scipy.fftpack import fft2, ifft2
import matplotlib.pyplot as plt


def lik(N):

    rho1=10
    rho2=1
    U=np.ones((N,N))*rho2


    k=0
    for i in range(int(N/5)):
        for j in range(2*int(N/5)+k,3*int(N/5)):
            U[i, j] = rho1
        k=k+1
        if k > N/5:
            break
    k=0
    for i in range(int(N/5)):
        for j in range(0,int(N/5)-k):
            U[i, j] = rho1
        k=k+1
        if k > N/5:
            break
    k=0
    for i in range(4*int(N/5),N):
        for j in range(int(N)-k-1,int(N)):
            U[i, j] = rho1
        k=k+1
        if k > N/5:
            break

    k=0
    for i in range(4*int(N/5),N):
        for j in range(2*int(N/5),2*int(N/5)+k+1):
            U[i, j] = rho1
        k=k+1
        if k > N/5:
            break

    for i in range(2*int(N/5),N):
        for j in range(int(N/5),2*int(N/5)):
            U[i, j] = rho1

    for i in range(3*int(N/5)):
        for j in range(3*int(N/5),4*int(N/5)):
            U[i, j] = rho1
    return U

N=20 #works for %5==0
h=1/(N)

# b is region region
b1=lik(N)
B1=np.hstack((np.flip(-b1,axis=0),b1))
B2=np.hstack((b1,np.flip(-b1,axis=1)))
b=np.vstack((B1,B2))
print(b)
plt.figure(0)
plt.imshow(b,cmap='gray')
plt.colorbar()
plt.show()

# x_delta and y_delta

x_delta=np.zeros(N+1)
x_delta[0]=h/2; x_delta[N]=h/2
for i in range(1,N,1):
    x_delta[i]=h
y_delta=x_delta


x=[0]
for i in range(1,N,1):
    x.append(x[i-1] + x_delta[i-1])
x=np.array(x)


print(x)
x1=np.arange(h/2, 1, h)
x2=-np.flip(x1)
x=np.concatenate((x2,x1))
print(x)

X,Y=np.meshgrid(x,np.flip(x))


###########################
### 2dFFT  ###

h=1/(N)
B=fft2(b)
U=np.zeros((2*N, 2*N),dtype=complex)
for m in range(0,2*N,1):
    for n in range(0, 2 * N, 1):
        if m==0 and n==0:
            continue
        else:
            U[m,n]=(h**2)*B[m][n]/(2*(np.cos(2*np.pi*m/(2*N))+np.cos(2*np.pi*n/(2*N)))-4)
for m in range(1,2*N,1):
    for n in range(1,2*N,1):
        U[0][0]-=U[m][n]

u=ifft2(U)

plt.figure(1)
plt.contourf(X,Y,np.abs(u),levels=20)
plt.colorbar()
'''plt.xlim(0,x[2*N])
plt.ylim((0,x[2*N]))
plt.tight_layout()'''
plt.axis('equal')
plt.show()