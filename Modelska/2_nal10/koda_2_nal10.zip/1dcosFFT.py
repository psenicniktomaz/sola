import numpy as np
from scipy.fftpack import fft,ifft, dct, idct
import matplotlib.pyplot as plt


N=101 #only odd numbers
h=1/(N-1)
x=np.arange(0,1+h/2,h)
print(x)

b=np.zeros(N-2)
print(b)

# SOR
u=np.ones(N)
u[0]=1 ; u[N-1]=1
S=np.sum(u)
S_last=1
iteracija=0
#while np.abs(S_last -S) > 0.01:
for k in range(50000):
    S_last=S
    for i in range(N-2):
        u[i+1]=((h**2)*b[i] + u[i] +u[i+2])/2
    S_last=np.sum(u)
    iteracija+=1
    #print(iteracija)
plt.figure(0)
plt.grid()
plt.plot(x,u)
plt.show()

'''B=np.zeros(N,dtype=complex)
for m in range(N):
    for k in range(N):
        B[m]+=np.cos(np.pi*m*k/N)*b[k]
B=dct(b, type=1)
print(B)

U=np.zeros(N,dtype=complex)
for i in range(1,N,1):
    U[i]=(h**2)*B[i]/(2*np.cos(2*np.pi*i/N)-2)
for i in range(1,N,1):
    U[0]-=U[i]

u=np.zeros(N,dtype=complex)
for m in range(N):
    for k in range(N):
        u[m]+=np.cos(np.pi*m*k/N)*U[k]/N
u=idct(U,type=1)


plt.figure(1)
plt.grid()
plt.plot(x,u)
plt.show()'''