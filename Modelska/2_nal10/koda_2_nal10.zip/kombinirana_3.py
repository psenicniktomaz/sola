import numpy as np
from scipy.fftpack import fft2, ifft2
import matplotlib.pyplot as plt


def lik(N):

    rho1=10
    rho2=1
    U=np.ones((N,N))*rho2


    k=0
    for i in range(int(N/5)):
        for j in range(2*int(N/5)+k,3*int(N/5)):
            U[i, j] = rho1
        k=k+1
        if k > N/5:
            break
    k=0
    for i in range(int(N/5)):
        for j in range(0,int(N/5)-k):
            U[i, j] = rho1
        k=k+1
        if k > N/5:
            break
    k=0
    for i in range(4*int(N/5),N):
        for j in range(int(N)-k-1,int(N)):
            U[i, j] = rho1
        k=k+1
        if k > N/5:
            break

    k=0
    for i in range(4*int(N/5),N):
        for j in range(2*int(N/5),2*int(N/5)+k+1):
            U[i, j] = rho1
        k=k+1
        if k > N/5:
            break

    for i in range(2*int(N/5),N):
        for j in range(int(N/5),2*int(N/5)):
            U[i, j] = rho1

    for i in range(3*int(N/5)):
        for j in range(3*int(N/5),4*int(N/5)):
            U[i, j] = rho1
    return U

N=100 #works for %5==0
h=1/(N+2)

# b1 is inner region region
b1=lik(N)

# adding outer region
b=np.zeros((N+2,N+2))
for i in range(N):
    for j in range(N):
        b[i+1][j+1]=b1[i][j]

'''for i in range(N):
    b[0][i+1]= b[1][i+1]
    b[N+1][i+1]=b[N][i+1]
    b[i+1][0]=b[i+1][1]
    b[i+1][N+1]=b[i+1][N]
b[0][0]=b[1][0]
b[0][N+1]=b[1][N+1]
b[N+1][0]=b[N][0]
b[N+1][N+1]=b[N+1][N]'''
for i in range(N+2):
    b[0][i]=0
    b[N+1][i]=0
    b[0][i]=0
    b[N+1][i]=0

######## we got the b matrix


#
B=np.zeros((N+2,N+2))
for k in range(N+2):
    for m in range(N + 2):
        for j in range(N+2):
            B[m][k]+=2*np.sin(np.pi *m*j/(N+2))*b[j][k]



U=np.ones((N+2,N+2))*B
u=np.ones((N+2,N+2))*B


iteracija=0
for n in range(5000):
    for m in range(N+2):
        for k in range(N):
            u[m][k + 1] = ((h ** 2) * B[m][k+1] +U[m][k]+U[m][k+2])/ (4-2*np.cos((m)*np.pi/(N+2)))
    iteracija+=1
    print(iteracija)
    U=u

# inverse sine transform

b=np.zeros((N+2,N+2))
for k in range(N+2):
    for m in range(N + 2):
        for j in range(N+2):
            b[m][k]+=np.sin(np.pi *m*j/(N+2))*U[j][k]/(N+2)



h=1/(N+1)
x=np.arange(0,1+h/2,h)
X,Y=np.meshgrid(x,np.flip(x))

plt.figure(4)
plt.contourf(X,Y,b,levels=20)
plt.colorbar()
plt.axis('equal')
plt.savefig('kombinirana_3.pdf')