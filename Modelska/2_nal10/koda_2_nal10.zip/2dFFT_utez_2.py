import numpy as np
from scipy.fftpack import fft2, ifft2
import matplotlib.pyplot as plt


def lik(N):

    rho1=1
    rho2=10
    U=np.ones((N,N))*rho2


    k=0
    for i in range(int(N/5)):
        for j in range(2*int(N/5)+k,3*int(N/5)):
            U[i, j] = rho1
        k=k+1
        if k > N/5:
            break
    k=0
    for i in range(int(N/5)):
        for j in range(0,int(N/5)-k):
            U[i, j] = rho1
        k=k+1
        if k > N/5:
            break
    k=0
    for i in range(4*int(N/5),N):
        for j in range(int(N)-k-1,int(N)):
            U[i, j] = rho1
        k=k+1
        if k > N/5:
            break

    k=0
    for i in range(4*int(N/5),N):
        for j in range(2*int(N/5),2*int(N/5)+k+1):
            U[i, j] = rho1
        k=k+1
        if k > N/5:
            break

    for i in range(2*int(N/5),N):
        for j in range(int(N/5),2*int(N/5)):
            U[i, j] = rho1

    for i in range(3*int(N/5)):
        for j in range(3*int(N/5),4*int(N/5)):
            U[i, j] = rho1
    return U

N=200 #works for %5==0
h=1/(N)

# b is region region
b1=lik(N)
Oh=np.zeros((1,N+2)) # horizontal zeros
Ov=np.zeros((N,1)) # vertical zeros
B1=np.hstack((Ov,b1,Ov))
B1=np.vstack((Oh,B1,Oh))
for i in range(N):
    B1[i+1][0]=B1[i+1][1]
    B1[i+1][N+1]=B1[i+1][N]
for i in range(N+2):
    B1[0][i]=B1[1][i]
    B1[N+1][i]=B1[N][i]




b1=np.hstack((-np.flip(B1,axis=0),B1))
b2=np.hstack((B1,-np.flip(B1,axis=1)))
b=-np.vstack((b1,b2))
print(b)
'''plt.figure(0)
plt.imshow(b,cmap='gray')
plt.colorbar()
plt.savefig('2dFFT_utez_2_lik.pdf')'''

# x_delta and y_delta

h=1/(N+2)
x1=np.arange(h/N,1,h)
x2=-np.flip(x1)
x=np.concatenate((x2,x1))
print(x)
print(len(x))

X,Y=np.meshgrid(x,np.flip(x))


###########################
### 2dFFT  ###

h=1/(N+2)
B=fft2(b)
U=np.zeros((2*N+4, 2*N+4),dtype=complex)
for m in range(0,2*N+4,1):
    for n in range(0, 2 * N + 4, 1):
        if m==0 and n==0:
            continue
        else:
            U[m,n]=(h**2)*B[m][n]/(2*(np.cos(2*np.pi*m/(2*N+4))+np.cos(2*np.pi*n/(2*N+4)))-4)
for m in range(1,2*N+4,1):
    for n in range(1,2*N+4,1):
        U[0][0]-=U[m][n]

u=ifft2(U)
print(u)
plt.figure(1)
plt.contourf(X,Y,u,levels=20)
plt.colorbar()
plt.axis('equal')
plt.savefig('2dFFT_utez_2_1.pdf')


plt.figure(2)
plt.contourf(X,Y,np.abs(u),levels=20)
plt.colorbar()
plt.xlim(0,x[2*N+3])
plt.ylim((0,x[2*N+3]))
plt.tight_layout()
plt.savefig('2dFFT_utez_2_2.pdf')