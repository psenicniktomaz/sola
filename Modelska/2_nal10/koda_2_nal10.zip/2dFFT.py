import numpy as np
from scipy.fftpack import fft2, ifft2
import matplotlib.pyplot as plt


def lik(N):

    rho1=1
    rho2=10
    U=np.ones((N,N))*rho2


    k=0
    for i in range(int(N/5)):
        for j in range(2*int(N/5)+k,3*int(N/5)):
            U[i, j] = rho1
        k=k+1
        if k > N/5:
            break
    k=0
    for i in range(int(N/5)):
        for j in range(0,int(N/5)-k):
            U[i, j] = rho1
        k=k+1
        if k > N/5:
            break
    k=0
    for i in range(4*int(N/5),N):
        for j in range(int(N)-k-1,int(N)):
            U[i, j] = rho1
        k=k+1
        if k > N/5:
            break

    k=0
    for i in range(4*int(N/5),N):
        for j in range(2*int(N/5),2*int(N/5)+k+1):
            U[i, j] = rho1
        k=k+1
        if k > N/5:
            break

    for i in range(2*int(N/5),N):
        for j in range(int(N/5),2*int(N/5)):
            U[i, j] = rho1

    for i in range(3*int(N/5)):
        for j in range(3*int(N/5),4*int(N/5)):
            U[i, j] = rho1
    return U

N=100 #works for %5==0
h=1/(N)

# b is region region
b1=lik(N)
b2=-lik(N)
Oh=np.zeros((1,2*N+3)) # horizontal zeros
Ov=np.zeros((N,1)) # vertical zeros
B1=np.hstack((Ov,np.flip(b2,axis=0),Ov,b1,Ov))
B2=np.hstack((Ov,b1,Ov,np.flip(b2,axis=1),Ov))
b=np.vstack((Oh,B1,Oh,B2,Oh))

'''plt.figure(0)
plt.imshow(b,cmap='gray')
plt.colorbar()
plt.show()'''

# x_delta and y_delta


x_delta=np.zeros(N+1)
x_delta[0]=h/2; x_delta[N]=h/2
for i in range(1,N,1):
    x_delta[i]=h
y_delta=x_delta


x=[0]
for i in range(1,N+2,1):
    x.append(x[i-1] + x_delta[i-1])
x=np.array(x)


x1=x
x2=-np.flip(np.delete(x,0))
x=np.concatenate((x2,x1))


X,Y=np.meshgrid(x,np.flip(x))


###########################
### 2dFFT  ###

h=1/(N+2)
B=fft2(b)
U=np.zeros((2*N+3, 2*N+3),dtype=complex)
for m in range(0,2*N+3,1):
    for n in range(0, 2 * N + 3, 1):
        if m==0 and n==0:
            continue
        else:
            U[m,n]=(h**2)*B[m][n]/(2*(np.cos(2*np.pi*m/(2*N+3))+np.cos(2*np.pi*n/(2*N+3)))-4)
for m in range(1,2*N+3,1):
    for n in range(1,2*N+3,1):
        U[0][0]-=U[m][n]
#U[0][0]=2*N+3
print(U)

u=ifft2(U)

plt.figure(1)
plt.contourf(X,Y,np.abs(u),levels=20)
#plt.axis('equal')
plt.colorbar()
plt.xlim(0,1)
plt.ylim((0,1))
plt.tight_layout()
#plt.show()
plt.savefig('2dFFT%d.pdf'%N)


'''omega=1.5
u=np.abs(u)
S=np.sum(u)
S_last=1
iteracija=0
while np.abs(S - S_last) > 0.000001 * (N ** 2):
#for m in range(100):
    S=S_last
    U=np.array(u)
    for i in range(N):
        for j in range(N):
            # first corners of matrix u:
            if i==0 and j==0:
                u[i+1][j+1]=((h**2)*-b[j][i] + u[j][i+1] + u[j+1][i] + u[j+2][i+1] + u[j+1][i+2])/6
            elif i==0 and j==N-1:
                u[i+1][j+1]=((h**2)*-b[j][i] + u[j][i+1] + u[j+1][i] + u[j+2][i+1] + u[j+1][i+2])/6
            elif i==N-1 and j==0:
                u[i+1][j+1]=((h**2)*-b[j][i] + u[j][i+1] + u[j+1][i] + u[j+2][i+1] + u[j+1][i+2])/6
            elif i==N-1 and j==N-1:
                u[i+1][j+1]=((h**2)*-b[j][i] + u[j][i+1] + u[j+1][i] + u[j+2][i+1] + u[j+1][i+2])/6

            # edges of matrix u
            if i==0 and 0<j<N-1:
                u[i+1][j+1]=((h**2)*-b[j][i] + u[j][i+1] + u[j+1][i] + u[j+2][i+1] + u[j+1][i+2])/5
            elif i==N and 0 <j<N-1:
                u[i+1][j+1]=((h**2)*-b[j][i] + u[j][i+1] + u[j+1][i] + u[j+2][i+1] + u[j+1][i+2])/5
            elif 0<i<N-1 and j==0:
                u[i+1][j+1]=((h**2)*-b[j][i] + u[j][i+1] + u[j+1][i] + u[j+2][i+1] + u[j+1][i+2])/5
            elif 0<i<N-1 and j==N-1:
                u[i+1][j+1]=((h**2)*-b[j][i] + u[j][i+1] + u[j+1][i] + u[j+2][i+1] + u[j+1][i+2])/5

            #everything else
            else:
                   u[i+1][j+1]=((h**2)*-b[j][i] + u[j][i+1] + u[j+1][i] + u[j+2][i+1] + u[j+1][i+2])/4
    u=U +omega*(u -U)
    iteracija +=1
    print(iteracija)
    S_last=np.sum(u)

plt.figure(2)
plt.contourf(X,Y,u,levels=20)
plt.colorbar()
plt.axis('equal')
plt.savefig('2dFFT_sor%d.pdf'%N)'''