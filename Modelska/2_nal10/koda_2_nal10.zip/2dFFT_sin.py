import numpy as np
import matplotlib.pyplot as plt


def lik(N):

    rho1=1
    rho2=1
    U=np.ones((N,N))*rho2


    k=0
    for i in range(int(N/5)):
        for j in range(2*int(N/5)+k,3*int(N/5)):
            U[i, j] = rho1
        k=k+1
        if k > N/5:
            break
    k=0
    for i in range(int(N/5)):
        for j in range(0,int(N/5)-k):
            U[i, j] = rho1
        k=k+1
        if k > N/5:
            break
    k=0
    for i in range(4*int(N/5),N):
        for j in range(int(N)-k-1,int(N)):
            U[i, j] = rho1
        k=k+1
        if k > N/5:
            break

    k=0
    for i in range(4*int(N/5),N):
        for j in range(2*int(N/5),2*int(N/5)+k+1):
            U[i, j] = rho1
        k=k+1
        if k > N/5:
            break

    for i in range(2*int(N/5),N):
        for j in range(int(N/5),2*int(N/5)):
            U[i, j] = rho1

    for i in range(3*int(N/5)):
        for j in range(3*int(N/5),4*int(N/5)):
            U[i, j] = rho1
    return U

N=100 #works for %5==0
h=1/(N)

b=lik(N)
Oh=np.zeros((1,N+2)) # horizontal zeros
Ov=np.zeros((N,1)) # vertical zeros
b=np.hstack((Ov,b,Ov))
b=np.vstack((Oh,b,Oh))

#print(b)

'''plt.figure(0)
plt.imshow(b,cmap='gray')
plt.colorbar()
plt.show()'''


# x_delta and y_delta
x_delta=np.zeros(N+1)
x_delta[0]=h/2; x_delta[N]=h/2
for i in range(1,N,1):
    x_delta[i]=h
y_delta=x_delta

x=[0]
for i in range(1,N+2,1):
    x.append(x[i-1] + x_delta[i-1])
x=np.array(x)
X,Y=np.meshgrid(x,np.flip(x))

###########################
### 2dFFT sin  ###

h=1/(N+1)
B=np.zeros((N+2,N+2),dtype=complex)
i=0
for m in range(1,N+1,1):
    for n in range(1,N+1,1):
        for j in range(1,N+1,1):
            for k in range(1,N+1,1):
                B[m][n]+=4*np.sin(np.pi*m*j/(N+1))*b[j][k]*np.sin(np.pi*n*k/(N+1))
                i += 1
                print('prva zanka %d' % i)
print(B)

U=np.zeros((N+2,N+2),dtype=complex)
for m in range(1,N+1,1):
    for n in range(1,N+1,1):
        U[m][n]=(h**2)*B[m][n]/(2*(np.cos(2*np.pi*m/(N+1)) +np.cos(2*np.pi*n/(N+1)))-4)

print(U)
i=0
u=np.zeros((N+2,N+2),dtype=complex)
for m in range(1,N+1,1):
    for n in range(1,N+1,1):
        for j in range(1,N+1,1):
            for k in range(1,N+1,1):
                u[m][n]+=4*np.sin(np.pi*m*j/(N+1))*U[j][k]*np.sin(np.pi*n*k/(N+1))/((N+2)**2)
                i += 1
                print('druga zanka %d' % i)

plt.figure(1)
plt.contourf(X,Y,u,levels=20)
plt.colorbar()
plt.axis('equal')
plt.savefig('2dFFT_sin_%d.pdf' %N)