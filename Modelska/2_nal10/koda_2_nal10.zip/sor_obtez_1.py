import numpy as np
import matplotlib.pyplot as plt


def lik(N):

    rho1=10
    rho2=1
    U=np.ones((N,N))*rho2


    k=0
    for i in range(int(N/5)):
        for j in range(2*int(N/5)+k,3*int(N/5)):
            U[i, j] = rho1
        k=k+1
        if k > N/5:
            break
    k=0
    for i in range(int(N/5)):
        for j in range(0,int(N/5)-k):
            U[i, j] = rho1
        k=k+1
        if k > N/5:
            break
    k=0
    for i in range(4*int(N/5),N):
        for j in range(int(N)-k-1,int(N)):
            U[i, j] = rho1
        k=k+1
        if k > N/5:
            break

    k=0
    for i in range(4*int(N/5),N):
        for j in range(2*int(N/5),2*int(N/5)+k+1):
            U[i, j] = rho1
        k=k+1
        if k > N/5:
            break

    for i in range(2*int(N/5),N):
        for j in range(int(N/5),2*int(N/5)):
            U[i, j] = rho1

    for i in range(3*int(N/5)):
        for j in range(3*int(N/5),4*int(N/5)):
            U[i, j] = rho1
    return U

omega=1
N=100 #works for %5==0


h=1/N

b=lik(N)


plt.figure(0)
plt.imshow(b,cmap='gray')
plt.colorbar()
plt.savefig('sor_obtez_1_lik.pdf')

# x_delta and y_delta

h=1/(N)
x_delta=np.zeros(N+1)
x_delta[0]=h/2; x_delta[N]=h/2
for i in range(1,N,1):
    x_delta[i]=h
y_delta=x_delta


x=[0]
for i in range(1,N+2,1):
    x.append(x[i-1] + x_delta[i-1])
x=np.array(x)
X,Y=np.meshgrid(x,np.flip(x))


###########################
### SOR  ###

u=np.ones((N+2,N+2))
for i in range(N+2):
    u[0][i]=0
    u[i][0]=0
    u[N+1][i]=0
    u[i][N+1]=0

S=np.sum(u)
S_last=1
iteracija=0
while np.abs(S - S_last) > 0.0000001 * (N ** 2):
#for m in range(8000):
    S = S_last
    U = np.array(u)
    for i in range(N):
        for j in range(N):
            # first corners of matrix u:
            if i == 0 and j == 0:
                u[i + 1][j + 1] = ((h ** 2) * b[i][j] + U[i + 2][j + 1] + U[i + 1][j + 2]) / 6
            elif i == 0 and j == N - 1:
                u[i + 1][j + 1] = ((h ** 2) * b[i][j] + U[i + 1][j] + U[i + 2][j + 1]) / 6
            elif i == N - 1 and j == 0:
                u[i + 1][j + 1] = ((h ** 2) * b[i][j] + U[i][j + 1] + U[i + 1][j + 2]) / 6
            elif i == N - 1 and j == N - 1:
                u[i + 1][j + 1] = ((h ** 2) * b[i][j] + U[i][j + 1] + U[i + 1][j]) / 6
            # edges of matrix u
            elif i == 0 and 0 < j < N - 1:
                u[i + 1][j + 1] = ((h ** 2) * b[i][j] + U[i + 1][j] + U[i + 2][j + 1] + U[i + 1][j + 2]) / 5
            elif i == N - 1 and 0 < j < N - 1:
                u[i + 1][j + 1] = ((h ** 2) * b[i][j] + U[i][j + 1] + U[i + 1][j] + U[i + 1][j + 2]) / 5
            elif 0 < i < N - 1 and j == 0:
                u[i + 1][j + 1] = ((h ** 2) * b[i][j] + U[i][j + 1] + U[i + 2][j + 1] + U[i + 1][j + 2]) / 5
            elif 0 < i < N - 1 and j == N - 1:
                u[i + 1][j + 1] = ((h ** 2) * b[i][j] + U[i][j + 1] + U[i + 1][j] + U[i + 2][j + 1]) / 5
            # everything else
            else:
                u[i + 1][j + 1] = ((h ** 2) * b[i][j] + U[i][j + 1] + U[i + 2][j + 1] + U[i + 1][j] + U[i + 1][
                    j + 2]) / 4
    u=U +omega*(u -U)
    iteracija +=1
    print(iteracija)
    S_last=np.sum(u)

plt.figure(1)
plt.contourf(X,Y,u,levels=20)
plt.colorbar()
plt.axis('equal')
plt.savefig('sor_obtez_1.pdf')
