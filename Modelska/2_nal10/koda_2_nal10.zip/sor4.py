import numpy as np
import matplotlib.pyplot as plt

f= open("sor4.dat","w+") #creating file
f.write("#omega=1.6\n")
f.write("#N\t#iteracija\n")
f.close() # closing file

def lik(N):

    rho1=10
    rho2=1
    U=np.ones((N,N))*rho2


    k=0
    for i in range(int(N/5)):
        for j in range(2*int(N/5)+k,3*int(N/5)):
            U[i, j] = rho1
        k=k+1
        if k > N/5:
            break
    k=0
    for i in range(int(N/5)):
        for j in range(0,int(N/5)-k):
            U[i, j] = rho1
        k=k+1
        if k > N/5:
            break
    k=0
    for i in range(4*int(N/5),N):
        for j in range(int(N)-k-1,int(N)):
            U[i, j] = rho1
        k=k+1
        if k > N/5:
            break

    k=0
    for i in range(4*int(N/5),N):
        for j in range(2*int(N/5),2*int(N/5)+k+1):
            U[i, j] = rho1
        k=k+1
        if k > N/5:
            break

    for i in range(2*int(N/5),N):
        for j in range(int(N/5),2*int(N/5)):
            U[i, j] = rho1

    for i in range(3*int(N/5)):
        for j in range(3*int(N/5),4*int(N/5)):
            U[i, j] = rho1
    return U

omega=1.6
NN=[100] #works for %5==0


for N in NN:
    h=1/N

    b=lik(N)
    Q=np.zeros((N+2,N+2))
    for i in range(N):
        for j in range(N):
            Q[i+1][j+1]=b[i][j]

    '''plt.figure(0)
    plt.imshow(Q,cmap='gray')
    plt.colorbar()
    plt.show()'''

    # x_delta and y_delta

    h=1/(N)
    x_delta=np.zeros(N+1)
    x_delta[0]=h/2; x_delta[N]=h/2
    for i in range(1,N,1):
        x_delta[i]=h
    y_delta=x_delta


    x=[0]
    for i in range(1,N+2,1):
        x.append(x[i-1] + x_delta[i-1])
    x=np.array(x)
    X,Y=np.meshgrid(x,np.flip(x))


    ###########################
    ### SOR  ###

    u=np.ones((N+2,N+2))
    for i in range(N+2):
        u[0][i]=0
        u[i][0]=0
        u[N+1][i]=0
        u[i][N+1]=0

    S=np.sum(u)
    S_last=1
    iteracija=0
    while np.abs(S-S_last)> 0.0001:
        S=S_last
        U=np.array(u)
        for i in range(N):
            for j in range(N):
                # first corners of matrix u:
                if i==0 and j==0:
                    u[i+1][j+1]=((h**2)*b[j][i] + u[j][i+1] + u[j+1][i] + u[j+2][i+1] + u[j+1][i+2])/6
                elif i==0 and j==N-1:
                    u[i+1][j+1]=((h**2)*b[j][i] + u[j][i+1] + u[j+1][i] + u[j+2][i+1] + u[j+1][i+2])/6
                elif i==N-1 and j==0:
                    u[i+1][j+1]=((h**2)*b[j][i] + u[j][i+1] + u[j+1][i] + u[j+2][i+1] + u[j+1][i+2])/6
                elif i==N-1 and j==N-1:
                    u[i+1][j+1]=((h**2)*b[j][i] + u[j][i+1] + u[j+1][i] + u[j+2][i+1] + u[j+1][i+2])/6

                # edges of matrix u
                if i==0 and 0<j<N-1:
                    u[i+1][j+1]=((h**2)*b[j][i] + u[j][i+1] + u[j+1][i] + u[j+2][i+1] + u[j+1][i+2])/5
                elif i==N and 0 <j<N-1:
                    u[i+1][j+1]=((h**2)*b[j][i] + u[j][i+1] + u[j+1][i] + u[j+2][i+1] + u[j+1][i+2])/5
                elif 0<i<N-1 and j==0:
                    u[i+1][j+1]=((h**2)*b[j][i] + u[j][i+1] + u[j+1][i] + u[j+2][i+1] + u[j+1][i+2])/5
                elif 0<i<N-1 and j==N-1:
                    u[i+1][j+1]=((h**2)*b[j][i] + u[j][i+1] + u[j+1][i] + u[j+2][i+1] + u[j+1][i+2])/5

                #everything else
                else:
                    u[i+1][j+1]=((h**2)*b[j][i] + u[j][i+1] + u[j+1][i] + u[j+2][i+1] + u[j+1][i+2])/4

        u=U +omega*(u -U)
        iteracija +=1
        print(iteracija)
        S_last=np.sum(u)

    f = open("sor4.dat", "a+")
    f.write("%d\t%d\n" %(N,iteracija))
    f.close()

plt.figure(1)
plt.contourf(X,Y,u,levels=20)
plt.colorbar()
plt.axis('equal')
plt.savefig('sor4.pdf')