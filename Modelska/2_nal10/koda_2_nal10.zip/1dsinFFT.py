import numpy as np
from scipy.fftpack import fft,ifft, dct, idct
import matplotlib.pyplot as plt


N=11 #only odd numbers
h=1/(N-1)
x=np.arange(0,1+h/2,h)
print(x)

b=np.ones(N)
b[0]=b[N-1]=0
print(b)

B=np.zeros(N,dtype=complex)
for m in range(N):
    for k in range(N):
        B[m]+=2*np.sin(np.pi*m*k/(N-1))*b[k]

print(B)

U=np.zeros(N,dtype=complex)

for i in range(1,N-1,1):
    U[i]=(h**2)*B[i]/(2*np.cos(np.pi*i/(N-1)) -2)
#U[1]=(h**2)*B[2]/(2*np.cos(np.pi*i/(N-1)) -2)
U[0]=0
U[N-1]=0
print(U)
u=np.zeros(N,dtype=complex)
for m in range(N):
    for k in range(N):
        u[m]+=np.sin(np.pi*m*k/(N-1))*U[k]/N

print(u)

plt.figure(1)
plt.grid()
plt.plot(x,u)
plt.show()