import numpy as np
import matplotlib.pyplot as plt

N=40 #works for %5==0
hr=0.5/N
r=np.arange(-0.5+hr/2,0.5,hr)
hz=(1/(2*N-1))
z=np.arange(0,1+hz/2,hz)

R,Z= np.meshgrid(r,np.flip(z))

# adding outer region
b=np.zeros((2*N,2*N))
for i in range(0,2*N,1):
        b[i][0]=1
        b[i][2*N-1]=1
        #b[0][i]=1
        #b[N-1][i]=1
'''plt.figure(0)
plt.imshow(b,cmap='gray')
plt.colorbar()
plt.show()'''

#### sine FFT

B=np.zeros((2*N,2*N))
for k in range(2*N):
    for m in range(2*N):
        for j in range(2*N):
            B[m][k]+=2*np.sin(np.pi *m*j/(2*N))*b[j][k]

'''plt.figure(2)
plt.contourf(R,Z,B,levels=20)
plt.colorbar()
plt.axis('equal')
plt.xlabel(r'$r$')
plt.ylabel(r'$z$')
plt.show()'''

U=np.ones((2*N,2*N))*B
u=np.ones((2*N,2*N))*B

iteracija=0
d=(2/(hr**2)+2/(hz**2))
for n in range(5000):
    for m in range(0,2*N,1):
        for k in range(1,N,1):
            u[m][k] = (B[m][k] +U[m][k-1]*(1/(hr**2)-1/(2*hr*(r[k])))
                       +U[m][k+1]*(1/(hr**2)+1/(2*hr*(r[k]))))/ (d -2*np.cos((m)*np.pi/(2*N))/(hz**2))
        for k in range(N,2*N-1,1):
            u[m][k] = (B[m][k] +U[m][k-1]*(1/(hr**2)-1/(2*hr*(r[k])))
                       +U[m][k+1]*(1/(hr**2)+1/(2*hr*(r[k]))))/ (d -2*np.cos((m)*np.pi/(2*N))/(hz**2))
    iteracija+=1
    print(iteracija)
    U=u

plt.figure(3)
plt.contourf(R,Z,U,levels=20)
plt.colorbar()
plt.axis('equal')
plt.xlabel(r'$r$')
plt.ylabel(r'$z$')
plt.savefig('valj_kombinirana_iteracija.pdf')

# inverse sine transform

c=np.zeros((2*N,2*N))
for k in range(2*N):
    for m in range(2*N):
        for j in range(2*N):
            c[m][k]+=np.sin(np.pi *m*j/(2*N))*U[j][k]/(2*N)


plt.figure(4)
plt.contourf(R,Z,c,levels=20)
plt.colorbar()
plt.axis('equal')
plt.xlabel(r'$r$')
plt.ylabel(r'$z$')
plt.savefig('valj_kombinirana.pdf')