import numpy as np
from scipy.fftpack import fft,ifft
import matplotlib.pyplot as plt

N=11
h=1/(N-1)
x=np.arange(0,1+h/2,h)


# SOR
'''b=np.ones(N-2)
u=np.ones(N)
u[0]=u[N-1]=0
S=np.sum(u)
S_last=1
iteracija=0
#while np.abs(S_last -S) > 0.01:
for k in range(50000):
    S_last=S
    for i in range(N-2):
        u[i+1]=((h**2)*b[i] + u[i] +u[i+2])/2
    S_last=np.sum(u)
    iteracija+=1
    #print(iteracija)
plt.figure(0)
plt.grid()
plt.plot(x,u)
plt.show()'''


b=np.ones(N)
b[0]=b[N-1]=0
B=fft(b)

'''B=np.zeros(N,dtype=complex)
for m in range(N):
    for k in range(N):
        B[m]+= b[k]*np.exp(np.pi*m*k*2j/N)'''

'''b=np.zeros(N,dtype=complex)
for m in range(N):
    for k in range(N):
        b[m]+= B[k]*np.exp(-np.pi*m*k*2j/N)/(N)
u=np.zeros(N)'''
U=np.zeros(N,dtype=complex)
for i in range(1,N,1):
    U[i]=(h**2)*B[i]/(2*np.cos(2*np.pi*i/(N))-2)
#U[N-1]=(h**2)*B[N-1]/(np.exp(-np.pi*(N-1)*2j/N)-2)
for i in range(1,N,1):
    U[0]-=U[i]

print(U)

'''for m in range(N):
    for k in range(N):
        u[m]+= U[k]*np.exp(-np.pi*m*k*2j/N)/N'''
u=ifft(U)
print(u)
plt.figure(1)
plt.grid()
plt.plot(x,np.abs(u*N/2))
plt.show()