import numpy as np
import matplotlib.pyplot as plt



N=100 #works for %5==0

hr=0.5/N
r=np.arange(-0.5+hr/2,0.5,hr)
hz=(1/(2*N-1))
z=np.arange(0,1+hz/2,hz)
print(r)


R,Z= np.meshgrid(r,np.flip(z))
###########################
### SOR  ###


u=np.zeros((2*N,2*N))
for i in range(2*N):
    u[i][0]=1
    u[i][2*N-1]=1

S=np.sum(u)
S_last=1
iteracija=0
while np.abs(S - S_last) > 0.0000001 * (N ** 2):
#for m in range(1000):
    S=S_last
    U=np.array(u)
    # first left side
    for i in range(1,2*N-1,1):
        for j in range(1,N,1):
            u[i][j]= ((U[i][j - 1] + U[i][j + 1]) / (hr ** 2) + (
                    -U[i][j - 1] + U[i][j + 1]) / (2 * hr * (r[j])) + (
                        U[i - 1][j] + U[i + 1][j]) / (hz ** 2)) / ((2 / (hr ** 2)) + (2 / (hz ** 2)))
    # left of the middle
    for i in range(1,2*N-1,1):
        u[i][N-1] = ((U[i][N-2]) / (hr ** 2) + (-U[i][N-2]) / (2 * hr * (r[N-1])) + (
                    U[i - 1][N-1] + U[i + 1][N-1]) / (hz ** 2)) / ((2 / (hr ** 2)) + (2 / (hz ** 2)))
    #right of the middle
    for i in range(1,2*N-1,1):
        u[i][N] = ((U[i][N+1]) / (hr ** 2) + (U[i][N+1]) / (2 * hr * r[N]) + (
                    U[i - 1][N] + U[i + 1][N]) / (hz ** 2)) / ((2 / (hr ** 2)) + (2 / (hz ** 2)))
    # right side
    for i in range(1, 2*N-1, 1):
        for j in range(N+1, 2*N - 1, 1):
            u[i][j] = ((U[i][j - 1] + U[i][j + 1]) / (hr ** 2) + (-U[i][j - 1] + U[i][j + 1]) / (
                    2 * hr * r[j]) + (
                        U[i - 1][j] + U[i + 1][j]) / (hz ** 2)) / ((2 / (hr ** 2)) + (2 / (hz ** 2)))
    iteracija +=1
    print(iteracija)
    S_last=np.sum(u)

print(u)


plt.figure(1)
plt.contourf(R,Z,u,levels=20)
plt.colorbar()
plt.axis('equal')
plt.xlabel(r'$r$')
plt.ylabel(r'$z$')
plt.savefig('valj_sor.pdf')