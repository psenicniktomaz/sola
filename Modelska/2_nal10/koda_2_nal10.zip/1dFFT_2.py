import numpy as np
from scipy.fftpack import fft,ifft
import matplotlib.pyplot as plt

N=111 #only odd numbers
h=1/(N-1)
x2=np.arange(0,1+h/2,h)
print(x2)
x1=np.arange(-1,-h/2, h)
print(x1)
x=np.concatenate((x1,x2))
print(x)

b1=-np.ones(N)
b1[0]=b1[N-1]=0
b2=np.ones(N-1)
b2[N-2]=0
b=np.concatenate((b1,b2))
print(b)

B=fft(b)
U=np.zeros(2*N-1,dtype=complex)
for i in range(1,2*N-1,1):
    U[i] = (h ** 2) * B[i] / (2 * np.cos(2 * np.pi * i / (2*N-1)) - 2)
for i in range(1, 2*N-1, 1):
    U[0]=0

u=ifft(U)
print(u)

plt.figure(1)
plt.grid()
plt.plot(x,u)
plt.xlim(-0.1,1.1)
plt.ylim(0,-0.13)
plt.show()