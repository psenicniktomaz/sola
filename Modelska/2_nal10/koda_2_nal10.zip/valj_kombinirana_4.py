import numpy as np
import matplotlib.pyplot as plt


f= open("valj_sor_3.dat","r") #creating file
vrstice=[]
for line in f:
    fields = line.split("\t")
    vrstice.append(fields)
f.close()

vrstice.pop(0)
N=len(vrstice)
print(N)
U=np.zeros((N,N))
for i in range(N):
    for j in range(N):
        U[i][j]=np.float(vrstice[i][j])

hr=1/N
r=np.arange(-0.5+hr/2,0.5,hr)
hz=(2/(2*N-1))
z=np.arange(0,1+hz/2,hz)

R,Z= np.meshgrid(r,np.flip(z))


'''plt.figure(0)
plt.contourf(R,Z,U,levels=20)
plt.colorbar()
plt.axis('equal')
plt.xlabel(r'$r$')
plt.ylabel(r'$z$')
plt.show()'''

# inverse sine FFT:
u=np.zeros((N,N))
for k in range(int(N/2)):
#for k in range(int(N/2)-1,int(N/2)+1,1):
#for k in range(2):
    for m in range(N):
        for j in range(N):
            u[m][k]+=2*np.sin(np.pi *m*j/(N))*U[j][k]

#print(u[:,int(N/2)-1])
#print(u[:,int(N/2)])
plt.figure(1)
plt.contourf(R,Z,u,levels=20)
plt.colorbar()
plt.axis('equal')
plt.xlabel(r'$r$')
plt.ylabel(r'$z$')
plt.savefig('valj_kombinirana_4.pdf')