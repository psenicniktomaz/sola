import numpy as np
from scipy import integrate
from scipy.optimize import curve_fit
import matplotlib.pyplot as plt



#preberimo vsako vrstico posbej
file=open("R_x_H.dat","r")
vrstice=[]
for line in file:
    fields = line.split("\t")
    vrstice.append(fields)
file.close()

#odstranimo prva dva elementa ker nista kul
vrstice.pop(0)
N=len(vrstice)
E=np.zeros(N+1)
Z=np.zeros(N+1)
for i in range(N):
    E[i+1]=vrstice[i][0]
    Z[i+1]=vrstice[i][1]

E[0]=-78.49
Z[0]=2



print(E)
print(Z)

plt.figure(0)
plt.xlabel('Z')
plt.ylabel(r'$E$ [eV]')
plt.plot(Z,E,'+-',alpha=0.7)


#fit function f=a*((x-b)**c)
def f(x,a,b,c,d):
    return a*np.exp(c*(x-b))+d
P=(0.6,-1.3,4,-0.01)
popt, pcov = curve_fit(f=f, xdata=Z, ydata= E,p0=P)
print('otpimalni parametri:',popt)
print(popt[0],popt[1],popt[2],popt[3])
print('faktorji kovariance:',pcov)
a=popt[0]
b=popt[1]
c=popt[2]
d=popt[3]

x=np.arange(0.99,2,0.01)
print(x)

print(f(x=1,a=a,b=b,c=c,d=d))
print(E[len(E)-3],f(x=1.1,a=a,b=b,c=c,d=d))
print(E[len(E)-2],f(x=1.09,a=a,b=b,c=c,d=d))
print(E[len(E)-1],f(x=1.08,a=a,b=b,c=c,d=d))


plt.figure(0)
plt.plot(x,f(x=x,a=a,b=b,c=c,d=d),'--',alpha=0.7,label=r'$f=-ae^{c(x-b)}+d $')

def F(x,aa,bb,cc,dd,ee,ff,gg,hh):
    return aa + cc*(x-bb) + dd*(x-bb)**2 + ee*(x-bb)**3 \
           +ff*(x-bb)**4 +gg*(x-bb)**5 + hh*(x-bb)**6

popt2, pcov2 = curve_fit(f=F, xdata=Z, ydata= E)
aa=popt2[0]
bb=popt2[1]
cc=popt2[2]
dd=popt2[3]
ee=popt2[4]
ff=popt2[5]
gg=popt2[6]
hh=popt2[7]

plt.figure(0)
plt.plot(x,F(x,aa,bb,cc,dd,ee,ff,gg,hh),'--',alpha=0.5,label='polinom 6-stopnje')
plt.legend()
plt.grid()


print(F(1,aa,bb,cc,dd,ee,ff,gg,hh))
plt.savefig('energija_H_0.png')




