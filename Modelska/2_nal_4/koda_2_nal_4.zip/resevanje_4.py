import numpy as np
from scipy import integrate
import matplotlib.pyplot as plt

def R(x,Z):
    return 2*(Z**(3/2))*x*np.exp(-Z*x)

def phi(x,Z):
    return np.exp(-2*Z*x)*(1-np.exp(2*Z*x)+Z*x)/x

h=0.001
M=5000
x=np.arange(h,M*h,h)
Z=27/16
RR=np.zeros(len(x))
for i in range(len(x)):
    RR[i]=R(x[i],Z)

print(RR)
print(x)

def PHI(x,i):
    N=len(x)
    R1=np.zeros(i)
    x1=np.zeros(i)
    if i==0:
        a1=0
    else:
        for j in range(i):
            R1[j]=RR[j]
            x1[j]=x[j]
        R1=np.array(R1)
        a1=-(1/x[i-1])*integrate.simps(R1**2,x1)
    if i==N:
        a2=0
        R2=[]
        x2=[]
    else:
        R2=np.zeros(int(N-i))
        x2=np.zeros(int(N-i))
        for j in range(i,N):
            R2[j-i] = RR[j]
            x2[j-i] = x[j]
        R2=np.array(R2)
        x2=np.array(x2)
        a2=-integrate.simps((R2**2)/x2,x2)
    return a1+a2

#i < N
'''for i in range(len(x)+1):
    print(PHI(x,i),'i=',i)'''
PHI_f=np.zeros(len(x))
for i in range(len(x)):
    PHI_f[i]=PHI(x,i)
    print(i)

plt.figure(0)
plt.plot(x,PHI_f,label='PHI',alpha=0.5)
plt.plot(x,phi(x,Z),'--',label='phi',alpha=0.5)
plt.legend(loc=0,frameon=False)


plt.figure(1)
plt.semilogy(x,np.abs(PHI_f-phi(x,Z)))
plt.show()