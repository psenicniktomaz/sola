import numpy as np
from scipy import integrate
import matplotlib.pyplot as plt

def RR(x,Z):
    return 2*(Z**(3/2))*x*np.exp(-Z*x)

Z=291/400
h=0.001

N=14000
R=np.zeros(N)
x=np.zeros(N)
for i in range(1,N+1):
    R[i-1]=RR(i*h,Z)
    x[i-1]=i*h


plt.figure(0)
plt.plot(x,R,label=r'$R_{0}$',linewidth=0.5,alpha=0.7)
#print(R)
#print(x)
Z=1.04

def PHI(x,i):
    N=len(x)
    R1=np.zeros(i)
    x1=np.zeros(i)
    if i==0:
        a1=0
    else:
        for j in range(i):
            R1[j]=R[j]
            x1[j]=x[j]
        R1=np.array(R1)
        a1=-(1/x[i-1])*integrate.simps(R1**2,x1)
    if i==N:
        a2=0
        R2=[]
        x2=[]
    else:
        R2=np.zeros(int(N-i))
        x2=np.zeros(int(N-i))
        for j in range(i,N):
            R2[j-i] = R[j]
            x2[j-i] = x[j]
        R2=np.array(R2)
        x2=np.array(x2)
        a2=-integrate.simps((R2**2)/x2,x2)
    return a1+a2

def A1():
    return 1
def A2(i):
    return -Z - VARPHI[i]
def A3(i,e):
    return (1/6)*(-e + 2*VARPHI[i]*(VARPHI[i]+2*Z))

def k(i,e):
    return 2*Z/x[i] + 2*VARPHI[i]/x[i] + e

EE=[]
# calculating energy the first approximate R(x)(x)
phi=np.zeros(len(x))
for i in range(len(x)):
    phi[i]=PHI(x,i)

N=len(x)
RR = np.zeros(N + 2)
RR[0] = 0
for i in range(1, N + 1):
    RR[i] = R[i - 1]
RR[N + 1] = R[N - 1]

dR = np.zeros(N)
for i in range(N):
    dR[i] = (RR[i] - RR[i + 2]) / (2 * h)

E = integrate.simps(dR ** 2, x) - 2 * Z * integrate.simps((R ** 2) / x, x) - integrate.simps(phi * (R ** 2), x)
E_0 = 13.6058
E=2*E_0*E
EE.append(E)

# now everything other... energies, eigenvalues, R_i
qw=0
e_last=-10
e_new=-8
QW=[0]
#while np.abs(e_last - e_new) >0.005:
for qw in range(20):
    QW.append(qw+1)
    #qw=qw+1
    e_last=e_new
    phi=np.zeros(len(x))
    for i in range(len(x)):
        phi[i]=PHI(x,i)
    VARPHI=np.zeros(len(x))
    for i in range(len(x)):
        VARPHI[i]=phi[i]*x[i]

    #metoda numerova
    e = -1
    t=h
    d_last=1
    d_current=1
    Y=[]
    while d_last*d_current >0:
        #začetni dve točki
        y=[A1()*x[0] + A2(i=0)*x[0]*x[0] + A3(i=0,e=e)*x[0]**3,A1()*x[1] + A2(i=1)*x[1]**2 +
           A3(i=1,e=e)*x[2]**3]
        d=0
        j=0
        d_last=d_current
        for i in range(0,len(x)-2):
            a = 2 * (1 - (5 / 12) * (t ** 2) * k(i+1, e)) * y[i + 1]
            b = (1 + ((t ** 2) / 12) * k(i, e)) * y[i]
            c = 1 + ((t ** 2) / 12) * k(i+2, e)
            d = (a - b) / c
            y.append(d)
            j=j+1
            if np.abs(d) > 2:
                d_current=d
                break
        d_current=d
        Y.append(d)
        e=e+0.1
    l1=e-0.2
    l2=e-0.1
    print(l1,l2)

    D=[Y[len(Y)-2],Y[len(Y)-1]]
    print(D)
    eps=1
    e_new = (l1 + l2) / 2
    e=e_new

    while eps>0.00001:
        y=[A1()*x[0] + A2(i=0)*x[0]*x[0] + A3(i=0,e=e)*x[0]**3,A1()*x[1] + A2(i=1)*x[1]**2 +
               A3(i=1,e=e)*x[2]**3]
        for i in range(0, len(x) - 2):
            a = 2 * (1 - (5 / 12) * (t ** 2) * k(i + 1, e)) * y[i + 1]
            b = (1 + ((t ** 2) / 12) * k(i, e)) * y[i]
            c = 1 + ((t ** 2) / 12) * k(i + 2, e)
            d = (a - b) / c
            y.append(d)
            if np.abs(d) > 1:
                d_current = d
                #print('prvega izpišemo:', d_current)
                break
        d_current = d
        #print('drugega izpišemo:',d_current)
        if d_current*D[0]<0:
            l2=e_new
            D[1]=d_current
        else:
            l1=e_new
            D[0]=d_current
        eps=np.abs(l1-l2)
        #print(eps)
        e_new = (l1 + l2) / 2
        e=e_new
        #print(e_new)


    #we get function R(x)


    #začetni dve točki
    R=[A1()*x[0] + A2(i=0)*x[0]*x[0] + A3(i=0,e=e)*x[0]**3,A1()*x[1] + A2(i=1)*x[1]**2 +
           A3(i=1,e=e)*x[2]**3]
    for i in range(0, len(x) - 2):
        a = 2 * (1 - (5 / 12) * (t ** 2) * k(i + 1, e)) * R[i + 1]
        b = (1 + ((t ** 2) / 12) * k(i, e)) * R[i]
        c = 1 + ((t ** 2) / 12) * k(i + 2, e)
        d = (a - b) / c
        R.append(d)

    #renormalizacija
    R=np.array(R)
    x=np.array(x)
    R_norm=integrate.simps(R**2,x)
    R=R/np.sqrt(R_norm)
    #print(R)
    print('lastne vrednosti',e_new,e_last,qw)


    # calculating energy of R(x)
    N=len(x)
    RR = np.zeros(N + 2)
    RR[0] = 0
    for i in range(1, N + 1):
        RR[i] = R[i - 1]
    RR[N + 1] = R[N - 1]

    dR = np.zeros(N)
    for i in range(N):
        dR[i] = (RR[i] - RR[i + 2]) / (2 * h)

    E = integrate.simps(dR ** 2, x) - 2 * Z * integrate.simps((R ** 2) / x, x) - integrate.simps(phi * (R ** 2), x)
    E_0 = 13.6058
    E=2*E_0*E
    EE.append(E)


    plt.figure(1)
    plt.plot(qw,e_new,'o',markersize=5)

    #qw=qw+1
    plt.figure(0)
    plt.plot(x, R, linewidth=0.8, alpha=0.7)





plt.figure(0)
plt.grid()
plt.legend(loc=0,frameon=False)
plt.ylabel('R(x)')
plt.xlabel('x')
plt.savefig('H_resevanje_4_konvergenca.png')

plt.figure(1)
plt.grid()
plt.xlabel('#iteracija')
plt.ylabel('lastna vrednost')
plt.legend(loc=0,frameon=False)
plt.savefig('H_resevanje_4_lastne.png')


plt.figure(2)
plt.plot(QW,EE,'o--',linewidth=0.8)
plt.grid()
plt.xlabel('#iteracija')
plt.ylabel('energija')
plt.savefig('H_resevanje_4_energija.png')