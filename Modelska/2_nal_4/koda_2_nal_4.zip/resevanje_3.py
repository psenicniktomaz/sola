import numpy as np
from scipy import integrate
import matplotlib.pyplot as plt

Z=2
Z_star=Z-5/16
def varphi(x,Z_star):
    return np.exp(-2*Z_star*x)*(1-np.exp(2*Z_star*x)+Z_star*x)

def a1():
    return 1
def a2(x):
    return -Z - varphi(x,Z_star)
def a3(x,e):
    return (1/6)*(-e + 2*varphi(x,Z_star)*(varphi(x,Z_star)+2*Z))
def a4(x,e):
    return (1/18)*(2*e*(varphi(x,Z_star)+Z)-
                   (varphi(x,Z_star)**2)*(varphi(x,Z_star)-3*Z))

def k(x,e):
    return 2*Z/x + 2*varphi(x,Z_star)/x + e

#first numerov method

T=[0.1,0.05,0.01,0.001,0.0001]
l1 = -10
l2 = 0
for t in T:
    Y=[]
    XX=[]
    j=0
    print(l1,l2)
    E=np.arange(l1,l2,t)
    for e in E:
        #začetni dve točki
        y=[a1()*t + a2(t)*t*t + a3(t,e)*t*t*t,a1()*2*t + a2(2*t)*t*t*4 +
           a3(2*t,e)*t*t*t*8]
        print(y)
        i=0
        d=0
        e_current=0
        while np.abs(d) < 3**2:
            e_last=e_current
            a = 2 * (1 - (5 / 12) * (t ** 2) * k(2 * t + i*t, e)) * y[i + 1]
            b = (1 + ((t ** 2) / 12) * k(t + i * t, e)) * y[i]
            c = 1 + ((t ** 2) / 12) * k(3 * t + i * t, e)
            d = (a - b) / c
            y.append(d)
            e_current=d
            X=3*t +i*t
            i=i+1
            if e_current*e_last <0:
                l1=e -t
                l2=e+t
                print('l sta:',l1,l2,t)
                break
        if e_current * e_last < 0:
            break

        Y.append(d)
        XX.append(X)
        print(Y[j], e, X,i)
        j = j + 1

e=(l1+l2)/2
print(e)

'''e=-1.8075000

#we get function R(x)

t=0.001
#začetni dve točki
R=[a1()*t + a2(t)*t*t + a3(t,e)*t*t*t,a1()*2*t + a2(2*t)*t*t*4 +
           a3(2*t,e)*t*t*t*8]
i=0
x=[t,2*t]
while R[i]>0:
    a=2*(1-(5/12)*(t**2)*k(2*t +i*t,e))*R[i+1]
    b=(1+((t**2)/12)*k(t+i*t,e))*R[i]
    c=1+((t**2)/12)*k(3*t +i*t,e)
    x.append(3*t +i*t)
    R.append((a-b)/c)
    i=i+1
    #print((a-b)/c)


#renormalizacija
R=np.array(R)
x=np.array(x)
R_norm=integrate.simps(R**2,x)
R=R/np.sqrt(R_norm)
print(R)
print(x)

#now we need to make the method discrete
def PHI(x,i):
    N=len(x)
    R1=np.zeros(i)
    x1=np.zeros(i)
    if i==0:
        a1=0
    else:
        for j in range(i):
            R1[j]=R[j]
            x1[j]=x[j]
        R1=np.array(R1)
        a1=-(1/x[i-1])*integrate.simps(R1**2,x1)
    if i==N:
        a2=0
        R2=[]
        x2=[]
    else:
        R2=np.zeros(int(N-i))
        x2=np.zeros(int(N-i))
        for j in range(i,N):
            R2[j-i] = R[j]
            x2[j-i] = x[j]
        R2=np.array(R2)
        x2=np.array(x2)
        a2=-integrate.simps((R2**2)/x2,x2)
    return a1+a2

def A1():
    return 1
def A2(i):
    return -Z - VARPHI[i]
def A3(i,e):
    return (1/6)*(-e + 2*VARPHI[i]*(VARPHI[i]+2*Z))

def k(i,e):
    return 2*Z/x[i] + 2*VARPHI[i]/x[i] + e

#here will be the loop

phi=np.zeros(len(x))
for i in range(len(x)):
    phi[i]=PHI(x,i)
VARPHI=np.zeros(len(x))
for i in range(len(x)):
    VARPHI[i]=phi[i]*x[i]

#numerov method
T=[0.1,0.05,0.01,0.001,0.0001]
l1 = -12
l2 = 0
for t in T:
    Y=[]
    XX=[]
    j=0
    print(l1,l2)
    E=np.arange(l1,l2,t)
    for e in E:
        #začetni dve točki
        y=[A1()*x[0] + A2(i=0)*x[0]*x[0] + A3(i=0,e=e)*x[0]**3,A1()*x[1] + A2(i=1)*x[1]**2 +
           A3(i=1,e=e)*x[2]**3]
        d=0
        e_current=0
        for i in range(0,len(x)-2):
            e_last=e_current
            a = 2 * (1 - (5 / 12) * (t ** 2) * k(i+1, e)) * y[i + 1]
            b = (1 + ((t ** 2) / 12) * k(i, e)) * y[i]
            c = 1 + ((t ** 2) / 12) * k(i+2, e)
            d = (a - b) / c
            y.append(d)
            e_current=d
            X=3*t +i*t
            i=i+1
            if e_current*e_last <0:
                l1=e -t
                l2=e+t
                print('l sta:',l1,l2,t)
                break
        if e_current * e_last < 0:
            break

        Y.append(d)
        XX.append(X)
        print(Y[j], e, X,i)
        j = j + 1

e=(l1+l2)/2
print(e)

#we get function R(x)

#začetni dve točki
R=[A1()*t + A2(i=0)*x[0]*x[0] + A3(i=0,e=e)*x[0]**3,A1()*x[1] + A2(i=1)*x[1]**2 +
           A3(i=1,e=e)*x[2]**3]
N=len(x)
i=0
while R[i]>0:
    a=2*(1-(5/12)*(t**2)*k(2*t +i*t,e))*R[i+1]
    b=(1+((t**2)/12)*k(t+i*t,e))*R[i]
    c=1+((t**2)/12)*k(3*t +i*t,e)
    R.append((a-b)/c)
    i=i+1
    if i== N-2:
        break'''






