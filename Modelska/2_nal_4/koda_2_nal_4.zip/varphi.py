import numpy as np
import matplotlib.pyplot as plt

Z=2

def phi(x,Z_star):
    return np.exp(-2*Z_star*x)*(1-np.exp(2*Z_star*x)+Z_star*x)/x

def varphi(x,Z_star):
    return np.exp(-2*Z_star*x)*(1-np.exp(2*Z_star*x)+Z_star*x)


Z_star=Z-(5/16)

x=np.arange(0.05,10,0.05)

plt.figure(0)
plt.plot(x,phi(x,Z_star),label=r'$\phi(x)$',alpha=0.7)
plt.plot(x,-phi(x,Z_star),label=r'$-\phi(x)$',alpha=0.7)
plt.title(r'$\phi(x)$')
plt.xlabel(r'x')
plt.grid()
plt.legend(loc=0,frameon=False)
plt.savefig('phi.png')


x=np.arange(0,3,0.05)
plt.figure(1)
plt.plot(x,varphi(x,Z_star),label=r'$\varphi(x)$',alpha=0.7)
plt.plot(x,-varphi(x,Z_star),label=r'$-\varphi(x)$',alpha=0.7)
plt.title(r'$\varphi(x)$')
plt.xlabel(r'x')
plt.grid()
plt.legend(loc=0,frameon=False)
plt.savefig('varphi.png')