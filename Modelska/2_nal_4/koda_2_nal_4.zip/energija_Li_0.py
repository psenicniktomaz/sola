import numpy as np
from scipy import integrate
import matplotlib.pyplot as plt


h=0.001

N=5000
x=np.zeros(N)
for i in range(1,N+1):
    x[i-1]=i*h
Z=3

#preberimo vsako vrstico posbej
file=open("R_x_Li.dat","r")
R=np.zeros(N)
vrstice=[]
for line in file:
    fields = line.split("\t")
    vrstice.append(fields)
file.close()

for i in range(N):
    R[i]=np.float(vrstice[i][0])

def PHI(x,i):
    N=len(x)
    R1=np.zeros(i)
    x1=np.zeros(i)
    if i==0:
        a1=0
    else:
        for j in range(i):
            R1[j]=R[j]
            x1[j]=x[j]
        R1=np.array(R1)
        a1=-(1/x[i-1])*integrate.simps(R1**2,x1)
    if i==N:
        a2=0
        R2=[]
        x2=[]
    else:
        R2=np.zeros(int(N-i))
        x2=np.zeros(int(N-i))
        for j in range(i,N):
            R2[j-i] = R[j]
            x2[j-i] = x[j]
        R2=np.array(R2)
        x2=np.array(x2)
        a2=-integrate.simps((R2**2)/x2,x2)
    return a1+a2

phi=np.zeros(len(x))
for i in range(len(x)):
    phi[i]=PHI(x,i)

#we need RR for differentiation
RR=np.zeros(N+2)
RR[0]=0
for i in range(1,N+1):
    RR[i]=R[i-1]
RR[N+1]=R[N-1]

dR=np.zeros(N)
for i in range(N):
    dR[i]=(RR[i]-RR[i+2])/(2*h)


E=integrate.simps(dR**2,x) - 2*Z*integrate.simps((R**2)/x,x) - integrate.simps(phi*(R**2),x)
print(E)

E_0=13.6058
print(E*E_0*2)