import numpy as np
from scipy import integrate
import matplotlib.pyplot as plt

def R(x,Z):
    return 2*(Z**(3/2))*x*np.exp(-Z*x)

def phi(x,Z):
    return np.exp(-2*Z*x)*(1-np.exp(2*Z*x)+Z*x)/x

Z=27/16

i=0
h=0.001
RR=[0,R(0.001,Z)]
x=[0,h]
while np.abs(RR[i]-RR[i+1]) > 0.0000000001:
    RR.append(R(2*h+h*i,Z))
    x.append(2*h +h*i)
    print(RR[i+2])
    i=i+1

I=len(RR)
print(I)

print(RR)
print(x)

def PHI(x):
    RR=[]
    y=np.arange(0,x,h)
    for j in y:
        RR.append(R(j,Z))
    RR=np.array(RR)
    a1=integrate.simps(RR*RR,y)

    y=np.arange(x,I*h,h)
    RR=[]
    for j in y:
        RR.append(R(j,Z))
    RR=np.array(RR)
    a2=integrate.simps(RR*RR/y,y)
    return -(1/x)*a1 - a2

print(PHI(2))
x=np.arange(h,I*h,0.1)

F=[]
for j in x:
    F.append(PHI(j))

F=np.array(F)

plt.figure(0)
plt.plot(x,F,label=r'$\phi$ numerically',alpha=0.5)
plt.plot(x,phi(x,Z),'--',label=r'$\phi$ analitically',alpha=0.5)
plt.legend(loc=0,frameon=False)
plt.savefig('resevanje_1_phi.png')

p=1
plt.figure(1)
plt.semilogy(x,np.abs(F-phi(x,Z)),alpha=0.7)
plt.title(r'|$\phi$ numerically - $\phi$ analytically |')
plt.savefig('resevanje_1_error.png')