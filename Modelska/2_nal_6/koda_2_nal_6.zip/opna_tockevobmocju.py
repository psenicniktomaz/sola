import numpy as np
from scipy.sparse.linalg import eigsh
from scipy.linalg import eigh
import matplotlib.pyplot as plt

N=70

#the A matrix
def UU(N):
    U = np.zeros((N * N, N * N))
    for i in range(N):
        if i%(N-1)==0:
            U[i][i]=6
        else:
            U[i][i]=5
    for i in range(N*N-1,N*N-N -1,-1):
        if i%(N-1)==0:
            U[i][i]=6
        else:
            U[i][i]=5
    u=[]
    for i in range(N):
        if i%(N-1)==0:
            u.append(5)
        else:
            u.append(4)
    for i in range(N):
        for n in range(N-2):
            U[i+N*n +N][i+N*n +N ]=u[i]

    for i in range(0,N*N-1):
        if ((N-1)*i-1)%N==0:
            U[i][i+1]=0
            U[i+1][i]=0
        else:
            U[i][i+1]=-1
            U[i+1][i]=-1
    for i in range(N*N -N):
        U[i+N][i]=-1
        U[i][i+N]=-1
    return U

A=UU(N)
print(A)

'''plt.figure(0)
plt.imshow(A,cmap='gray')
plt.colorbar()'''


I=[]
for i in range(1,N**2+1):
    I.append(i)


eigenvalues,eigenvectors =eigsh(A,which='SM')

'''plt.figure('eigenvalues')
plt.plot(I,eigenvalues,'o-',markersize=0.3,linewidth=0.7)
plt.grid()'''


print(eigenvectors)
u1=[]
for i in range(N**2):
    u1.append(eigenvectors[i][5])
u1=np.array(u1)
u2=[]
for i in range(N**2):
    u2.append(eigenvectors[i][4])
u2=np.array(u2)

u=(u1+u2)/2

U=np.zeros((N,N))
j=-1
for i in range(N**2):
    if i % (N) == 0:
        j = j + 1
    U[j][i % (N)] = u[i]

print(U)

'''plt.figure(0)
plt.imshow(U,cmap='gray')
plt.colorbar()'''




h=1/N

X=np.arange(h/2,1,h)
Y=np.arange(h/2,1,h)
XX,YY=np.meshgrid(X,Y)

Z=np.zeros((N,N))
for i in range(N):
    for j in range(N):
        Z[i][j]=U[i,j]
plt.figure('krneki')
plt.contourf(XX,YY,Z,levels=15)
plt.colorbar()
plt.axis('equal')
plt.show()
