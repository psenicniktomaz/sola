import numpy as np
from scipy.linalg import eigh
import matplotlib.pyplot as plt

N=21
#the A matrix
I=[]
for i in range(1,N+1):
    I.append(i)

def UU(N):
    U = np.zeros((N, N))
    for i in range(N):
        U[i][i]=2
    for i in range(0,N-1):
        U[i][i+1]=-1
        U[i+1][i]=-1
    return U

A=UU(N=N)
print(A)

#w,v= np.linalg.eig(A)

#print(w)
#print('\n lastni vektorji',v)

W,V=eigh(A)

print(W)
print('\n lastni vektorji',V)
print('seštevek=',sum((V[:][2]**2)))

'''plt.figure(0)
plt.plot(I,W,'o-')
plt.grid()


eigenvector_1=[]
for i in range(N):
    eigenvector_1.append(V[i,0]/0.3)

plt.figure(1)
plt.plot(I,eigenvector_1,'o-')
plt.grid()


eigenvector_2=[]
for i in range(N):
    eigenvector_2.append(V[i,1])

plt.figure(2)
plt.plot(I,eigenvector_2,'o-')
plt.grid()


eigenvector_3=[]
for i in range(N):
    eigenvector_3.append(V[i,2])

plt.figure(3)
plt.plot(I,eigenvector_3,'o-')
plt.grid()


eigenvector_5=[]
for i in range(N):
    eigenvector_5.append(V[i,4])

plt.figure(5)
plt.plot(I,eigenvector_5,'o-')
plt.grid()


eigenvector_11=[]
for i in range(N):
    eigenvector_11.append(V[i,10])

plt.figure(11)
plt.plot(I,eigenvector_11,'o-')
plt.grid()


eigenvector_21=[]
for i in range(N):
    eigenvector_21.append(V[i,20])

plt.figure(21)
plt.plot(I,eigenvector_21,'o-')
plt.grid()
plt.show()'''