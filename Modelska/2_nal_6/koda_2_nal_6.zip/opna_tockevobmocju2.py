import numpy as np
from scipy.sparse.linalg import eigsh
from scipy.linalg import eigh
import matplotlib.pyplot as plt

N=50

#the A matrix
def UU(N):
    U = np.zeros((N * N, N * N))
    for i in range(N):
        if i%(N-1)==0:
            U[i][i]=6
        else:
            U[i][i]=5
    for i in range(N*N-1,N*N-N -1,-1):
        if i%(N-1)==0:
            U[i][i]=6
        else:
            U[i][i]=5
    u=[]
    for i in range(N):
        if i%(N-1)==0:
            u.append(5)
        else:
            u.append(4)
    for i in range(N):
        for n in range(N-2):
            U[i+N*n +N][i+N*n +N ]=u[i]

    for i in range(0,N*N-1):
        if ((N-1)*i-1)%N==0:
            U[i][i+1]=0
            U[i+1][i]=0
        else:
            U[i][i+1]=-1
            U[i+1][i]=-1
    for i in range(N*N -N):
        U[i+N][i]=-1
        U[i][i+N]=-1
    return U

A=UU(N)
print(A)




I=[]
for i in range(1,N**2+1):
    I.append(i)


eigenvalues =eigh(A,eigvals_only=True)

plt.figure('eigenvalues')
plt.plot(I,eigenvalues,'o-',markersize=0.3,linewidth=0.7)
plt.grid()
plt.savefig('opna_tockevobmocju2_1.pdf')

plt.figure('eigenvalues2')
plt.plot(I,eigenvalues,'o-')
plt.grid()
plt.xlim(0,15)
plt.ylim(0.5*eigenvalues[0],1.02*eigenvalues[16])
plt.savefig('opna_tockevobmocju2_2.pdf')





