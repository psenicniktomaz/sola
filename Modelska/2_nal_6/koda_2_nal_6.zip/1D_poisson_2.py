from scipy.sparse import diags
from scipy.linalg import eigh

N=5
def diagonals(N):
    d=[]
    d1=N*[2]
    d2=(N-1)*[-1]
    d.append(d1)
    d.append(d2)
    d.append(d2)
    return d

U=diagonals(N)
A=diags(U, [0, -1, 1]).toarray()
print(A)

W,V=eigh(A)

print(W)
print('\n lastni vektorji',V)
