import numpy as np
from scipy.sparse.linalg import eigsh
from scipy.linalg import eigh
import matplotlib.pyplot as plt


n=[9,19,29,39,49]




#the A matrix
def UU(N):
    U = np.zeros((N * N, N * N))
    for i in range(N*N):
        U[i][i]=4
    for i in range(0,N*N-1):
        if ((N-1)*i-1)%N==0:
            U[i][i+1]=0
            U[i+1][i]=0
        else:
            U[i][i+1]=-1
            U[i+1][i]=-1
    for i in range(N*N -N):
        U[i+N][i]=-1
        U[i][i+N]=-1
    return U


for N in n:
    h=1/(N+1)
    A=UU(N)
    #print(A)

    I=[]
    for i in range(1,N**2+1):
        I.append(i)

    #eigenvalues, eigenvectors =eigsh(A,k=int(N**2))
    eigenvalues, eigenvectors =eigh(A)

    plt.figure('eigenvalues')
    plt.plot(eigenvalues,I,'o-',markersize=0.9,alpha=0.6)



plt.figure('eigenvalues')
plt.grid()
plt.ylabel('#lastna vrednost')
plt.xlabel(r'vrednost $\lambda _{n}$')
plt.savefig('kvadratna_opna_0_eigenvalues.pdf')