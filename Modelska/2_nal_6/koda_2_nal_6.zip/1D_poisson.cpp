#include "../numerika/nr3.h"
#include <cstdlib>
#include <cstdio>
#include <iostream>
#include <fstream>
#include <cmath>
#include <string>
#include "../numerika/roots_poly.h"



using namespace std;

int main() {
    
    return 0;
}