import numpy as np
from scipy.sparse.linalg import eigsh
from scipy.linalg import eigh
import matplotlib.pyplot as plt

N=70 #works for %5==0
h=1/N

def lik(N):

    rho1=0.5
    rho2=5
    U=np.ones((N,N))*rho2


    k=0
    for i in range(int(N/5)):
        for j in range(2*int(N/5)+k,3*int(N/5)):
            U[i, j] = rho1
        k=k+1
        if k > N/5:
            break
    k=0
    for i in range(int(N/5)):
        for j in range(0,int(N/5)-k):
            U[i, j] = rho1
        k=k+1
        if k > N/5:
            break
    k=0
    for i in range(4*int(N/5),N):
        for j in range(int(N)-k-1,int(N)):
            U[i, j] = rho1
        k=k+1
        if k > N/5:
            break

    k=0
    for i in range(4*int(N/5),N):
        for j in range(2*int(N/5),2*int(N/5)+k+1):
            U[i, j] = rho1
        k=k+1
        if k > N/5:
            break

    for i in range(2*int(N/5),N):
        for j in range(int(N/5),2*int(N/5)):
            U[i, j] = rho1

    for i in range(3*int(N/5)):
        for j in range(3*int(N/5),4*int(N/5)):
            U[i, j] = rho1
    return U

b=lik(N)

B=np.zeros((N**2,N**2))
l=0
for i in range(N):
    for j in range(N):
        B[l][l]=b[i][j]
        l=l+1

def UU(N):
    U = np.zeros((N * N, N * N))
    for i in range(N*N):
        U[i][i]=4
    for i in range(0,N*N-1):
        if ((N-1)*i-1)%N==0:
            U[i][i+1]=0
            U[i+1][i]=0
        else:
            U[i][i+1]=-1
            U[i+1][i]=-1
    for i in range(N*N -N):
        U[i+N][i]=-1
        U[i][i+N]=-1
    return U

A=UU(N)


I=[]
for i in range(1,N**2+1):
    I.append(i)

eigenvalues, eigenvectors =eigsh(A,k=6,M=B,which='SM')


u1=[]
for i in range(N**2):
    u1.append(eigenvectors[i][4])
u1=np.array(u1)
u2=[]
for i in range(N**2):
    u2.append(eigenvectors[i][3])
u2=np.array(u2)



X=np.arange(h/2,1,h)
Y=np.arange(h/2,1,h)
XX,YY=np.meshgrid(X,Y)


u=(u1-u2)/2
U=np.zeros((N,N))
j=-1
for i in range(N**2):
    if i % (N) == 0:
        j = j + 1
    U[j][i % (N)] = u[i]


Z=np.zeros((N,N))
for i in range(N):
    for j in range(N):
        Z[i][j]=U[i,j]
plt.figure(1)
plt.contourf(XX,YY,Z,levels=15)
plt.colorbar()
plt.axis('equal')
plt.savefig('obtez3_1.pdf')


u=(u1+u2)/2
U=np.zeros((N,N))
j=-1
for i in range(N**2):
    if i % (N) == 0:
        j = j + 1
    U[j][i % (N)] = u[i]

Z=np.zeros((N,N))
for i in range(N):
    for j in range(N):
        Z[i][j]=U[i,j]
plt.figure(2)
plt.contourf(XX,YY,Z,levels=15)
plt.colorbar()
plt.axis('equal')
plt.savefig('obtez3_2.pdf')

u=u1
U=np.zeros((N,N))
j=-1
for i in range(N**2):
    if i % (N) == 0:
        j = j + 1
    U[j][i % (N)] = u[i]

Z=np.zeros((N,N))
for i in range(N):
    for j in range(N):
        Z[i][j]=U[i,j]
plt.figure(3)
plt.contourf(XX,YY,Z,levels=15)
plt.colorbar()
plt.axis('equal')
plt.savefig('obtez3_3.pdf')



u=u2
U=np.zeros((N,N))
j=-1
for i in range(N**2):
    if i % (N) == 0:
        j = j + 1
    U[j][i % (N)] = u[i]

Z=np.zeros((N,N))
for i in range(N):
    for j in range(N):
        Z[i][j]=U[i,j]
plt.figure(4)
plt.contourf(XX,YY,Z,levels=15)
plt.colorbar()
plt.axis('equal')
plt.savefig('obtez3_4.pdf')





