import numpy as np
from scipy.sparse.linalg import eigsh
from scipy.linalg import eigh
import matplotlib.pyplot as plt

from matplotlib import cm
from matplotlib.ticker import LinearLocator, FormatStrFormatter
from mpl_toolkits.mplot3d import Axes3D

N=99
h=1/(N+1)
print(h)
#the A matrix
def UU(N):
    U = np.zeros((N * N, N * N))
    for i in range(N*N):
        U[i][i]=4
    for i in range(0,N*N-1):
        if ((N-1)*i-1)%N==0:
            U[i][i+1]=0
            U[i+1][i]=0
        else:
            U[i][i+1]=-1
            U[i+1][i]=-1
    for i in range(N*N -N):
        U[i+N][i]=-1
        U[i][i+N]=-1
    return U

A=UU(N)
#print(A)


I=[]
for i in range(1,N**2+1):
    I.append(i)

#eigenvalues, eigenvectors =eigsh(A,k=int(N**2))
eigenvalues, eigenvectors =eigh(A)

#print(eigenvalues)
#print(eigenvectors[:,0])

lastni_vekt=[]
for i in range(14):
    lastni_vekt.append(eigenvalues[i]/(h**2))

print(lastni_vekt)

plt.figure('eigenvalues')
plt.plot(I,eigenvalues,'o-',markersize=0.3,linewidth=0.7)
plt.grid()
plt.savefig('kvadratna_opna_1_eigenvalues.pdf')
#plt.xlim(0,50)
#plt.ylim(0,0.5)

plt.figure('eigenvalues2')
plt.plot(I,eigenvalues,'o-')
plt.grid()
plt.xlim(0,15)
plt.ylim(0.5*eigenvalues[0],1.02*eigenvalues[16])
plt.savefig('kvadratna_opna_1_eigenvalues2.pdf')



j=-1
U=np.zeros((N,N))
for i in range(0,(N**2)):
    if i%(N)==0:
        j=j+1
    U[j, i % (N)] = eigenvectors[i][0]

#print(U)

'''plt.figure(1)
plt.imshow(U,cmap='gray')
plt.colorbar()'''


X=np.arange(h,1,h)
Y=np.arange(h,1,h)
XX,YY=np.meshgrid(X,Y)

Z=np.zeros((N,N))
for i in range(N):
    for j in range(N):
        Z[i][j]=U[i,j]
plt.figure('krneki')
plt.contourf(XX,YY,Z,levels=15)
plt.colorbar()
plt.axis('equal')
plt.savefig('kvadratna_opna_1_nihajni1_1.pdf')



fig = plt.figure('3')
ax = fig.gca(projection='3d')
surf = ax.plot_surface(XX, YY, Z, cmap=cm.coolwarm,
                       linewidth=1, antialiased=False,alpha=0.5)

# Customize the z axis.

ax.zaxis.set_major_locator(LinearLocator(10))
ax.zaxis.set_major_formatter(FormatStrFormatter('%.02f'))

# Add a color bar which maps values to colors.
#fig.colorbar(surf, shrink=0.5, aspect=5)

ax.set_xlabel(r'$x$')
ax.set_ylabel(r'$y$')
fig.colorbar(surf, shrink=0.5, aspect=5)
ax.set_zlabel(r'$u_{z}$')
plt.savefig('kvadratna_opna_1_nihajni1_2.pdf')









j=-1
U=np.zeros((N,N))
for i in range(0,(N**2)):
    if i%(N)==0:
        j=j+1
    U[j, i % (N)] = eigenvectors[i][1]

Z=np.zeros((N,N))
for i in range(N):
    for j in range(N):
        Z[i][j]=U[i,j]
plt.figure('4')
plt.contourf(XX,YY,Z,levels=15)
plt.colorbar()
plt.axis('equal')
plt.savefig('kvadratna_opna_1_nihajni2_1.pdf')


fig = plt.figure('5')
ax = fig.gca(projection='3d')
surf = ax.plot_surface(XX, YY, Z, cmap=cm.coolwarm,
                       linewidth=1, antialiased=False,alpha=0.5)

# Customize the z axis.

ax.zaxis.set_major_locator(LinearLocator(10))
ax.zaxis.set_major_formatter(FormatStrFormatter('%.02f'))

# Add a color bar which maps values to colors.
#fig.colorbar(surf, shrink=0.5, aspect=5)

ax.set_xlabel(r'$x$')
ax.set_ylabel(r'$y$')
fig.colorbar(surf, shrink=0.5, aspect=5)
ax.set_zlabel(r'$u_{z}$')
plt.savefig('kvadratna_opna_1_nihajni2_2.pdf')





j=-1
U=np.zeros((N,N))
for i in range(0,(N**2)):
    if i%(N)==0:
        j=j+1
    U[j, i % (N)] = eigenvectors[i][2]

Z=np.zeros((N,N))
for i in range(N):
    for j in range(N):
        Z[i][j]=U[i,j]
plt.figure('6')
plt.contourf(XX,YY,Z,levels=15)
plt.colorbar()
plt.axis('equal')
plt.savefig('kvadratna_opna_1_nihajni3_1.pdf')


fig = plt.figure('7')
ax = fig.gca(projection='3d')
surf = ax.plot_surface(XX, YY, Z, cmap=cm.coolwarm,
                       linewidth=1, antialiased=False,alpha=0.5)

# Customize the z axis.

ax.zaxis.set_major_locator(LinearLocator(10))
ax.zaxis.set_major_formatter(FormatStrFormatter('%.02f'))

# Add a color bar which maps values to colors.
#fig.colorbar(surf, shrink=0.5, aspect=5)

ax.set_xlabel(r'$x$')
ax.set_ylabel(r'$y$')
fig.colorbar(surf, shrink=0.5, aspect=5)
ax.set_zlabel(r'$u_{z}$')
plt.savefig('kvadratna_opna_1_nihajni3_2.pdf')










j=-1
U=np.zeros((N,N))
for i in range(0,(N**2)):
    if i%(N)==0:
        j=j+1
    U[j, i % (N)] = eigenvectors[i][3]

Z=np.zeros((N,N))
for i in range(N):
    for j in range(N):
        Z[i][j]=U[i,j]
plt.figure('8')
plt.contourf(XX,YY,Z,levels=15)
plt.colorbar()
plt.axis('equal')
plt.savefig('kvadratna_opna_1_nihajni4_1.pdf')


fig = plt.figure('9')
ax = fig.gca(projection='3d')
surf = ax.plot_surface(XX, YY, Z, cmap=cm.coolwarm,
                       linewidth=1, antialiased=False,alpha=0.5)

# Customize the z axis.

ax.zaxis.set_major_locator(LinearLocator(10))
ax.zaxis.set_major_formatter(FormatStrFormatter('%.02f'))

# Add a color bar which maps values to colors.
#fig.colorbar(surf, shrink=0.5, aspect=5)

ax.set_xlabel(r'$x$')
ax.set_ylabel(r'$y$')
fig.colorbar(surf, shrink=0.5, aspect=5)
ax.set_zlabel(r'$u_{z}$')
plt.savefig('kvadratna_opna_1_nihajni4_2.pdf')





j=-1
U=np.zeros((N,N))
for i in range(0,(N**2)):
    if i%(N)==0:
        j=j+1
    U[j, i % (N)] = eigenvectors[i][4]

Z=np.zeros((N,N))
for i in range(N):
    for j in range(N):
        Z[i][j]=U[i,j]
plt.figure('10')
plt.contourf(XX,YY,Z,levels=15)
plt.colorbar()
plt.axis('equal')
plt.savefig('kvadratna_opna_1_nihajni5_1.pdf')


fig = plt.figure('11')
ax = fig.gca(projection='3d')
surf = ax.plot_surface(XX, YY, Z, cmap=cm.coolwarm,
                       linewidth=1, antialiased=False,alpha=0.5)

# Customize the z axis.

ax.zaxis.set_major_locator(LinearLocator(10))
ax.zaxis.set_major_formatter(FormatStrFormatter('%.02f'))

# Add a color bar which maps values to colors.
#fig.colorbar(surf, shrink=0.5, aspect=5)

ax.set_xlabel(r'$x$')
ax.set_ylabel(r'$y$')
fig.colorbar(surf, shrink=0.5, aspect=5)
ax.set_zlabel(r'$u_{z}$')
plt.savefig('kvadratna_opna_1_nihajni5_2.pdf')






j=-1
U=np.zeros((N,N))
for i in range(0,(N**2)):
    if i%(N)==0:
        j=j+1
    U[j, i % (N)] = eigenvectors[i][5]

Z=np.zeros((N,N))
for i in range(N):
    for j in range(N):
        Z[i][j]=U[i,j]
plt.figure('12')
plt.contourf(XX,YY,Z,levels=15)
plt.colorbar()
plt.axis('equal')
plt.savefig('kvadratna_opna_1_nihajni6_1.pdf')


fig = plt.figure('13')
ax = fig.gca(projection='3d')
surf = ax.plot_surface(XX, YY, Z, cmap=cm.coolwarm,
                       linewidth=1, antialiased=False,alpha=0.5)

# Customize the z axis.

ax.zaxis.set_major_locator(LinearLocator(10))
ax.zaxis.set_major_formatter(FormatStrFormatter('%.02f'))

# Add a color bar which maps values to colors.
#fig.colorbar(surf, shrink=0.5, aspect=5)

ax.set_xlabel(r'$x$')
ax.set_ylabel(r'$y$')
fig.colorbar(surf, shrink=0.5, aspect=5)
ax.set_zlabel(r'$u_{z}$')
plt.savefig('kvadratna_opna_1_nihajni6_2.pdf')
