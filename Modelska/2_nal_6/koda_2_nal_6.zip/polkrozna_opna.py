import numpy as np
from scipy.sparse.linalg import eigsh
from scipy.linalg import eigh
from scipy.linalg import eig
from scipy.sparse.linalg import eigs
import matplotlib.pyplot as plt

N=49
h_r=1/(N+1)
h_phi=np.pi /(N+1)

def UU(N):
    U = np.zeros((N * N, N * N))
    for i in range(1,N*N+1):
        U[i-1][i-1]=2*(1/(h_r**2)+ 1/(h_r*h_r * h_phi* h_phi *i * i))
    for i in range(1,N*N):
        if ((N-1)*(i-1)-1)%N==0:
            U[i-1][i]=0
            U[i][i-1]=0
        else:
            U[i-1][i]=-1/((h_r * i * h_phi)**2)
            U[i][i-1]=-1/((h_r * i * h_phi)**2)
    for i in range(1,N*N -N+1):
        U[i+N-1][i-1]=-(1/(h_r**2)) - 1/(2*i*(h_r**2))
        U[i-1][i+N-1]=-(1/(h_r**2)) + 1/(2*i*(h_r**2))
    return U

A=UU(N)
#print(A)

k=6
eigenvalues,eigenvectors=eigs(A,k=k,which='SM')

I=[]
for i in range(k,0,-1):
    I.append(i)

print(len(eigenvalues))
print(eigenvalues)


r=np.arange(1 -h_r,0,-h_r)
phi=np.arange(h_phi,np.pi,h_phi)
R,PHI=np.meshgrid(r,phi)

print(R)
print(PHI)

X=np.zeros((N,N))
for i in range(N):
    for j in range(N):
        X[i][j]=np.cos(phi[i])*r[j]

Y=np.zeros((N,N))
for i in range(N):
    for j in range(N):
        Y[i][j]=np.sin(phi[i])*r[j]


j=-1
U=np.zeros((N,N))
for i in range(0,(N**2)):
    if i%(N)==0:
        j=j+1
    U[j, i % (N)] = eigenvectors[i][0]

Z=np.zeros((N,N))
for i in range(N):
    for j in range(N):
        Z[i][j]=U[i,j]



'''plt.figure('eigenvalues')
plt.plot(I,eigenvalues,'o-',markersize=0.3,linewidth=0.7)
plt.grid()
plt.show()'''

plt.figure(0)
plt.contourf(X,Y,Z,levels=20)
plt.colorbar()
plt.xlabel(r'$x$')
plt.ylabel(r'$y$')
plt.savefig('polkrozna_opna1_1.pdf')

plt.figure(1)
plt.contourf(R,PHI,Z,levels=20)
plt.colorbar()
plt.xlabel(r'$r$')
plt.ylabel(r'$\phi$')
plt.savefig('polkrozna_opna1_2.pdf')

'''plt.figure('eigenvalues2')
plt.plot(I,eigenvalues,'o-')
plt.grid()
plt.xlim(0,6)
plt.ylim(0.5*eigenvalues[0],1.02*eigenvalues[5])
plt.show()'''

'''plt.figure(0)
plt.imshow(A,cmap='gray')
plt.colorbar()
plt.show()'''

j=-1
U=np.zeros((N,N))
for i in range(0,(N**2)):
    if i%(N)==0:
        j=j+1
    U[j, i % (N)] = eigenvectors[i][1]

Z=np.zeros((N,N))
for i in range(N):
    for j in range(N):
        Z[i][j]=U[i,j]

plt.figure(2)
plt.contourf(X,Y,Z,levels=20)
plt.colorbar()
plt.xlabel(r'$x$')
plt.ylabel(r'$y$')
plt.savefig('polkrozna_opna2_1.pdf')


plt.figure(3)
plt.contourf(R,PHI,Z,levels=20)
plt.colorbar()
plt.xlabel(r'$r$')
plt.ylabel(r'$\phi$')
plt.savefig('polkrozna_opna2_2.pdf')




j = -1
U = np.zeros((N, N))
for i in range(0, (N ** 2)):
    if i % (N) == 0:
        j = j + 1
    U[j, i % (N)] = eigenvectors[i][2]

Z = np.zeros((N, N))
for i in range(N):
    for j in range(N):
        Z[i][j] = U[i, j]

plt.figure(4)
plt.contourf(X, Y, Z, levels=20)
plt.colorbar()
plt.xlabel(r'$x$')
plt.ylabel(r'$y$')
plt.savefig('polkrozna_opna3_1.pdf')

plt.figure(5)
plt.contourf(R, PHI, Z, levels=20)
plt.colorbar()
plt.xlabel(r'$r$')
plt.ylabel(r'$\phi$')
plt.savefig('polkrozna_opna3_2.pdf')



j = -1
U = np.zeros((N, N))
for i in range(0, (N ** 2)):
    if i % (N) == 0:
        j = j + 1
    U[j, i % (N)] = eigenvectors[i][3]

Z = np.zeros((N, N))
for i in range(N):
    for j in range(N):
        Z[i][j] = U[i, j]

plt.figure(6)
plt.contourf(X, Y, Z, levels=20)
plt.colorbar()
plt.xlabel(r'$x$')
plt.ylabel(r'$y$')
plt.savefig('polkrozna_opna4_1.pdf')

plt.figure(7)
plt.contourf(R, PHI, Z, levels=20)
plt.colorbar()
plt.xlabel(r'$r$')
plt.ylabel(r'$\phi$')
plt.savefig('polkrozna_opna4_2.pdf')




j = -1
U = np.zeros((N, N))
for i in range(0, (N ** 2)):
    if i % (N) == 0:
        j = j + 1
    U[j, i % (N)] = eigenvectors[i][4]

Z = np.zeros((N, N))
for i in range(N):
    for j in range(N):
        Z[i][j] = U[i, j]

plt.figure(8)
plt.contourf(X, Y, Z, levels=20)
plt.colorbar()
plt.xlabel(r'$x$')
plt.ylabel(r'$y$')
plt.savefig('polkrozna_opna5_1.pdf')

plt.figure(9)
plt.contourf(R, PHI, Z, levels=20)
plt.colorbar()
plt.xlabel(r'$r$')
plt.ylabel(r'$\phi$')
plt.savefig('polkrozna_opna5_2.pdf')




j = -1
U = np.zeros((N, N))
for i in range(0, (N ** 2)):
    if i % (N) == 0:
        j = j + 1
    U[j, i % (N)] = eigenvectors[i][5]

Z = np.zeros((N, N))
for i in range(N):
    for j in range(N):
        Z[i][j] = U[i, j]

plt.figure(10)
plt.contourf(X, Y, Z, levels=20)
plt.colorbar()
plt.xlabel(r'$x$')
plt.ylabel(r'$y$')
plt.savefig('polkrozna_opna6_1.pdf')

plt.figure(11)
plt.contourf(R, PHI, Z, levels=20)
plt.colorbar()
plt.xlabel(r'$r$')
plt.ylabel(r'$\phi$')
plt.savefig('polkrozna_opna6_2.pdf')

