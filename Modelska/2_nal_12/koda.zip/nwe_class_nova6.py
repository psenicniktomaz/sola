import numpy as np
import matplotlib.pyplot as plt
import time
import os
#import sys
#import random

#from tqdm import tqdm

#from matplotlib import cm
#import matplotlib.mlab as mlab
#from matplotlib.ticker import LinearLocator, FormatStrFormatter
#import matplotlib.path as mplPath

#import numpy.linalg as lin
##from numpy.random import power
##import math as m

#import scipy.optimize as optimize
#import scipy.linalg as lna
#import scipy.special as special
#from scipy import integrate
#from scipy.misc import factorial
#import scipy.stats as stat
#import scipy.sparse.linalg as linalg
#import scipy.sparse as sparse
#from scipy import linalg as la
#from scipy.spatial import Delaunay

#from scipy.interpolate import griddata

#from mpl_toolkits.axes_grid1 import make_axes_locatable
#from mpl_toolkits.mplot3d import Axes3D
#from multiprocessing import Pool, Process, Value, Array
#from functools import partial

#____________________________________________________________________________________________________________________

"""
Decimal points
'%.2f' % a
"""

# Plot style settings
#plt.style.use('ggplot')

### First part
class First():
    """
    Class for the first part of exercise.
    """
    ## A few parameters to begin with

    def __init__(self):
        self.a = 1
        self.N = 10            # 1D resolution
        self.Re = 1
        self.CFL = 0.4

        self.rho = 1
        self.eta = 1

        return

    def initialisation(self):
        """
        Initialisation of some needed variables
        """

        self.v0 = self.eta*self.Re / (self.a*self.rho)
        self.v0 = 1

        self.x = np.linspace(0,1,self.N)
        self.y = np.copy(self.x)
        self.p = np.linspace(0,1,self.N)

        self.dx = self.x[1] - self.x[0]
        self.dt = self.CFL * self.dx / self.v0

        return 0

    def zeta_from_velocity(self, u,v):
        """
        Calculating vorticity zeta from
        """

        zeta = np.zeros(np.shape(u))
        i=1
        while i<len(zeta)-1:
            j=1
            while j<len(zeta[0])-1:

                zeta[i,j] = - ( (u[i,j+1]-u[i,j-1])/(2*self.dx) - (v[i+1,j]-v[i-1,j])/(2*self.dx) )

                j=j+1
            i=i+1

        return zeta

    def velocity_from_psi(self, psi, u0,v0):
        """
        Calculating velocity fields from stream function psi
        u0 and v0 are just form boundary condition
        """

        u = np.zeros(np.shape(u0))
        v = np.zeros(np.shape(v0))

        i=1
        while i<len(psi)-1:
            j=1
            while j<len(psi)-1:

                u[i,j] = (psi[i,j+1] - psi[i,j-1]) / (2*self.dx)
                v[i,j] = -(psi[i+1,j] - psi[i-1,j]) / (2*self.dx)

                j=j+1
            i=i+1

        return u,v

    def initial_condition(self):
        """
        Initial condition for whole world
        """

        u = np.zeros((self.N, self.N))
        v = np.copy(u)

        u[:, 0] = [self.v0 for i in range(self.N)]

        psi = np.zeros((self.N, self.N))

        # zeta
        zeta = self.zeta_from_velocity(u,v)

#        print(np.shape(u), np.shape(v), np.shape(zeta0))

        return u,v, zeta,psi

    def initial_condition2(self):
        """
        Initial condition for whole world
        """

        u = np.zeros((self.N, self.N))
        v = np.zeros((self.N, self.N))
        u[:, 0] = np.ones((self.N))*self.v0
        psi = np.zeros((self.N, self.N))

        zeta = np.zeros((self.N, self.N))
        for i in range(1, self.N-1):
            for j in range(1, self.N-1):
                zeta[i, j] = (u[i, j+1]-u[i, j-1]-v[i+1, j]+v[i-1, j]) / (2*self.dx)

        return u,v, zeta,psi

    def boundary_zeta(self, zeta, psi):
        """
        Boundary condition for zeta
        """

        _zeta = np.copy(zeta)

        i=0
        while i<len(zeta):

            # y=0
            _zeta[i, 0] = 2 * (psi[i,0] - self.v0*self.dx) / (self.dx**2)

            # y=1
            _zeta[i, -1] = 2*psi[i,-2] / (self.dx**2)

            # x=0
            _zeta[0, i] = 2*psi[1,i] / (self.dx**2)

            # x=1
            _zeta[-1, i] = 2*psi[-2,i] / (self.dx**2)

            i=i+1

        return _zeta

    def SOR(self, zeta, psi0, u0,v0, maks=10, err=10**-3, alpha=1, prog=True):
        """
        SOR iteration to find psi in \nabla^2 psi = zeta
        Not really working for this case
        """
        t1 = time.time()

        # Variables declaration
        psi_prev = np.copy(psi0)
        psi = np.copy(psi0)

        omega = 2/(1 + alpha*np.pi/len(zeta))

        # Loop over iterations
        k = 0
        while k<maks:
            errors = []

            # Loop over space x and y
            i=1
            while i<len(zeta)-1:
                j=1
                while j<len(zeta[0])-1:

                    fun = 0.25 * ( psi[i-1,j] + psi_prev[i+1,j] + psi_prev[i,j+1] + psi[i,j-1] - self.dx**2*zeta[i,j] )
                    psi[i,j] = psi_prev[i,j] + omega*(fun - psi_prev[i,j])

                    errors.append( np.abs(fun - psi_prev[i,j]) )

                    j=j+1

                i=i+1

            if np.max(errors) <= err:
                if prog == True:
                    print("\tBreaking for minimum error! At iteration="+str(k)+", err="+str(round(np.max(errors), 4))+"\n")
                break
            psi_prev = np.copy(psi)

            if prog == True:
                t2=time.time()
                if k%(maks//30) == 0:
                    print("\tSOR: "+str(round(k/maks*100 ,2))+" %,  k="+str(k)+", error="+str(round(np.max(errors), 4))+"\t elapsed time = "+str(round((t2-t1)/60, 2))+" min" )
            k=k+1

        return psi #, k-1

    def sor(self, N, xii, psi, eps=10**(-13)):
        """
        Working SOR for this perticular case
        Actually Chebyshev acceleration for SOR
        """

        xi = xii.flatten()
        u = psi.flatten()
        h=1/N
        alpha=1
        omega=2/(1+alpha*np.pi/(N+1))

        i=0
        while(1):

            cor=0
            for x in range(1, N):
                if x%2==0:
                    yy=np.arange(2, N, 2)
                else:
                    yy=np.arange(1, N, 2)

                for y in yy:
                    nov = 1/4*( u[(N+1)*(x+1) + y] + u[(N+1)*(x-1) + y] + u[(N+1)*x + y+1] + u[(N+1)*x + y-1] - h**2*xi[(N+1)*x + y] )
                    delta = omega*(nov - u[(N+1)*x + y])
                    cor = cor + delta**2
                    u[(N+1)*x + y] = u[(N+1)*x + y] + delta

#                    print("\t"+str([x,y]))

#            print()
            for x in range(1, N):
                if x%2==0:
                    yy=np.arange(1, N, 2)
                else:
                    yy=np.arange(2, N, 2)

                for y in yy:
                    nov = 1/4*( u[(N+1)*(x+1) + y] + u[(N+1)*(x-1) + y] + u[(N+1)*x + y+1] + u[(N+1)*x + y-1] - h**2*xi[(N+1)*x + y] )
                    delta = omega*(nov - u[(N+1)*x + y])
                    cor = cor + delta**2
                    u[(N+1)*x + y] = u[(N+1)*x + y] + delta

#                    print("\t"+str([x,y]))

            i=i+1
            if cor/N**2 < eps:
                break

#            return np.reshape(u, (N+1, N+1))    # original working for final solution

        # Indent of return line gives different results in testing!!
        return np.reshape(u, (N+1, N+1))    # makes sense and also works

    def force(self, zeta):
        """
        Force at the moving lid
        """

        fun = (zeta[0,0] + zeta[-1, 0]) / 2

        for i in range(1, len(zeta)):
            fun = fun + zeta[i, 0]

        fun = fun/self.Re

        return fun

    def FTCS_one_step(self, zeta, u0,v0,psi0):
        """
        Steping one time step forward with FTCS scheme on A grid
        """

        # Calculating psi and velocity with SOR iteration
#        psi = self.SOR(zeta, psi0, u0,v0, maks=0.5*10**3, err=10**-3, prog=False)
        psi = self.sor(self.N-1, np.array(zeta), np.array(psi0))
        u,v = self.velocity_from_psi(psi, u0,v0)

        # Loop over space (x and y)
        zeta1 = np.zeros(np.shape(zeta))
        i=1
        while i<len(zeta1)-1:
            j=1
            while j<len(zeta1[0])-1:

                zeta1[i,j] = zeta[i,j] + self.dt/self.dx * ( -(u[i+1,j]*zeta[i+1,j] - u[i-1,j]*zeta[i-1,j])/2 - (v[i,j+1]*zeta[i,j+1] - v[i,j-1]*zeta[i,j-1])/2
                            + 1/(self.Re*self.dx)*(zeta[i+1,j] + zeta[i-1,j] + zeta[i,j+1] + zeta[i,j-1] - 4*zeta[i,j]) )

                j=j+1
            i=i+1

        # Boundary condition
        zeta1 = self.boundary_zeta(zeta1, psi)

        return zeta1, u,v, psi

    def FTCS(self, t_max, tol=1):
        """
        Time evolution until t_max or error gets below tol
        """

        print("\nFTCS")

        u0,v0, zeta0,psi0 = self.initial_condition2()
        u = [u0]
        v = [v0]
        psi = [psi0]
        zeta = [zeta0]
        force = [self.force(zeta0)]

        i=1
        while i*self.dt < t_max:

            # Progress printout
            if i%((t_max/self.dt)//20) < 1 or t_max <= 20*self.dt:
                print("FTCS: "+str(round(i*self.dt, 5))+" / "+str(t_max)+"\t ("+str(round(100*i*self.dt/t_max, 2))+" %)")

            # one step forward
            zeta1, u1,v1, psi1 = self.FTCS_one_step(zeta[-1], u[-1], v[-1], psi[-1])

            force1 = self.force(zeta1)

            error = np.max(np.abs(zeta1 - zeta[-1]))
            if error < tol:
                print("Breaking - error is below tolerance: "+str(error)+", time_steps = "+str(i))
                break

            # appending currecnt step to history
            u.append(u1)
            v.append(v1)
            psi.append(psi1)
            zeta.append(zeta1)
            force.append(force1)

            i=i+1

        return u,v,zeta,psi, force

    def force_reynolds(self, Rey=[100]):
        """
        Final force dependant on Re
        """
        _re = self.Re
        print("\@nForce at Reynolds")

        force = []

        i=0
        while i<len(Rey):

            print("\tRe = "+str(Rey[i])+", prog: "+str((i+1)/len(Rey)*100)+" %")
            self.Re = Rey[i]
            self.initialisation()

            u,v, zeta,psi, f = self.FTCS(50, tol=0.001)

            force.append(f[-1])

            i=i+1

        self.Re = _re
        self.initialisation()

        return Rey, force


def risanje_prva():
    """
    Plotting for first part.
    """
    t01=time.time()

    ## Data
    f = First()
    f.N = 40
    f.CFL = 0.05
    f.Re = 2000

    f.initialisation()
    x = f.x
    y = f.y
    print("dt = "+str(round(f.dt, 5))+"\tRe = "+str(f.Re))

#    u0,v0, zeta0,psi0 = f.initial_condition2()
#    psi1 = f.SOR(zeta0, psi0, u0,v0, maks=1000, err=10**-5, prog=True)
##    psi1 = f.sor(f.N-1, zeta0, zeta0)
##    psi1 = f.sor(f.N-1, zeta0, psi0)
#    u1,v1 = f.velocity_from_psi(psi1, u0,v0)
#    u = [u0, u1]
#    v = [v0, v1]
#    psi = [psi0, psi1]
#    zeta = [f.zeta_from_velocity(u0,v0), f.zeta_from_velocity(u1,v1)]
    u,v, zeta,psi, _force = f.FTCS(100, tol=0.001)

    # Calulating force
    '''Re = [10, 15,20,25,30,45, 50,70,90, 110, 150,200, 250,350, 500]
    Rey, force = f.force_reynolds(Re)'''

    print("Done calculating")
#    print(np.shape(u), np.shape(v), np.shape(zeta), np.shape(psi))

    directory = "Slike2/Re"+str(f.Re)
    try:
        os.stat(directory)
    except:
        os.makedirs(directory+"/u")
        os.makedirs(directory+"/v")
        os.makedirs(directory+"/psi")
        os.makedirs(directory+"/zeta")
        os.makedirs(directory+"/velocity")
        os.makedirs(directory+"/abs_v")


    ## Ploting
    # Ploting force
    '''fig = plt.figure(figsize=(10, 5))
    a = plt.subplot()
    #a.axhline(c="k", ls="dashed")
    #a.axvline(c="k", ls="dashed")
    plt.plot(Re, force, "x-" )
    plt.axis("equal")
    a.grid()
    #a.legend(loc="best")
    a.set_xlabel(r'$Re$')
    a.set_ylabel(r'$F$')
    #a.set_xscale('log')
    #a.set_yscale('log')
    #a.set_xlim([0, N[-1]*1.05])
    #a.set_ylim([0, 1])
    #plt.gca().invert_xaxis()
    #plt.gca().invert_yaxis()
    naslov = "Sila na pokrov \n CFL = "+str(f.CFL)+", dt = "+str(round(f.dt, 5))+", v$_0$ = "+str(round(f.v0,2))
    a.set_title(naslov)
    #plt.savefig("Slike/sila.png" , bbox_inches='tight', pad_inches=0.25, dpi=100)
    plt.savefig("Slike/sila.pdf", bbox_inches='tight')
    plt.close(fig)'''

    print("Ploting in time")
    k = False
    tr = len(zeta) // 12
    i = 0 #+ len(zeta)+10**10
    while i<len(zeta):

        if i > tr:
            print("Ploting in time: "+str(i)+" / "+str(len(zeta))+"\t ("+str(round(100*i/len(zeta), 2))+" %)")
            tr = len(zeta)//25 + tr

        fig = plt.figure(figsize=(6.2, 5))
        a = plt.subplot()
    #    a.axhline(c="k", ls="dashed")
    #    a.axvline(c="k", ls="dashed")
        plt.contourf(x, y, zeta[i])
        plt.colorbar()
        plt.axis("equal")
    #    a.legend(loc="best")
        a.set_xlabel("y")
        a.set_ylabel("x")
    #    a.set_xscale('log')
    #    a.set_yscale('log')
    #    a.set_xlim([0, N[-1]*1.05])
        a.set_ylim([0, 1])
    #    plt.gca().invert_xaxis()
    #    plt.gca().invert_yaxis()
        naslov = "$\\zeta$\nCFL = "+str(f.CFL)+", Re = "+str(f.Re)+", t = "+str(round(i*f.dt, 5))
        a.set_title(naslov)
        plt.savefig(directory+"/zeta"+str(i)+".pdf", bbox_inches='tight')
        plt.close(fig)

        fig = plt.figure(figsize=(6.2, 5))
        a = plt.subplot()
    #    a.axhline(c="k", ls="dashed")
    #    a.axvline(c="k", ls="dashed")
        plt.contourf(x, y, psi[i])
        plt.colorbar()
        plt.axis("equal")
    #    a.legend(loc="best")
        a.set_xlabel("y")
        a.set_ylabel("x")
    #    a.set_xscale('log')
    #    a.set_yscale('log')
    #    a.set_xlim([0, N[-1]*1.05])
        a.set_ylim([0, 1])
    #    plt.gca().invert_xaxis()
    #    plt.gca().invert_yaxis()
        naslov = "$\psi$\nCFL = "+str(f.CFL)+", Re = "+str(f.Re)+", t = "+str(round(i*f.dt, 5))
        a.set_title(naslov)
        plt.savefig(directory+"/psi"+str(i)+".pdf", bbox_inches='tight')
        plt.close(fig)

        fig = plt.figure(figsize=(5,5))
        a = plt.subplot()
        plt.streamplot(x, y, v[i], u[i], color='blue', density=1.1)
        plt.axis("equal")
        a.set_xlabel("y")
        a.set_ylabel("x")
#        a.set_xlim([0, 1])
        a.set_ylim([0, 1])
        naslov = "Hitrostno polje\nCFL = "+str(f.CFL)+", Re = "+str(f.Re)+", t = "+str(round(i*f.dt, 5))
        a.set_title(naslov)
        plt.savefig(directory+"/velocity"+str(i)+".pdf", bbox_inches='tight')
        plt.close(fig)

        fig = plt.figure(figsize=(6.2, 5))
        a = plt.subplot()
    #    a.axhline(c="k", ls="dashed")
    #    a.axvline(c="k", ls="dashed")
        plt.contourf(x, y, u[i])
        plt.colorbar()
        plt.axis("equal")
    #    a.legend(loc="best")
        a.set_xlabel("y")
        a.set_ylabel("x")
    #    a.set_xscale('log')
    #    a.set_yscale('log')
    #    a.set_xlim([0, N[-1]*1.05])
        a.set_ylim([0, 1])
    #    plt.gca().invert_xaxis()
    #    plt.gca().invert_yaxis()
        naslov = "$u$\nCFL = "+str(f.CFL)+", Re = "+str(f.Re)+", t = "+str(round(i*f.dt, 5))
        a.set_title(naslov)
        plt.savefig(directory+"/u"+str(i)+".pdf", bbox_inches='tight')
        plt.close(fig)

        fig = plt.figure(figsize=(6.2, 5))
        a = plt.subplot()
    #    a.axhline(c="k", ls="dashed")
    #    a.axvline(c="k", ls="dashed")
        plt.contourf(x, y, v[i])
        plt.colorbar()
        plt.axis("equal")
    #    a.legend(loc="best")
        a.set_xlabel("x")
        a.set_ylabel("y")
    #    a.set_xscale('log')
    #    a.set_yscale('log')
    #    a.set_xlim([0, N[-1]*1.05])
        a.set_ylim([0, 1])
    #    plt.gca().invert_xaxis()
    #    plt.gca().invert_yaxis()
        naslov = "$v$\nCFL = "+str(f.CFL)+", Re = "+str(f.Re)+", t = "+str(round(i*f.dt, 5))
        a.set_title(naslov)
        plt.savefig(directory+"/v"+str(i)+".pdf", bbox_inches='tight')
        plt.close(fig)

        fig = plt.figure(figsize=(6.2, 5))
        a = plt.subplot()
        #    a.axhline(c="k", ls="dashed")
        #    a.axvline(c="k", ls="dashed")
        plt.contourf(x, y, np.sqrt(u[i]**2 +v[i]**2))
        plt.colorbar()
        plt.axis("equal")
        #    a.legend(loc="best")
        a.set_xlabel("y")
        a.set_ylabel("x")
        #    a.set_xscale('log')
        #    a.set_yscale('log')
        #    a.set_xlim([0, N[-1]*1.05])
        a.set_ylim([0, 1])
        #    plt.gca().invert_xaxis()
        #    plt.gca().invert_yaxis()
        naslov = "|$\\vec{v}$|\nCFL = " + str(f.CFL) + ", Re = " + str(f.Re) + ", t = " + str(round(i * f.dt, 5))
        a.set_title(naslov)
        plt.savefig(directory+ "/abs_v" + str(i) + ".pdf", bbox_inches='tight')
        plt.close(fig)

        if i + len(zeta)//10 >= len(zeta) and k == False:
            i = len(zeta) - 1
            k = True
        else:
            i=i+len(zeta)//40


    t02=time.time()
    cas=t02-t01
    units = " s"
    if cas > 2*60:
        cas = cas/60
        units = " min"
    print(50*"-"+"\nRisanje: Poteklo je "+str(round(cas, 2))+units)

    return plt.show()

## TEST
def SOR(zeta, psi0, u0,v0,dx, maks=10, err=10**-3, alpha=1, prog=True):
    """
    SOR iteration to find psi in \nabla^2 psi = zeta
    """
    t1 = time.time()

    # Variables declaration
    psi_prev = np.copy(psi0)
    psi = np.copy(psi0)

    omega = 2/(1 + alpha*np.pi/len(zeta))

    # Loop over iterations
    k = 0
    while k<maks:
        errors = []

        # Loop over space x and y
        i=1
        while i<len(zeta)-1:
            j=1
            while j<len(zeta[0])-1:

                fun = 0.25 * ( psi[i-1,j] + psi_prev[i+1,j] + psi_prev[i,j+1] + psi[i,j-1] - dx**2*zeta[i,j] )
                psi[i,j] = psi_prev[i,j] + omega*(fun - psi_prev[i,j])

                errors.append( np.abs(fun - psi_prev[i,j]) )

                j=j+1

            i=i+1

        if np.max(errors) <= err:
            if prog == True:
                print("\tBreaking for minimum error! At iteration="+str(k)+", err="+str(round(np.max(errors), 4))+"\n")
            break
        psi_prev = np.copy(psi)

        if prog == True:
            t2=time.time()
            if k%(maks//30) == 0:
                print("\tSOR: "+str(round(k/maks*100 ,2))+" %,  k="+str(k)+", error="+str(round(np.max(errors), 4))+"\t elapsed time = "+str(round((t2-t1)/60, 2))+" min" )
        k=k+1

    return psi #, k-1

def sor(N, xii, psi, eps=10**(-13)):

    xi = xii.flatten()
    u = psi.flatten()
    h=1/N
    alpha=1
    omega=2/(1+alpha*np.pi/(N+1))

    i=0
    while(1):

        cor=0
        for x in range(1, N):
            if x%2==0:
                yy=np.arange(2, N, 2)
            else:
                yy=np.arange(1, N, 2)

            for y in yy:
                nov = 1/4*( u[(N+1)*(x+1) + y] + u[(N+1)*(x-1) + y] + u[(N+1)*x + y+1] + u[(N+1)*x + y-1] - h**2*xi[(N+1)*x + y] )
                delta = omega*(nov - u[(N+1)*x + y])
                cor = cor + delta**2
                u[(N+1)*x + y] = u[(N+1)*x + y] + delta

#                    print("\t"+str([x,y]))

#            print()
        for x in range(1, N):
            if x%2==0:
                yy=np.arange(1, N, 2)
            else:
                yy=np.arange(2, N, 2)

            for y in yy:
                nov = 1/4*( u[(N+1)*(x+1) + y] + u[(N+1)*(x-1) + y] + u[(N+1)*x + y+1] + u[(N+1)*x + y-1] - h**2*xi[(N+1)*x + y] )
                delta = omega*(nov - u[(N+1)*x + y])
                cor = cor + delta**2
                u[(N+1)*x + y] = u[(N+1)*x + y] + delta

#                    print("\t"+str([x,y]))

        i=i+1
        if cor/N**2 < eps:
            break

    # This indent here is very important
    return np.reshape(u, (N+1, N+1))

def test():
    """
    """
    print("test")

    f = First()
    f.N = 40
    f.CFL = 0.05
    f.Re = 10

    f.initialisation()
    u0,v0, zeta0,psi0 = f.initial_condition()

    psi10 = SOR(zeta0, psi0, u0,v0, f.dx, maks=0.5*10**3, err=10**-3, prog=False)
    psi20 = sor(f.N-1, np.array(zeta0), np.array(psi0))

    plt.figure()
    plt.imshow(psi10)
    plt.colorbar()
    plt.title("psi moja \n")

    plt.figure()
    plt.imshow(psi20)
    plt.colorbar()
    plt.title("psi prava \n")

    plt.figure()
    plt.imshow(psi10-psi20)
    plt.colorbar()
    plt.title("psi moja - prava\n")

    return 0


def main():

    t01 = time.time()

    risanje_prva()
#    test()

    t02 = time.time()
    if (t02-t01) >= 20:
        freq = 1000 # ms
        dur = 5  # s
        os.system('play -nq -t alsa synth {} sine {}'.format(dur, freq))
    return 0
main()
