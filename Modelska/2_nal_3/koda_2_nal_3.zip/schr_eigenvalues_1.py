import numpy as np
import matplotlib.pyplot as plt

def k(x,l,e):
    return 2/x - l*(l+1)/(x**2) +e

def R_10(x):
    return x*np.exp(-x)
def R_20(x):
    return x*(1-(1/2)*x)*np.exp(-x/2)

h=0.0001
N=500000
l=0
#for l=0

def a1(e):
    return 1
def a2(e):
    return -1
def a3(e):
    return (1/6)*(2-e)
def a4(e):
    return (1/18)*(-1+2*e)
def a5(e):
    return (1/360)*(2-10*e+3*e*e)

h=0.0001
l=0
#for l=0
e=-1.01
y=[a1(e)*h +a2(e)*h*h + a3(e)*h*h*h + a4(e)*h*h*h*h + a5(e)*h*h*h*h*h,
       a1(e)*2*h +a2(e)*4*h*h + a3(e)*8*h*h*h + a4(e)*16*h*h*h*h + a5(e)*32*h*h*h*h*h]
x=[h,2*h]

for i in range(N):
    a=2*(1-(5/12)*(h**2)*k(2*h +i*h,l,e))*y[i+1]
    b=(1+((h**2)/12)*k(h+i*h,l,e))*y[i]
    c=1+((h**2)/12)*k(3*h +i*h,l,e)
    x.append(3*h +i*h)
    y.append((a-b)/c)

x=np.array(x)

plt.figure(0)
plt.plot(x,y,alpha=0.7)
#plt.plot(x,R_20(x),'--',alpha=0.5)
plt.show()


