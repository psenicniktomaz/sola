import numpy as np
import matplotlib.pyplot as plt


#najprej lomni količnik
def n(x):
    if x<1:
        n=2-0.5*x*x
        return n
    else:
        n=1
        return n



#definicija začetnih dveh točk
def a0():
    return 1

def a2(l,k):
    return (1/4)*(l*l-4*k*k)

def a4(l,k):
    return (1/64)*(8*k*k +16*k*k*k*k -8*k*k*l*l + l*l*l*l)

def K(x,k,l):
    return (1/(4*x*x)) + n(x)*n(x)*k*k -l*l

h=0.0001
k=3
l=2.9

y=[np.sqrt(h)*(a0() + a2(l,k)*h*h + a4(l,k)*h*h*h*h),
       np.sqrt(2*h)*(a0() + a2(l,k)*h*h*4 + a4(l,k)*h*h*h*h*16)]
x=[h,2*h]

N=500000
for i in range(N):
    a = 2 * (1 - (5 / 12) * (h ** 2) * K(2 * h + i * h, k, l)) * y[i + 1]
    b = (1 + ((h ** 2) / 12) * K(h + i * h, k, l)) * y[i]
    c = 1 + ((h ** 2) / 12) * K(3 * h + i * h, k, l)
    x.append(3 * h + i * h)
    y.append((a - b) / c)
    X = 3 * h + i * h

plt.figure(0)
plt.plot(x,y, label=r'k=3 , $\lambda$=2.9',alpha=0.7)


k=4
l=3.9

y=[np.sqrt(h)*(a0() + a2(l,k)*h*h + a4(l,k)*h*h*h*h),
       np.sqrt(2*h)*(a0() + a2(l,k)*h*h*4 + a4(l,k)*h*h*h*h*16)]
x=[h,2*h]

for i in range(N):
    a = 2 * (1 - (5 / 12) * (h ** 2) * K(2 * h + i * h, k, l)) * y[i + 1]
    b = (1 + ((h ** 2) / 12) * K(h + i * h, k, l)) * y[i]
    c = 1 + ((h ** 2) / 12) * K(3 * h + i * h, k, l)
    x.append(3 * h + i * h)
    y.append((a - b) / c)
    X = 3 * h + i * h

plt.figure(0)
plt.plot(x,y, label=r'k=4 , $\lambda$=3.9',alpha=0.7)


k = 2
l = 1

y = [np.sqrt(h) * (a0() + a2(l, k) * h * h + a4(l, k) * h * h * h * h),
     np.sqrt(2 * h) * (a0() + a2(l, k) * h * h * 4 + a4(l, k) * h * h * h * h * 16)]
x = [h, 2 * h]

for i in range(N):
    a = 2 * (1 - (5 / 12) * (h ** 2) * K(2 * h + i * h, k, l)) * y[i + 1]
    b = (1 + ((h ** 2) / 12) * K(h + i * h, k, l)) * y[i]
    c = 1 + ((h ** 2) / 12) * K(3 * h + i * h, k, l)
    x.append(3 * h + i * h)
    y.append((a - b) / c)
    X = 3 * h + i * h

plt.figure(0)
plt.plot(x, y, label=r'k=2 , $\lambda$=1',alpha=0.7)



k = 2
l = 1.99

y = [np.sqrt(h) * (a0() + a2(l, k) * h * h + a4(l, k) * h * h * h * h),
     np.sqrt(2 * h) * (a0() + a2(l, k) * h * h * 4 + a4(l, k) * h * h * h * h * 16)]
x = [h, 2 * h]

for i in range(N):
    a = 2 * (1 - (5 / 12) * (h ** 2) * K(2 * h + i * h, k, l)) * y[i + 1]
    b = (1 + ((h ** 2) / 12) * K(h + i * h, k, l)) * y[i]
    c = 1 + ((h ** 2) / 12) * K(3 * h + i * h, k, l)
    x.append(3 * h + i * h)
    y.append((a - b) / c)
    X = 3 * h + i * h

plt.figure(0)
plt.plot(x, y, label=r'k=2 , $\lambda$=1.99',alpha=0.7)
plt.legend(loc=0,frameon=False)
plt.ylabel(r'$R(x)$')
plt.xlabel('x')
plt.grid()
plt.savefig('propagacija_svetlobe_1.png')