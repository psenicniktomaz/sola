import numpy as np
import matplotlib.pyplot as plt


#najprej lomni količnik
def n(x):
    if x<1:
        n=2-0.5*x*x
        return n
    else:
        n=1
        return n


#definicija začetnih dveh točk
def a0():
    return 1

def a2(l,k):
    return (1/4)*(l*l-4*k*k)

def a4(l,k):
    return (1/64)*(8*k*k +16*k*k*k*k -8*k*k*l*l + l*l*l*l)

def K(x,k,l):
    return (1/(4*x*x)) + n(x)*n(x)*k*k -l*l

h=0.0001
x1=[]
y1=[]
x2=[]
y2=[]
x3=[]
y3=[]
x4=[]
y4=[]
x5=[]
y5=[]

KK=np.arange(0.8,10,0.05)
for k in KK:
    L=np.arange(k+0.5,20,0.05)

    Y=[]
    XX=[]
    LL=[]
    j=0
    m=0
    for l in L:
        y=[np.sqrt(h)*(a0() + a2(l,k)*h*h + a4(l,k)*h*h*h*h),
           np.sqrt(2*h)*(a0() + a2(l,k)*h*h*4 + a4(l,k)*h*h*h*h*16)]
        x=[h,2*h]
        i = 0
        d = 0
        while np.abs(d) < 10:
            a = 2 * (1 - (5 / 12) * (h ** 2) * K(2 * h + i * h, k, l)) * y[i + 1]
            b = (1 + ((h ** 2) / 12) * K(h + i * h, k, l)) * y[i]
            c = 1 + ((h ** 2) / 12) * K(3 * h + i * h, k, l)
            d=(a - b) / c
            x.append(3 * h + i * h)
            y.append(d)
            X = 3*h + i*h
            i = i + 1


        Y.append(d)
        XX.append(X)
        LL.append(l)
        print(Y[j], l, X,k)
        j = j + 1
    Y=np.array(Y)
    XX=np.array(XX)
    LL=np.array(LL)
    I=[]
    for i in range(1,len(Y)):
        if Y[i-1]*Y[i]<0:
            m=m+1
            I.append(i)
    if m==1:
        x1.append(k)
        i=I[m-1]
        y1.append((LL[i-1]+LL[i])/2)
    elif m==2:
        x1.append(k)
        i=I[m-1]
        y1.append((LL[i - 1] + LL[i]) / 2)
        x2.append(k)
        i=I[m-2]
        y2.append((LL[i-1]+LL[i])/2)
    elif m==3:
        x1.append(k)
        i = I[m - 1]
        y1.append((LL[i - 1] + LL[i]) / 2)
        x2.append(k)
        i = I[m - 2]
        y2.append((LL[i - 1] + LL[i]) / 2)
        x3.append(k)
        i = I[m - 3]
        y3.append((LL[i - 1] + LL[i]) / 2)
    elif m==4:
        x1.append(k)
        i = I[m - 1]
        y1.append((LL[i - 1] + LL[i]) / 2)
        x2.append(k)
        i = I[m - 2]
        y2.append((LL[i - 1] + LL[i]) / 2)
        x3.append(k)
        i = I[m - 3]
        y3.append((LL[i - 1] + LL[i]) / 2)
        x4.append(k)
        i = I[m - 4]
        y4.append((LL[i - 1] + LL[i]) / 2)
    elif m==5:
        x1.append(k)
        i = I[m - 1]
        y1.append((LL[i - 1] + LL[i]) / 2)
        x2.append(k)
        i = I[m - 2]
        y2.append((LL[i - 1] + LL[i]) / 2)
        x3.append(k)
        i = I[m - 3]
        y3.append((LL[i - 1] + LL[i]) / 2)
        x4.append(k)
        i = I[m - 4]
        y4.append((LL[i - 1] + LL[i]) / 2)
        x5.append(k)
        i = I[m - 5]
        y5.append((LL[i - 1] + LL[i]) / 2)

'''print(x1,y1)
print(x2,y2)
print(x3,y3)
print(x4,y4)
print(x5,y5)'''

plt.figure(0)
plt.plot(x1,y1)
plt.plot(x2,y2)
plt.plot(x3,y3)
plt.plot(x4,y4)
plt.plot(x5,y5)
plt.ylabel(r'$\lambda$')
plt.xlabel(r'k')
plt.grid()
plt.savefig('disperzija.png')


