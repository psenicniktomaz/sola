import numpy as np
import matplotlib.pyplot as plt

def k(x,l,e):
    return 2/x - l*(l+1)/(x**2) +e

def R_10(x):
    return x*np.exp(-x)
def R_20(x):
    return x*(1-(1/2)*x)*np.exp(-x/2)

h=0.0001
N=[50000,100000]
l=0
#for l=0

def a1(e):
    return 1
def a2(e):
    return -1
def a3(e):
    return (1/6)*(2-e)
def a4(e):
    return (1/18)*(-1+2*e)
def a5(e):
    return (1/360)*(2-10*e+3*e*e)

E1=np.arange(-1.05,-0.95, 0.005)
E2=np.arange(-0.9,-0.3,0.05)
E3=np.arange(-0.29,-0.23,0.005)
E4=np.arange(-0.22,-0.13,0.01)
E5=np.arange(-0.12,-0.09,0.005)
E6=np.arange(-0.07,-0.05,0.002)
E7=np.arange(-0.044,-0.019,0.002)
E=[]
E=np.append(E,E1)
E=np.append(E,E2)
E=np.append(E,E3)
E=np.append(E,E4)
E=np.append(E,E5)
E=np.append(E,E6)
E=np.append(E,E7)


Y=[]
XX=[]
j=0
for e in E:
    y=[a1(e)*h +a2(e)*h*h + a3(e)*h*h*h + a4(e)*h*h*h*h + a5(e)*h*h*h*h*h,
       a1(e)*2*h +a2(e)*4*h*h + a3(e)*8*h*h*h + a4(e)*16*h*h*h*h + a5(e)*32*h*h*h*h*h]
    x=[h,2*h]
    i=0
    d=0
    while np.abs(d) < 10**2:
        a=2*(1-(5/12)*(h**2)*k(2*h +i*h,l,e))*y[i+1]
        b=(1+((h**2)/12)*k(h+i*h,l,e))*y[i]
        c=1+((h**2)/12)*k(3*h +i*h,l,e)
        d=(a-b)/c
        x.append(3*h +i*h)
        y.append(d)
        X=3*h +i*h
        i=i+1

    Y.append(d)
    XX.append(X)
    print(Y[j],e,X)
    j=j+1




plt.figure(0)
plt.plot(E,Y,alpha=0.7)
#plt.plot(x,R_20(x),'--',alpha=0.5)
plt.axhline(y=0,color='black')
plt.grid()
plt.ylabel('amplituda divergence')
plt.xlabel(r'$\epsilon$')
plt.savefig('schr_eigenvalues_2.png')

plt.figure(1)
plt.plot(E,XX,alpha=0.7)
plt.grid()
plt.xlabel(r'$\epsilon$')
plt.ylabel('x (pot) divergence')
plt.savefig('schr_eigenvalues_2_pot.png')

plt.show()
