import numpy as np
import matplotlib.pyplot as plt

def n(x):
    if x<1:
        n=2-0.5*x*x
        return n
    else:
        n=1
        return n

x=np.arange(0,2.1,0.005)
N=[]
for i in range(len(x)):
    N.append(n(x[i]))
N=np.array(N)

plt.figure(0)
plt.plot(x,N,'-',markersize=0.5)
plt.savefig('lomni_kolicnik.png')
