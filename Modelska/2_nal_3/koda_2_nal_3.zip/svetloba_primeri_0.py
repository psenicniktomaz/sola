import numpy as np
import matplotlib.pyplot as plt


#najprej lomni količnik
def n(x):
    if x<1:
        n=2-0.5*x*x
        return n
    else:
        n=1
        return n



#definicija začetnih dveh točk
def a0():
    return 1

def a2(l,k):
    return (1/4)*(l*l-4*k*k)

def a4(l,k):
    return (1/64)*(8*k*k +16*k*k*k*k -8*k*k*l*l + l*l*l*l)

def K(x,k,l):
    return (1/(4*x*x)) + n(x)*n(x)*k*k -l*l

h=0.0001
k=2
l=3.2321

y=[np.sqrt(h)*(a0() + a2(l,k)*h*h + a4(l,k)*h*h*h*h),
       np.sqrt(2*h)*(a0() + a2(l,k)*h*h*4 + a4(l,k)*h*h*h*h*16)]
x=[h,2*h]

N=26000
for i in range(N):
    a = 2 * (1 - (5 / 12) * (h ** 2) * K(2 * h + i * h, k, l)) * y[i + 1]
    b = (1 + ((h ** 2) / 12) * K(h + i * h, k, l)) * y[i]
    c = 1 + ((h ** 2) / 12) * K(3 * h + i * h, k, l)
    x.append(3 * h + i * h)
    y.append((a - b) / c)
    X = 3 * h + i * h

plt.figure(0)
plt.plot(x,y, label=r'k=2 , $\lambda$=3.232',alpha=0.7)


plt.legend(loc=0,frameon=False)
plt.ylabel(r'$R(x)$')
plt.xlabel('x')
plt.grid()
plt.savefig('svetloba_primeri_0_1.png')


k=5
l=5.331

y=[np.sqrt(h)*(a0() + a2(l,k)*h*h + a4(l,k)*h*h*h*h),
       np.sqrt(2*h)*(a0() + a2(l,k)*h*h*4 + a4(l,k)*h*h*h*h*16)]
x=[h,2*h]

N=30000
for i in range(N):
    a = 2 * (1 - (5 / 12) * (h ** 2) * K(2 * h + i * h, k, l)) * y[i + 1]
    b = (1 + ((h ** 2) / 12) * K(h + i * h, k, l)) * y[i]
    c = 1 + ((h ** 2) / 12) * K(3 * h + i * h, k, l)
    x.append(3 * h + i * h)
    y.append((a - b) / c)
    X = 3 * h + i * h

plt.figure(1)
plt.plot(x,y, label=r'k=5 , $\lambda$=5.331',alpha=0.7)


l=7.641725
y=[np.sqrt(h)*(a0() + a2(l,k)*h*h + a4(l,k)*h*h*h*h),
       np.sqrt(2*h)*(a0() + a2(l,k)*h*h*4 + a4(l,k)*h*h*h*h*16)]
x=[h,2*h]

N=30000
for i in range(N):
    a = 2 * (1 - (5 / 12) * (h ** 2) * K(2 * h + i * h, k, l)) * y[i + 1]
    b = (1 + ((h ** 2) / 12) * K(h + i * h, k, l)) * y[i]
    c = 1 + ((h ** 2) / 12) * K(3 * h + i * h, k, l)
    x.append(3 * h + i * h)
    y.append((a - b) / c)
    X = 3 * h + i * h

plt.figure(1)
plt.plot(x,y, label=r'k=5 , $\lambda$=7.6417',alpha=0.7)


l=9.28121252
y=[np.sqrt(h)*(a0() + a2(l,k)*h*h + a4(l,k)*h*h*h*h),
       np.sqrt(2*h)*(a0() + a2(l,k)*h*h*4 + a4(l,k)*h*h*h*h*16)]
x=[h,2*h]

N=30000
for i in range(N):
    a = 2 * (1 - (5 / 12) * (h ** 2) * K(2 * h + i * h, k, l)) * y[i + 1]
    b = (1 + ((h ** 2) / 12) * K(h + i * h, k, l)) * y[i]
    c = 1 + ((h ** 2) / 12) * K(3 * h + i * h, k, l)
    x.append(3 * h + i * h)
    y.append((a - b) / c)
    X = 3 * h + i * h

plt.figure(1)
plt.plot(x,y, label=r'k=5 , $\lambda$=9.2812',alpha=0.7)

plt.legend(loc=0,frameon=False)
plt.ylabel(r'$R(x)$')
plt.xlabel('x')
plt.grid()
plt.savefig('svetloba_primeri_0_2.png')