import numpy.linalg as LA
import numpy as np

m=100 #za matriko mxm

#korak med točkama
h=0.0001


# definicija q funkcije
def q(x,l):
    return -2/x + l*(l+1)/(x**2)


#naredimo D matriko
D=np.zeros((m,m))
for i in range(m):
    D[i][i]=2
for i in range(m-1):
    D[i+1,i]=-1
    D[i,i+1]=-1

#print('matrika D =\n',D)

#naredimo matriko Q za dan l
l=0
Q=np.zeros((m,m))
for i in range(m):
    Q[i,i]=q(h+i*h,l)

#print('\n matrika Q =\n',Q)

#naredimo matriko M
I=np.identity(m)
M=I-(1/12)*D
#print('\n matrika M =\n',M)

Minv=LA.inv(M)
A=(1/(h**2))*D +np.matmul(M,Q)
#print(np.matmul(M,Q))
lam=LA.eig(np.matmul(Minv,A))
print(lam[0])

