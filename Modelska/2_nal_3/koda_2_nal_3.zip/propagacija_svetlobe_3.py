import numpy as np
import matplotlib.pyplot as plt


#najprej lomni količnik
def n(x):
    if x<1:
        n=2-0.5*x*x
        return n
    else:
        n=1
        return n


#definicija začetnih dveh točk
def a0():
    return 1

def a2(l,k):
    return (1/4)*(l*l-4*k*k)

def a4(l,k):
    return (1/64)*(8*k*k +16*k*k*k*k -8*k*k*l*l + l*l*l*l)

def K(x,k,l):
    return (1/(4*x*x)) + n(x)*n(x)*k*k -l*l

h=0.0001
k=10
L=np.arange(10.1,30,0.1)

Y=[]
XX=[]
j=0
for l in L:
    y=[np.sqrt(h)*(a0() + a2(l,k)*h*h + a4(l,k)*h*h*h*h),
       np.sqrt(2*h)*(a0() + a2(l,k)*h*h*4 + a4(l,k)*h*h*h*h*16)]
    x=[h,2*h]
    i = 0
    d = 0
    while np.abs(d) < 20:
        a = 2 * (1 - (5 / 12) * (h ** 2) * K(2 * h + i * h, k, l)) * y[i + 1]
        b = (1 + ((h ** 2) / 12) * K(h + i * h, k, l)) * y[i]
        c = 1 + ((h ** 2) / 12) * K(3 * h + i * h, k, l)
        d=(a - b) / c
        x.append(3 * h + i * h)
        y.append(d)
        X = 3*h + i*h
        i = i + 1


    Y.append(d)
    XX.append(X)
    print(Y[j], l, X)
    j = j + 1

plt.figure(0)
plt.plot(L,Y,alpha=0.7,label='k=10')
plt.axhline(y=0,color='black')
plt.legend(loc=0,frameon=False)
plt.grid()
plt.ylabel('amplituda divergence')
plt.xlabel(r'$\lambda$')
plt.savefig('propagacija_svetlobe_3_0.png')





k=10
L=[]
L1=np.arange(11.8,11.9,0.002)
L2=np.arange(14.2,14.4,0.002)
L3=np.arange(16.1,16.3,0.002)
L4=np.arange(17.8,17.9,0.002)
L5=np.arange(19.2,19.3,0.002)
L=np.append(L,L1)
L=np.append(L,L2)
L=np.append(L,L3)
L=np.append(L,L4)
L=np.append(L,L5)



Y=[]
XX=[]
j=0
for l in L:
    y=[np.sqrt(h)*(a0() + a2(l,k)*h*h + a4(l,k)*h*h*h*h),
       np.sqrt(2*h)*(a0() + a2(l,k)*h*h*4 + a4(l,k)*h*h*h*h*16)]
    x=[h,2*h]
    i = 0
    d = 0
    while np.abs(d) < 20:
        a = 2 * (1 - (5 / 12) * (h ** 2) * K(2 * h + i * h, k, l)) * y[i + 1]
        b = (1 + ((h ** 2) / 12) * K(h + i * h, k, l)) * y[i]
        c = 1 + ((h ** 2) / 12) * K(3 * h + i * h, k, l)
        d=(a - b) / c
        x.append(3 * h + i * h)
        y.append(d)
        X = 3*h + i*h
        i = i + 1


    Y.append(d)
    XX.append(X)
    print(Y[j], l, X)
    j = j + 1

plt.figure(1)
plt.plot(L,Y,alpha=0.7,label='k=10')
plt.axhline(y=0,color='black')
plt.grid()
plt.legend(loc=0,frameon=False)
plt.ylabel('amplituda divergence')
plt.xlabel(r'$\lambda$')
plt.savefig('propagacija_svetlobe_3_1.png')