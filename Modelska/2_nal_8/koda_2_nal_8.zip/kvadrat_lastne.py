import numpy as np
from scipy.spatial import Delaunay
from scipy.spatial import delaunay_plot_2d
import matplotlib.pyplot as plt
from scipy.sparse.linalg import eigsh


m=10
n=10
M=m
N=n

def pravokotnik(m,n):
    h_m = 1 / (m-1)
    h_n = 1 / (n-1)
    x = np.arange(1, m-1,1)/(m-1); y = np.arange(1, n-1,1)/(n-1)  # excludes boundary nodes
    U=[]
    inn=0
    for i in range(len(x)):
        for j in range(len(y)):
            U.append([x[i],y[j]])
            inn=inn+1

    #boundary nodes
    #left
    bound=0
    y = np.arange(0, n, 1) / (n - 1)
    for i in range(len(y)):
        U.append([0, y[i]])
        bound=bound+1

    # top
    for i in range(len(x)):
        U.append([x[i], 1])
        bound = bound + 1

    #right
    for i in range(len(y)):
        U.append([1, y[i]])
        bound = bound + 1
    #bottom
    x = np.arange(1, m - 1, 1) / (m - 1)
    for i in range(len(x)):
        U.append([x[i], 0])
        bound = bound + 1

    return U, inn, bound

tri=Delaunay(pravokotnik(m,n)[0],furthest_site=False) #triangulation
nodes=tri.simplices  # we get the nodes of triangles
#print(nodes)
points=pravokotnik(m,n)[0] #coordinates of the points
#print(points)
in_points=pravokotnik(m,n)[1]
out_points=pravokotnik(m,n)[2]

print('število notranjih točk',in_points)
print('število zunanjih točk',out_points)

A=np.zeros((n*m,n*m))
B=np.zeros((n*m,n*m))
T=len(nodes)
k=0
for i in range(T):
    l,m,n= nodes[k][0],nodes[k][1],nodes[k][2] # x1, x2 and x3 nodes of triangle; not the coordinates
    # print(l,m,n)
    Pe=[[1 ,points[l][0], points[l][1]],
        [1 ,points[m][0], points[m][1]],
        [1 ,points[n][0], points[n][1]]] # matrix with 1,x1,x2,x3,y1,y2,y3
    Pe=np.array(Pe) # matrix for a triangle
    jac_det=np.linalg.det(Pe) # 2 * area of the triangle

    # computing local A_k matrix elements

    A11=((points[m][1]-points[n][1])**2 +(points[n][0]-points[m][0])**2)/(2*jac_det)
    A12=((points[m][1]-points[n][1])*(points[n][1]-points[l][1]) +
         (points[n][0]-points[m][0])*(points[l][0]-points[n][0]))/(2*jac_det)
    A13=((points[m][1]-points[n][1])*(points[l][1]-points[m][1]) +
         (points[n][0]-points[m][0])*(points[m][0]-points[l][0]))/(2*jac_det)
    A22=((points[n][1]-points[l][1])*(points[n][1]-points[l][1]) +
         (points[l][0]-points[n][0])*(points[l][0]-points[n][0]))/(2*jac_det)
    A23=((points[n][1]-points[l][1])*(points[l][1]-points[m][1]) +
         (points[l][0]-points[n][0])*(points[m][0]-points[l][0]))/(2*jac_det)
    A33=((points[l][1]-points[m][1])**2 + (points[m][0]-points[l][0])**2)/(2*jac_det)

    A[l][l]= A[l][l]+A11
    A[l][m]=A[l][m]+ A12; A[m][l]=A[m][l]+A12
    A[l][n]=A[l][n]+ A13; A[n][l]=A[n][l]+A13
    A[m][m]= A[m][m]+A22
    A[m][n]=A[m][n]+A23 ; A[n][m]=A[n][m]+ A23
    A[n][n]=A[n][n]+A33

    # computing local B_k matrix elements
    B11=jac_det/12
    B22=jac_det/12
    B33=jac_det/12
    B12=jac_det/24
    B13=jac_det/24
    B23=jac_det/24

    B[l][l]=B[l][l] + B11
    B[l][m] = B[l][m] + B12
    B[m][l] = B[m][l] + B12
    B[l][n] = B[l][n] + B13
    B[n][l] = B[n][l] + B13
    B[m][m] = B[m][m] + B22
    B[m][n] = B[m][n] + B23
    B[n][m] = B[n][m] + B23
    B[n][n] = B[n][n] + B33

    k=k+1


b=np.arange(M*N -2*(N+M) +4,M*N,1) #boundary nodes
print('število zunanjih točk', len(b))




for i in range(len(points)):
    for j in b:
        A[i][j]=0
        A[j][i]=0
        B[i][j]=0
        B[j][i]=0
for i in b:
    A[i][i]=1
    B[i][i]=1

#print(A)
#print(B)
d=N*M-out_points
print('matrika n x n ; n=' , d)
AA=np.zeros((d,d))
BB=np.zeros((d,d))
for i in range(d):
    for j in range(d):
        AA[i][j]=A[i][j]
        BB[i][j]=B[i][j]

#print(AA)
#print(BB)

'''eigenvalues, eigenvectors = eigsh(AA, k=6, M=BB,which='SM')
print(eigenvalues) # don't know why the fuck 1/2...
#print(eigenvectors)

X=[]
Y=[]
for i in range(len(points)):
    X.append(points[i][0])
    Y.append((points[i][1]))

################
Z=[]
for i in range(d):
    Z.append(eigenvectors[i][0])
for i in range(out_points):
    Z.append(0)
plt.figure(0)
plt.tricontourf(X,Y,Z,levels=15)
plt.colorbar()
plt.axis('equal')
plt.savefig('kvadrat__lastne_1.pdf')



###################
Z=[]
for i in range(d):
    Z.append(eigenvectors[i][1])
for i in range(out_points):
    Z.append(0)


plt.figure(3)
plt.tricontourf(X,Y,Z,levels=15)
plt.colorbar()
plt.axis('equal')
plt.savefig('kvadrat__lastne_2.pdf')


###################
Z=[]
for i in range(d):
    Z.append(eigenvectors[i][2])
for i in range(out_points):
    Z.append(0)


plt.figure(4)
plt.tricontourf(X,Y,Z,levels=15)
plt.colorbar()
plt.axis('equal')
plt.savefig('kvadrat__lastne_3.pdf')


###################
Z=[]
for i in range(d):
    Z.append(eigenvectors[i][3])
for i in range(out_points):
    Z.append(0)


plt.figure(5)
plt.tricontourf(X,Y,Z,levels=15)
plt.colorbar()
plt.axis('equal')
plt.savefig('kvadrat__lastne_4.pdf')


###################
Z=[]
for i in range(d):
    Z.append(eigenvectors[i][4])
for i in range(out_points):
    Z.append(0)


plt.figure(6)
plt.tricontourf(X,Y,Z,levels=15)
plt.colorbar()
plt.axis('equal')
plt.savefig('kvadrat__lastne_5.pdf')


###################
Z=[]
for i in range(d):
    Z.append(eigenvectors[i][5])
for i in range(out_points):
    Z.append(0)


plt.figure(7)
plt.tricontourf(X,Y,Z,levels=15)
plt.colorbar()
plt.axis('equal')
plt.savefig('kvadrat__lastne_6.pdf')'''



plt.figure(1)
plt.imshow(AA,cmap='gray')
plt.colorbar()
plt.savefig('kvadrat_A.pdf')

plt.figure(2)
plt.imshow(BB,cmap='gray')
plt.colorbar()
plt.savefig('kvadrat_B.pdf')


delaunay_plot_2d(tri)
plt.axis('equal')
plt.savefig('kvadrat_tri.pdf')