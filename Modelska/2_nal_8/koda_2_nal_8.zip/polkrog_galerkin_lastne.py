import numpy as np
from scipy.spatial import Delaunay
from scipy.spatial import delaunay_plot_2d
import matplotlib.pyplot as plt
from scipy.sparse.linalg import eigsh
from scipy.linalg import eigh

N=61 #works best for odd numbers
#generating points for triangulation
def polkrog(N):

    #inner points
    inn=0
    h_r=1/(int(N)-1)
    r=np.arange(0+2*h_r, 0.999999, 2*h_r)
    l=3
    R_inn = []
    for j in r:
        R_x = []
        R_y = []
        M=l*2
        h_phi=np.pi/(M-2)
        phi=np.arange(h_phi,np.pi -0.0001,h_phi)
        for i in phi:
            R_x= j * np.cos(i)
            R_y=j * np.sin(i)
            R_inn.append([R_x, R_y])
            inn+=1
        l=l+2


    # outer edge points
    bound=0
    x = np.arange(-N +1, N-1, 2) / (N - 1)
    X = []
    for i in range(len(x)):
        X.append([x[i], 0])
        bound+=1
    X = np.array(X)

    R_x = []
    R_y = []
    R = []
    for i in range(0,2*N,1):
        R_x.append( np.cos(i * np.pi / (2*N-1)))
        R_y.append( np.sin(i * np.pi / (2*N-1)))
        R.append([R_x[i], R_y[i]])
        bound+=1
    R = np.array(R)

    U=np.concatenate((R_inn,X,R))
    #U=R_inn
    return U,inn, bound

def baza(x,y,m,n):
    r=np.sqrt(x**2 +y**2)

    if x > 0 and y > 0:
        phi=np.arctan(y/x)
    else:
        phi = np.pi + np.arctan(y/x)

    u=(r**(m+n))*(1-r)*np.sin(m*phi)

    return u


U=polkrog(N)[0]
b=polkrog(N)[2]
d=polkrog(N)[1]

M=10
N=7

A=np.zeros((M*N,M*N))
B=np.zeros((M*N,M*N))

l=0
for k in range(M):
    for i in range(N):
        for j in range(N):
            B[i+l][j+l]=(np.pi/2)*((1/(2*(k+1) + j + i +2))-(2/(2*(k+1) + j + i +3)) + (1/(2*(k+1) + j + i +4)) )
            A[i+l][j+l]=(np.pi/2)*(((j*i)/(2*(k+1) + j + i))-((2*j*i + j +i)/(2*(k+1) + j + i +1)) + (((j+1)*(i+1))/(2*(k+1) + j + i +2)) )
    l+=N


'''plt.figure(0)
plt.imshow(B,cmap='gray')
plt.colorbar()
plt.savefig('polkrog_galerkin_lastne_B.pdf')

plt.figure(1)
plt.imshow(A,cmap='gray')
plt.colorbar()
plt.savefig('polkrog_galerkin_lastne_A.pdf')'''

dd=15 #number of eigenvectors
eigenvalues, eigenvectors=eigh(A,B,eigvals_only=False,eigvals=(0,dd-1))
print(eigenvalues)
print(eigenvectors)


for f in range(6,dd,1):
    k=0
    Z=np.zeros(len(U))
    Z=np.array(Z)

    for i in eigenvectors[:,f]:
        uu = []
        n=k%N
        m=1+int(k/N)
        k=k+1
        for j in range(d): # inner nodes
            uu.append(baza(x=U[j][0],y=U[j][1],m=m,n=n))
        for j in range(b): # boundary nodes are zero
            uu.append(0)
        uu=np.array(uu)
        Z=Z + uu*i


    plt.figure('%d' %f)
    plt.tricontourf(U[:,0],U[:,1],Z,levels=15)
    plt.colorbar()
    plt.axis('equal')
    plt.savefig('polkrog_galerkin_lastne_%d.pdf' %f)