import numpy as np
from scipy.spatial import Delaunay
from scipy.spatial import delaunay_plot_2d
import matplotlib.pyplot as plt
from scipy.sparse.linalg import eigsh


N=31 #works best for odd numbers
#generating points for triangulation
def polkrog(N):

    #inner points
    inn=0
    h_r=0.5/(int(N)-1)
    r=np.arange(0+2*h_r, 0.49999, 2*h_r)
    l=3
    R_inn = []
    for j in r:
        R_x = []
        R_y = []
        M=l*2
        h_phi=np.pi/(M-2)
        phi=np.arange(h_phi,np.pi -0.0001,h_phi)
        for i in phi:
            R_x=0.5 + j * np.cos(i)
            R_y=j * np.sin(i)
            R_inn.append([R_x, R_y])
            inn+=1
        l=l+2


    # outer edge points
    bound=0
    x = np.arange(1, N - 1, 1) / (N - 1)
    X = []
    for i in range(len(x)):
        X.append([x[i], 0])
        bound+=1
    X = np.array(X)

    R_x = []
    R_y = []
    R = []
    for i in range(0,2*N,1):
        R_x.append(0.5 + 0.5 * np.cos(i * np.pi / (2*N-1)))
        R_y.append(0.5 * np.sin(i * np.pi / (2*N-1)))
        R.append([R_x[i], R_y[i]])
        bound+=1
    R = np.array(R)

    U=np.concatenate((R_inn,X,R))
    #U=R_inn
    return U,inn, bound

tri=Delaunay(polkrog(N)[0],furthest_site=False) #triangulation
nodes=tri.simplices  # we get the nodes of triangles
#print(nodes)
points=polkrog(N)[0] #coordinates of the points
#print(points)
in_points=polkrog(N)[1]
out_points=polkrog(N)[2]

print('število notranjih točk',in_points)
print('število zunanjih točk',out_points)


A=np.zeros((in_points+out_points,in_points+out_points))
B=np.zeros((in_points+out_points,in_points+out_points))
T=len(nodes)
k=0
for i in range(T):
    l,m,n= nodes[k][0],nodes[k][1],nodes[k][2] # x1, x2 and x3 nodes of triangle; not the coordinates
    # print(l,m,n)
    Pe=[[1 ,points[l][0], points[l][1]],
        [1 ,points[m][0], points[m][1]],
        [1 ,points[n][0], points[n][1]]] # matrix with 1,x1,x2,x3,y1,y2,y3
    Pe=np.array(Pe) # matrix for a triangle
    jac_det=np.linalg.det(Pe) # 2 * area of the triangle

    # computing local A_k matrix elements

    A11=((points[m][1]-points[n][1])**2 +(points[n][0]-points[m][0])**2)/(2*jac_det)
    A12=((points[m][1]-points[n][1])*(points[n][1]-points[l][1]) +
         (points[n][0]-points[m][0])*(points[l][0]-points[n][0]))/(2*jac_det)
    A13=((points[m][1]-points[n][1])*(points[l][1]-points[m][1]) +
         (points[n][0]-points[m][0])*(points[m][0]-points[l][0]))/(2*jac_det)
    A22=((points[n][1]-points[l][1])*(points[n][1]-points[l][1]) +
         (points[l][0]-points[n][0])*(points[l][0]-points[n][0]))/(2*jac_det)
    A23=((points[n][1]-points[l][1])*(points[l][1]-points[m][1]) +
         (points[l][0]-points[n][0])*(points[m][0]-points[l][0]))/(2*jac_det)
    A33=((points[l][1]-points[m][1])**2 + (points[m][0]-points[l][0])**2)/(2*jac_det)


    A[l][l]= A[l][l]+A11
    A[l][m]=A[l][m]+ A12; A[m][l]=A[m][l]+A12
    A[l][n]=A[l][n]+ A13; A[n][l]=A[n][l]+A13
    A[m][m]= A[m][m]+A22
    A[m][n]=A[m][n]+A23 ; A[n][m]=A[n][m]+ A23
    A[n][n]=A[n][n]+A33

    # computing local B_k matrix elements
    B11=jac_det/12
    B22=jac_det/12
    B33=jac_det/12
    B12=jac_det/24
    B13=jac_det/24
    B23=jac_det/24

    B[l][l]=B[l][l] + B11
    B[l][m] = B[l][m] + B12
    B[m][l] = B[m][l] + B12
    B[l][n] = B[l][n] + B13
    B[n][l] = B[n][l] + B13
    B[m][m] = B[m][m] + B22
    B[m][n] = B[m][n] + B23
    B[n][m] = B[n][m] + B23
    B[n][n] = B[n][n] + B33

    k=k+1

b=np.arange(in_points, in_points +out_points, 1) #boundary nodes
print(b)
print('število zunanjih točk', len(b))

for i in range(len(points)):
    for j in b:
        A[i][j]=0
        A[j][i]=0
        B[i][j]=0
        B[j][i]=0
for i in b:
    A[i][i]=1
    B[i][i]=1

d=in_points
AA=np.zeros((d,d))
BB=np.zeros((d,d))
for i in range(d):
    for j in range(d):
        AA[i][j]=A[i][j]
        BB[i][j]=B[i][j]


eigenvalues, eigenvectors = eigsh(AA, k=6, M=BB,which='SM')
print(eigenvalues)

X=[]
Y=[]
for i in range(len(points)):
    X.append(points[i][0])
    Y.append((points[i][1]))

##############
Z=[]
for i in range(d):
    Z.append(eigenvectors[i][0])
for i in range(out_points):
    Z.append(0)
plt.figure(0)
plt.tricontourf(X,Y,Z,levels=15)
plt.colorbar()
plt.axis('equal')
plt.savefig('polkrog_lastne_1.pdf')

##############
Z=[]
for i in range(d):
    Z.append(eigenvectors[i][1])
for i in range(out_points):
    Z.append(0)
plt.figure(1)
plt.tricontourf(X,Y,Z,levels=15)
plt.colorbar()
plt.axis('equal')
plt.savefig('polkrog_lastne_2.pdf')

##############
Z=[]
for i in range(d):
    Z.append(eigenvectors[i][2])
for i in range(out_points):
    Z.append(0)
plt.figure(2)
plt.tricontourf(X,Y,Z,levels=15)
plt.colorbar()
plt.axis('equal')
plt.savefig('polkrog_lastne_3.pdf')


##############
Z=[]
for i in range(d):
    Z.append(eigenvectors[i][3])
for i in range(out_points):
    Z.append(0)
plt.figure(3)
plt.tricontourf(X,Y,Z,levels=15)
plt.colorbar()
plt.axis('equal')
plt.savefig('polkrog_lastne_4.pdf')

##############
Z=[]
for i in range(d):
    Z.append(eigenvectors[i][4])
for i in range(out_points):
    Z.append(0)
plt.figure(4)
plt.tricontourf(X,Y,Z,levels=15)
plt.colorbar()
plt.axis('equal')
plt.savefig('polkrog_lastne_5.pdf')

##############
Z=[]
for i in range(d):
    Z.append(eigenvectors[i][5])
for i in range(out_points):
    Z.append(0)
plt.figure(5)
plt.tricontourf(X,Y,Z,levels=15)
plt.colorbar()
plt.axis('equal')
plt.savefig('polkrog_lastne_6.pdf')

plt.figure(6)
plt.imshow(AA,cmap='gray')
plt.colorbar()
plt.savefig('polkrog_A.pdf')


plt.figure(7)
plt.imshow(BB,cmap='gray')
plt.colorbar()
plt.savefig('polkrog_B.pdf')


delaunay_plot_2d(tri)
plt.axis('equal')
plt.savefig('polkrog_tri.pdf')
