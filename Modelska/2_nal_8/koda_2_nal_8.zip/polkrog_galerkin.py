import numpy as np
from scipy.spatial import Delaunay
from scipy.spatial import delaunay_plot_2d
import matplotlib.pyplot as plt
from scipy.sparse.linalg import eigsh

N=51 #works best for odd numbers
#generating points for triangulation
def polkrog(N):

    #inner points
    inn=0
    h_r=1/(int(N)-1)
    r=np.arange(0+2*h_r, 0.999999, 2*h_r)
    l=3
    R_inn = []
    for j in r:
        R_x = []
        R_y = []
        M=l*2
        h_phi=np.pi/(M-2)
        phi=np.arange(h_phi,np.pi -0.0001,h_phi)
        for i in phi:
            R_x= j * np.cos(i)
            R_y=j * np.sin(i)
            R_inn.append([R_x, R_y])
            inn+=1
        l=l+2


    # outer edge points
    bound=0
    x = np.arange(-N +1, N-1, 2) / (N - 1)
    X = []
    for i in range(len(x)):
        X.append([x[i], 0])
        bound+=1
    X = np.array(X)

    R_x = []
    R_y = []
    R = []
    for i in range(0,2*N,1):
        R_x.append( np.cos(i * np.pi / (2*N-1)))
        R_y.append( np.sin(i * np.pi / (2*N-1)))
        R.append([R_x[i], R_y[i]])
        bound+=1
    R = np.array(R)

    U=np.concatenate((R_inn,X,R))
    #U=R_inn
    return U,inn, bound

U=polkrog(N)[0]
b=polkrog(N)[2]
d=polkrog(N)[1]
print(U)

def baza(x,y,m,n):
    r=np.sqrt(x**2 +y**2)

    if x > 0 and y > 0:
        phi=np.arctan(y/x)
    else:
        phi = np.pi + np.arctan(y/x)

    u=(r**(m+n))*(1-r)*np.sin(m*phi)

    return u



for m in range(1,4,1):
    for n in range(0,3):
        Z=[]
        for i in range(d):
            Z.append(baza(x=U[i][0],y=U[i][1],m=m,n=n))
        for i in range(b):
            Z.append(0)


        plt.figure('%d%d' %(m,n))
        plt.tricontourf(U[:,0],U[:,1],Z,levels=15)
        plt.colorbar()
        plt.axis('equal')
        plt.savefig('polkrog_galerkin_baznefun_%d%d.pdf' %(m,n))


'''tri=Delaunay(polkrog(N)[0],furthest_site=False) #triangulation

delaunay_plot_2d(tri)
plt.axis('equal')
plt.show()'''
