import numpy as np
import matplotlib.pyplot as plt

#preberimo vsako vrstico posbej
file=open("lik_omega_iteracije_41.dat","r")
vrstice=[]
for line in file:
    fields = line.split("\t")
    vrstice.append(fields)
file.close()

#odstranimo prva dva elementa ker nista kul
vrstice.pop(0)
N=len(vrstice)
n=np.zeros(N)
omega=np.zeros(N)
for i in range(N):
    n[i]=vrstice[i][0]
    omega[i]=vrstice[i][1]

plt.figure(0)
plt.plot(omega,n,label='N=41')



file=open("lik_omega_iteracije_61.dat","r")
vrstice=[]
for line in file:
    fields = line.split("\t")
    vrstice.append(fields)
file.close()

#odstranimo prva dva elementa ker nista kul
vrstice.pop(0)
N=len(vrstice)
n=np.zeros(N)
omega=np.zeros(N)
for i in range(N):
    n[i]=vrstice[i][0]
    omega[i]=vrstice[i][1]

plt.figure(0)
plt.plot(omega,n,label='N=61')


file=open("lik_omega_iteracije_81.dat","r")
vrstice=[]
for line in file:
    fields = line.split("\t")
    vrstice.append(fields)
file.close()

#odstranimo prva dva elementa ker nista kul
vrstice.pop(0)
N=len(vrstice)
n=np.zeros(N)
omega=np.zeros(N)
for i in range(N):
    n[i]=vrstice[i][0]
    omega[i]=vrstice[i][1]

plt.figure(0)
plt.plot(omega,n,label='N=81')

file=open("lik_omega_iteracije_101.dat","r")
vrstice=[]
for line in file:
    fields = line.split("\t")
    vrstice.append(fields)
file.close()

#odstranimo prva dva elementa ker nista kul
vrstice.pop(0)
N=len(vrstice)
n=np.zeros(N)
omega=np.zeros(N)
for i in range(N):
    n[i]=vrstice[i][0]
    omega[i]=vrstice[i][1]

plt.figure(0)
plt.plot(omega,n,label='N=101')




file=open("lik_omega_iteracije_121.dat","r")
vrstice=[]
for line in file:
    fields = line.split("\t")
    vrstice.append(fields)
file.close()

#odstranimo prva dva elementa ker nista kul
vrstice.pop(0)
N=len(vrstice)
n=np.zeros(N)
omega=np.zeros(N)
for i in range(N):
    n[i]=vrstice[i][0]
    omega[i]=vrstice[i][1]

plt.figure(0)
plt.plot(omega,n,label='N=121')



file=open("lik_omega_iteracije_141.dat","r")
vrstice=[]
for line in file:
    fields = line.split("\t")
    vrstice.append(fields)
file.close()

#odstranimo prva dva elementa ker nista kul
vrstice.pop(0)
N=len(vrstice)
n=np.zeros(N)
omega=np.zeros(N)
for i in range(N):
    n[i]=vrstice[i][0]
    omega[i]=vrstice[i][1]

plt.figure(0)
plt.plot(omega,n,label='N=141')


plt.figure(0)
plt.legend(loc=0,frameon=False)
plt.grid()
plt.xlabel(r'$\omega$')
plt.ylabel('#iteracij')
plt.savefig('omega.png')