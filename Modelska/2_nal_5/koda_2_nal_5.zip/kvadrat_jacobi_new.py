import numpy as np
import matplotlib.pyplot as plt

N=50
h=1/N
print(h)
U=np.zeros((N,N))
U=np.matrix(U)
for i in range(1,N-1):
    for j in range(1,N-1):
        U[i,j]=1

X=np.arange(0+1/(2*N),1+1/(2*N),1/N)
Y=np.arange(0+1/(2*N),1+1/(2*N),1/N)

XX,YY=np.meshgrid(X,Y)

print(X)
plt.figure(0)
plt.imshow(U,cmap='gray')
plt.colorbar()
plt.savefig('kvadrat_jacobi_new_0.png')

def Q(j,k): #brez tistega h odspodi
    return -(4*U[j,k] - U[j-1,k]-U[j+1,k]-U[j,k-1]-U[j,k+1])*U[j,k]

def jacobi(j,k): #brez tistega h odspodi
    return U[j+1,k] + U[j-1,k] + U[j,k+1] + U[j,k-1]

u=np.zeros((N,N))
u=np.matrix(u)


S_last=np.matrix.sum(U)

S_new=S_last+50
iteracija=0
while np.abs(S_new-S_last) > 0.01:
    S_last=S_new
    #print(u)
    for i in range(0,N):
        for j in range(0,N):
            if U[i, j] == 0:
                continue
            else:
                u[i, j] = (Q(i, j) + jacobi(i, j)) / 4
    S_new=np.matrix.sum(u)
    U=u
    print(iteracija)
    iteracija=iteracija +1
    #print(u)

print(u)
plt.figure(2)
plt.imshow(U,cmap='gray')
plt.colorbar()
plt.savefig('kvadrat_jacobi_new_2.png')


Z=np.zeros((N,N))
for i in range(N):
    for j in range(N):
        Z[i][j]=u[i,j]
plt.figure(1)
plt.contourf(XX,YY,Z)
plt.colorbar()
plt.axis('equal')
plt.savefig('kvadrat_jacobi_new_1.png')