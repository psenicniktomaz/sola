import numpy as np
import matplotlib.pyplot as plt
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import cm
from matplotlib.ticker import LinearLocator, FormatStrFormatter
import numpy as np
from mpl_toolkits.mplot3d import Axes3D

#2D simspon works only for odd numbers
N=101 #zagotovo delujejo števila N deljiva s 4, ; k N prištejemo +1
h=1/N
print(h)
U=np.zeros((N,N))
U=np.matrix(U)


W=np.zeros((N,N))
W=np.matrix(W)
#2D simspon matrix W
for i in range(N):
    for j in range(N):
        if i ==0:
            if j==0 or j==N-1:
                W[i,j]=1
            elif j%2==1:
                W[i,j]=4
            else:
                W[i,j]=2
        elif i <N-1:
            if i%2==1:
                if j == 0 or j == N - 1:
                    W[i, j] = 4
                elif j % 2 == 1:
                    W[i, j] = 16
                else:
                    W[i, j] = 8
            else:
                if j == 0 or j == N - 1:
                    W[i, j] = 2
                elif j % 2 == 1:
                    W[i, j] = 8
                else:
                    W[i, j] = 4
        else:
            if j==0 or j==N-1:
                W[i,j]=1
            elif j%2==1:
                W[i,j]=4
            else:
                W[i,j]=2

X=np.arange(0+1/(2*N),1+1/(2*N),1/N)
Y=np.arange(1+1/(2*N),0+1/(2*N),-1/N)

XX,YY=np.meshgrid(X,Y)



#za lik
plt.figure(1)
x=[X[0],X[int(N/4)],X[int(N/2)],X[int(3*N/4)],X[N-1],X[N-1],
   X[int(3*N/4)],X[int(N/4)],X[0],X[0]]
y=[Y[int(N/4)],Y[0],Y[int(N/4)],Y[0],Y[int(N/4)],Y[int(3*N/4)],
   Y[N-1],Y[N-1],Y[int(3*N/4)],Y[int(N/4)]]
plt.plot(x,y,'-',c='#1f77b4')
x=[X[int(N/4)],X[int(N/2)],X[int(3*N/4)],X[int(3*N/4)],
   X[int(N/4)],X[int(N/4)]]
y=[Y[int(N/4)],Y[int(N/2)],Y[int(N/4)],Y[int(3*N/4)],
   Y[int(3*N/4)],Y[int(N/4)]]
plt.plot(x,y,'-',c='#1f77b4')
plt.axis('equal')

#definiton of our geometric shape
def lik(N):
    k = 0
    for i in range(1, int(N / 4)):
        for j in range(int(N / 4) - int(k), int(N / 4) + int(k) + 1):
            U[i, j] = 1
        k = k + 1

    k = 0
    for i in range(1, int(N / 2)):
        for j in range(int(3 * N / 4) - int(k), int(3 * N / 4) + int(k) + 1):
            U[i, j] = 1
        k = k + 1
        if k > N / 4 - 2:
            break

    for i in range(int(N / 4), int(3 * N / 4) + 1):
        for j in range(1, int(N / 4)):
            U[i, j] = 1

    for i in range(int(N / 4), int(3 * N / 4) + 1):
        for j in range(int(3 * N / 4) + 1, N - 1):
            U[i, j] = 1

    k = 0
    for i in range(int(N / 4), int(N / 2)):
        for j in range(int(N / 4) + k + 1, int(N / 2)):
            U[i, j] = 1
        k = k + 1
        if k > N / 4:
            break

    for i in range(int(N / 4) + 1, int(N / 2)):
        U[i, int(N / 2)] =1

    k = 0
    for i in range(int(N / 4), int(N / 2)):
        for j in range(int(N / 2) + 1, int(3 * N / 4) - k):
            U[i, j] = 1
        k = k + 1
        if k > N / 4:
            break

    k = 0
    for i in range(int(3 * N / 4) + 1, int(N)):
        for j in range(k + 2, int(N / 4)):
            U[i, j] = 1
        k = k + 1
        if k > N / 4 - 1:
            break

    for i in range(int(3 * N / 4) + 1, int(N) - 1):
        for j in range(int(N / 4), int(3 * N / 4) + 1):
            U[i, j] = 1

    k = 0
    for i in range(int(3 * N / 4) + 1, int(N) - 1):
        for j in range(int(3 * N / 4) + 1, int(N) - k - 2):
            U[i, j] = 1
        k = k + 1
        if k > N / 4 - 2:
            break
    return U

U=lik(N)


plt.figure(0)
plt.imshow(U,cmap='gray')
plt.colorbar()
plt.savefig('lik_jacobi_0.png')

u=np.zeros((N,N))
u=np.matrix(u)


#definition of Q= pressure gradient / viscosity == same on all region
def Q(j,k): #brez tistega h odspodi
    delta_p = 0.28
    delta_x = 1
    eta = 1
    return delta_p / (delta_x * eta)
#definition of jacobi convergence
def jacobi(j,k): #brez tistega h odspodi
    return U[j+1,k] + U[j-1,k] + U[j,k+1] + U[j,k-1]


S_last=np.matrix.sum(U)

S_new=S_last+50
iteracija=0

while np.abs(S_new-S_last) > 0.00001:

    S_last=S_new
    k = 0
    for i in range(1, int(N / 4)):
        for j in range(int(N / 4) - int(k), int(N / 4) + int(k) + 1):
            u[i, j] = (Q(i, j)*(h**2) + jacobi(i, j)) / 4
        k = k + 1

    k = 0
    for i in range(1, int(N / 2)):
        for j in range(int(3 * N / 4) - int(k), int(3 * N / 4) + int(k) + 1):
            u[i, j] = (Q(i, j)*(h**2) + jacobi(i, j)) / 4
        k = k + 1
        if k > N / 4 - 2:
            break

    for i in range(int(N / 4), int(3 * N / 4) + 1):
        for j in range(1, int(N / 4)):
            u[i, j] = (Q(i, j)*(h**2) + jacobi(i, j)) / 4

    for i in range(int(N / 4), int(3 * N / 4) + 1):
        for j in range(int(3 * N / 4) + 1, N - 1):
            u[i, j] = (Q(i, j)*(h**2) + jacobi(i, j)) / 4

    k = 0
    for i in range(int(N / 4), int(N / 2)):
        for j in range(int(N / 4) + k + 1, int(N / 2)):
            u[i, j] = (Q(i, j)*(h**2) + jacobi(i, j)) / 4
        k = k + 1
        if k > N / 4:
            break

    for i in range(int(N / 4) + 1, int(N / 2)):
        u[i, j] = (Q(i, j) * (h ** 2) + jacobi(i, j)) / 4

    k = 0
    for i in range(int(N / 4), int(N / 2)):
        for j in range(int(N / 2) + 1, int(3 * N / 4) - k):
            u[i, j] = (Q(i, j)*(h**2) + jacobi(i, j)) / 4
        k = k + 1
        if k > N / 4:
            break

    k = 0
    for i in range(int(3 * N / 4) + 1, int(N)):
        for j in range(k + 2, int(N / 4)):
            u[i, j] = (Q(i, j)*(h**2) + jacobi(i, j)) / 4
        k = k + 1
        if k > N / 4 - 1:
            break

    for i in range(int(3 * N / 4) + 1, int(N) - 1):
        for j in range(int(N / 4), int(3 * N / 4) + 1):
            u[i, j] = (Q(i, j)*(h**2) + jacobi(i, j)) / 4

    k = 0
    for i in range(int(3 * N / 4) + 1, int(N) - 1):
        for j in range(int(3 * N / 4) + 1, int(N) - k - 2):
            u[i, j] = (Q(i, j)*(h**2) + jacobi(i, j)) / 4
        k = k + 1
        if k > N / 4 - 2:
            break

    S_new = np.matrix.sum(u)
    U = u
    print(iteracija)
    iteracija = iteracija + 1

#print(U)

plt.figure(2)
plt.imshow(U,cmap='gray')
plt.colorbar()
plt.savefig('lik_jacobi_2.png')


Z=np.zeros((N,N))
for i in range(N):
    for j in range(N):
        Z[i][j]=u[i,j]
plt.figure(1)
plt.contourf(XX,YY,Z,levels=12)
plt.colorbar()
plt.axis('equal')
plt.savefig('lik_jacobi_1.png')


#calculation of volume flow
sum=0
for i in range(N):
    for j in range(N):
        sum=W[i,j]*U[i,j]+sum
sum=sum/(N**2)
print(sum)

fig = plt.figure(4)
ax = fig.gca(projection='3d')
surf = ax.plot_surface(XX, YY, Z, cmap=cm.coolwarm,
                       linewidth=1, antialiased=False,alpha=0.5)

# Customize the z axis.

ax.zaxis.set_major_locator(LinearLocator(10))

# Add a color bar which maps values to colors.
#fig.colorbar(surf, shrink=0.5, aspect=5)

ax.set_xlabel(r'$x$')
ax.set_ylabel(r'$y$')
fig.colorbar(surf, shrink=0.5, aspect=5)
ax.set_zlabel(r'$u_{z}$')
plt.show()