import numpy as np
import matplotlib.pyplot as plt


#2D simspon works only for odd numbers
N=101

W=np.zeros((N,N))
W=np.matrix(W)

#2D simspon matrix W
for i in range(N):
    for j in range(N):
        if i ==0:
            if j==0 or j==N-1:
                W[i,j]=1
            elif j%2==1:
                W[i,j]=4
            else:
                W[i,j]=2
        elif i <N-1:
            if i%2==1:
                if j == 0 or j == N - 1:
                    W[i, j] = 4
                elif j % 2 == 1:
                    W[i, j] = 16
                else:
                    W[i, j] = 8
            else:
                if j == 0 or j == N - 1:
                    W[i, j] = 2
                elif j % 2 == 1:
                    W[i, j] = 8
                else:
                    W[i, j] = 4
        else:
            if j==0 or j==N-1:
                W[i,j]=1
            elif j%2==1:
                W[i,j]=4
            else:
                W[i,j]=2

h=1/N
print(h)
U=np.zeros((N,N))
U=np.matrix(U)
#initial marix U with 0 at the edge and 1 inside
for i in range(1,N-1):
    for j in range(1,N-1):
        U[i,j]=1

u=np.zeros((N,N))
u=np.matrix(u)

X=np.arange(0+1/(2*N),1+1/(2*N),1/N)
Y=np.arange(0+1/(2*N),1+1/(2*N),1/N)

XX,YY=np.meshgrid(X,Y)

plt.figure(0)
plt.imshow(U,cmap='gray')
plt.colorbar()
plt.savefig('2d_simpson_0.png')

#definition of Q= pressure gradient / viscosity == same on all region
def Q(j,k): #brez tistega h odspodi
    delta_p = 0.28
    delta_x = 1
    eta = 1
    return delta_p / (delta_x * eta)
#definition of jacobi convergence
def jacobi(j,k): #brez tistega h odspodi
    return U[j+1,k] + U[j-1,k] + U[j,k+1] + U[j,k-1]

S_last=np.matrix.sum(U)

S_new=S_last+50
iteracija=0

while np.abs(S_new-S_last) > 0.0001:
    S_last=S_new
    for i in range(1,N-1):
        for j in range(1,N-1):
            u[i, j] = (Q(i, j)*(h**2) + jacobi(i, j)) / 4

    S_new = np.matrix.sum(u)
    U = u
    print(iteracija)
    iteracija = iteracija + 1


plt.figure(2)
plt.imshow(U,cmap='gray')
plt.colorbar()
plt.savefig('2d_simpson_2.png')

Z=np.zeros((N,N))
for i in range(N):
    for j in range(N):
        Z[i][j]=u[i,j]
plt.figure(1)
plt.contourf(XX,YY,Z,levels=10)
plt.colorbar()
plt.axis('equal')
plt.savefig('2d_simpson_1.png')

#calculation of volume flow
sum=0
for i in range(N):
    for j in range(N):
        sum=W[i,j]*U[i,j]+sum
sum=sum/(N**2)
print(sum)