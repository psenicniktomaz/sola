import numpy as np
import matplotlib.pyplot as plt

N=21 #zagotovo delujejo števila N deljiva s 4, ; k N prištejemo +1
h=1/N
print(h)
U=np.zeros((N,N))
U=np.matrix(U)
k=0

X=np.arange(0+1/(2*N),1+1/(2*N),1/N)
Y=np.arange(1+1/(2*N),0+1/(2*N),-1/N)

XX,YY=np.meshgrid(X,Y)

#za lik
plt.figure(1)
x=[X[0],X[int(N/4)],X[int(N/2)],X[int(3*N/4)],X[N-1],X[N-1],
   X[int(3*N/4)],X[int(N/4)],X[0],X[0]]
y=[Y[int(N/4)],Y[0],Y[int(N/4)],Y[0],Y[int(N/4)],Y[int(3*N/4)],
   Y[N-1],Y[N-1],Y[int(3*N/4)],Y[int(N/4)]]
plt.plot(x,y,'-',c='#1f77b4')
x=[X[int(N/4)],X[int(N/2)],X[int(3*N/4)],X[int(3*N/4)],
   X[int(N/4)],X[int(N/4)]]
y=[Y[int(N/4)],Y[int(N/2)],Y[int(N/4)],Y[int(3*N/4)],
   Y[int(3*N/4)],Y[int(N/4)]]
plt.plot(x,y,'-',c='#1f77b4')
plt.axis('equal')


k=0
for i in range(1,int(N/4)):
    for j in range(int(N / 4) - int(k), int(N / 4) + int(k)+1):
        U[i,j]=1
    k = k + 1

k=0
for i in range(1,int(N/2)):
    for j in range(int(3*N / 4) - int(k), int(3*N / 4) + int(k)+1):
        U[i, j] = 2
    k = k + 1
    if k > N / 4 - 2:
        break

for i in range(int(N/4),int(3*N/4)+1):
    for j in range(1,int(N/4)):
        U[i,j]=3

for i in range(int(N/4),int(3*N/4)+1):
    for j in range(int(3*N/4)+1,N-1):
        U[i, j] = 4

k=0
for i in range(int(N/4),int(N/2)):
    for j in range(int(N/4)+k+1,int(N/2)):
        U[i, j] = 5
    k=k+1
    if k > N/4:
        break

for i in range(int(N/4)+1,int(N/2)):
    U[i,int(N/2)]=6

k=0
for i in range(int(N/4),int(N/2)):
    for j in range(int(N/2)+1,int(3*N/4)-k):
        U[i, j] = 7
    k=k+1
    if k > N/4:
        break

k=0
for i in range(int(3*N/4)+1,int(N)):
    for j in range(k+2,int(N/4)):
        U[i, j] = 8
    k=k+1
    if k > N/4-1:
        break

for i in range(int(3*N/4)+1,int(N)-1):
    for j in range(int(N/4),int(3*N/4)+1):
        U[i,j]=9

k=0
for i in range(int(3*N/4)+1,int(N)-1):
    for j in range(int(3*N/4)+1,int(N)-k-2):
        U[i, j] = 10
    k=k+1
    if k > N/4-2:
        break

print(U)
plt.figure(0)
plt.imshow(U,cmap='gray')
plt.colorbar()
plt.show()