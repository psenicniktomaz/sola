import numpy as np
import matplotlib.pyplot as plt
from matplotlib import cm
from matplotlib.ticker import LinearLocator, FormatStrFormatter
import numpy as np
from mpl_toolkits.mplot3d import Axes3D

N=30
h=1/N
print(h)
U=np.zeros((N,N))
U=np.matrix(U)
for i in range(1,N-1):
    for j in range(1,N-1):
        U[i,j]=1

u=np.zeros((N,N))
u=np.matrix(u)

X=np.arange(0+1/(2*N),1+1/(2*N),1/N)
Y=np.arange(0+1/(2*N),1+1/(2*N),1/N)

XX,YY=np.meshgrid(X,Y)

print(X)
plt.figure(0)
plt.imshow(U,cmap='gray')
plt.colorbar()
plt.savefig('kvadrat_novo_jacobi_0.png')

#definirajmo koeficiente
a_0=-4/(h**2)
a_4=a_3=a_2=a_1=-1/(h**2)



'''def q(j,k):
    q_jk=a_1 * U[j + 1, k] + a_2 * U[j - 1, k] + a_3 * U[j, k - 1] + a_4 * U[j, k + 1] -a_0*U[j,k]
    return q_jk'''
def q(j,k):
    delta_p=0.28
    delta_x=1
    eta=1
    return delta_p /(delta_x *eta)


S_last=np.matrix.sum(U)

S_new=S_last+55
iteracija=0

while np.abs(S_new-S_last) > 0.001:
    S_last=S_new
    for i in range(1,N-1):
        for j in range(1,N-1):
            u[i,j]=(-1/a_0)*(q(j=i,k=j) - a_1* U[i+1,j] - a_2*U[i-1,j]
                             - a_3*U[i,j+1]-a_4*U[i,j-1])


    S_new = np.matrix.sum(u)
    U = u
    print(iteracija)
    iteracija = iteracija + 1

print(U)

plt.figure(2)
plt.imshow(U,cmap='gray')
plt.colorbar()
plt.savefig('kvadrat_novo_jacobi_2.png')

Z=np.zeros((N,N))
for i in range(N):
    for j in range(N):
        Z[i][j]=u[i,j]
plt.figure(1)
plt.contourf(XX,YY,Z,levels=10)
plt.colorbar()
plt.axis('equal')
plt.savefig('kvadrat_novo_jacobi_1.png')




fig = plt.figure(4)
ax = fig.gca(projection='3d')
surf = ax.plot_surface(XX, YY, Z, cmap=cm.coolwarm,
                       linewidth=1, antialiased=False,alpha=0.5)

# Customize the z axis.

ax.zaxis.set_major_locator(LinearLocator(10))
ax.zaxis.set_major_formatter(FormatStrFormatter('%.02f'))

# Add a color bar which maps values to colors.
#fig.colorbar(surf, shrink=0.5, aspect=5)

ax.set_xlabel(r'$x$')
ax.set_ylabel(r'$y$')
fig.colorbar(surf, shrink=0.5, aspect=5)
ax.set_zlabel(r'$u_{z}$')
plt.show()