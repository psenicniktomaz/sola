import numpy as np
import matplotlib.pyplot as plt

N=100
h=1/(int(N))
print(h)
U=np.zeros((2*N,2*N))
U=np.matrix(U)
for i in range(1,2*N-1):
    for j in range(1,2*N-1):
        U[i,j]=1


r=np.arange(-1 +h/2, 1 ,h)
z=np.arange(2-h/2,0,-h)

RR,ZZ=np.meshgrid(r,z)

r=np.arange(1- h/2,0,-h)
R=np.arange(0+h/2,1,h)
r=np.append(r,R)



for i in range(2*N):
    for j in range(2*N):
        if i==0:
            U[i,j]=2
        elif j==2*N-1 and i> int(N)-1:
            U[i,j]=2
        elif j==0 and i > int(N)-1:
            U[i,j]=2
#U[0,0]=U[0,2*N-1]=U[2*N-1,0]=U[2*N-1,2*N-1]=0



u=np.zeros((2*N,2*N))
u=np.matrix(u)



Uu=np.zeros((2*N,2*N))
Uu=np.matrix(Uu)
for i in range(1,2*N-1):
    for j in range(1,2*N-1):
        Uu[i,j]=1
for i in range(2*N):
    for j in range(2*N):
        if i==0:
            Uu[i,j]=2
        elif j==2*N-1 and i> int(N)-1:
            Uu[i,j]=2
        elif j==0 and i > int(N)-1:
            Uu[i,j]=2
#Uu[0,0]=Uu[0,2*N-1]=Uu[2*N-1,0]=Uu[2*N-1,2*N-1]=0




def jacobi_desno(j,k):
    return U[j+1,k] + U[j-1,k] + U[j,k+1] + U[j,k-1] +(h/(2*r[k]))*(U[j,k+1]-U[j,k-1])

def jacobi_levo(j,k):
    return U[j+1,k] + U[j-1,k] + U[j,k+1] + U[j,k-1] -(h/(2*r[k]))*(U[j,k+1]-U[j,k-1])

K_2=0.5
def jacobi_odvod_spodaj_desno(j,k):
    return 2*K_2*h + 2*U[j-1,k] + U[j,k+1] + U[j,k-1] +(h/(2*r[k]))*(U[j,k+1]-U[j,k-1])
def jacobi_odvod_spodaj_levo(j,k):
    return 2*K_2*h + 2*U[j-1,k] + U[j,k+1] + U[j,k-1] -(h/(2*r[k]))*(U[j,k+1]-U[j,k-1])

omega=1.4



S_last=np.matrix.sum(U)
S_new=S_last+50
iteracija=0

#while np.abs(S_new-S_last) > 0.00001:
for qw in range(1000):
    S_last=S_new
    for i in range(1,2*N-1):
        for j in range(1,N):
            u[i, j] =  ( jacobi_levo(i, j)) / 4
            Uu[i, j] = U[i, j] + omega * (u[i, j] - U[i, j])

    for i in range(1,2*N-1):
        for j in range(2*N-2,N-1,-1):
            u[i, j] =  ( jacobi_desno(i, j)) / 4
            Uu[i, j] = U[i, j] + omega * (u[i, j] - U[i, j])

    for j in range(1,N):
        u[int(2*N)-1, j] = ( jacobi_odvod_spodaj_levo(j=int((2*N))-1, k=j)) / 4
        Uu[int(2*N)-1, j] = U[int(2*N)-1, j] + omega * (u[int(2*N)-1, j] - U[int(2*N)-1, j])

    for j in range(2*N-2,N-1,-1):
        u[int(2*N)-1, j] = ( jacobi_odvod_spodaj_desno(j=int((2*N))-1, k=j)) / 4
        Uu[int(2*N)-1, j] = U[int(2*N)-1, j] + omega * (u[int(2*N)-1, j] - U[int(2*N)-1, j])
    iteracija=iteracija+1
    print(iteracija)
    U=Uu
print(Uu)



Z=np.zeros((2*N,2*N))
for i in range(2*N):
    for j in range(2*N):
        Z[i][j]=U[i,j]
plt.figure(1)
plt.contourf(RR,ZZ,Z,levels=15)
plt.colorbar()
plt.axis('equal')
plt.xlabel(r'$r$')
plt.ylabel(r'$z$')
plt.savefig('valj3.png')