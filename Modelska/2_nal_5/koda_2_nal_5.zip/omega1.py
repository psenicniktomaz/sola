import numpy as np
import matplotlib.pyplot as plt

#preberimo vsako vrstico posbej
file=open("lik_omega_iteracije.dat","r")
vrstice=[]
for line in file:
    fields = line.split("\t")
    vrstice.append(fields)
file.close()

#odstranimo prva dva elementa ker nista kul
vrstice.pop(0)
N=len(vrstice)

n=[]
omega=[]
for i in range(N-1):
    n.append(np.float(vrstice[i][0]))
    omega.append(np.float(vrstice[i][1]))
print(n)


plt.figure(0)
plt.plot(omega,n)
plt.legend(loc=0,frameon=False)
plt.grid()
plt.xlabel(r'$\omega$')
plt.ylabel('#iteracij')
plt.title(r' #iteracije($\omega$) za N=101')
plt.savefig('omega1.png')
