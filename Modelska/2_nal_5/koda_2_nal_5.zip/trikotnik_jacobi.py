import numpy as np
import matplotlib.pyplot as plt

N=201
h=1/N
print(h)
U=np.zeros((N,N))
U=np.matrix(U)
k=0

if N%2==1:
#works for odd numbers
    for i in range(1,N-1):
        for j in range(int(N/2)-int(k/2),int(N/2)+int(k/2+1)):
            U[i,j]=1
        k=k+1

#works for even numbers
else:
    for i in range(2,N-1):
        for j in range(int(N/2)-int(k/2)-1,int(N/2)+ int(k/2)+1):
            U[i,j]=1
        k=k+1


W=np.zeros((N,N))
W=np.matrix(W)
#2D simspon matrix W
for i in range(N):
    for j in range(N):
        if i ==0:
            if j==0 or j==N-1:
                W[i,j]=1
            elif j%2==1:
                W[i,j]=4
            else:
                W[i,j]=2
        elif i <N-1:
            if i%2==1:
                if j == 0 or j == N - 1:
                    W[i, j] = 4
                elif j % 2 == 1:
                    W[i, j] = 16
                else:
                    W[i, j] = 8
            else:
                if j == 0 or j == N - 1:
                    W[i, j] = 2
                elif j % 2 == 1:
                    W[i, j] = 8
                else:
                    W[i, j] = 4
        else:
            if j==0 or j==N-1:
                W[i,j]=1
            elif j%2==1:
                W[i,j]=4
            else:
                W[i,j]=2


plt.figure(0)
plt.imshow(U,cmap='gray')
plt.colorbar()
plt.savefig('trikotnik_jacobi_0.png')

X=np.arange(0+1/(2*N),1+1/(2*N),1/N)
Y=np.arange(1+1/(2*N),0+1/(2*N),-1/N)

XX,YY=np.meshgrid(X,Y)


#definition of Q= pressure gradient / viscosity == same on all region
def Q(j,k): #brez tistega h odspodi
    delta_p = 0.28
    delta_x = 1
    eta = 1
    return delta_p / (delta_x * eta)
#definition of jacobi convergence
def jacobi(j,k): #brez tistega h odspodi
    return U[j+1,k] + U[j-1,k] + U[j,k+1] + U[j,k-1]

u=np.zeros((N,N))
u=np.matrix(u)

#for the triangle
x=[X[0],(X[N-1]-X[0])/2,X[N-1],X[0]]
y=[Y[N-1],Y[0],Y[N-1],Y[N-1]]
plt.figure(1)
plt.plot(x,y,'-',c='#1f77b4')

S_last=np.matrix.sum(U)

S_new=S_last+50
iteracija=0
while np.abs(S_new-S_last) > 0.0001:
#for l in range(10000):
    S_last=S_new
    #print(u)
    k=0
    if N%2==1:
        for i in range(1, N - 1):
            for j in range(int(N / 2) - int(k / 2), int(N / 2) + int(k / 2 + 1)):
                u[i, j] = (Q(i, j) * (h ** 2) + jacobi(i, j)) / 4
            k = k + 1
        S_new = np.matrix.sum(u)
        U = u
        print(iteracija)
        iteracija = iteracija + 1

    else:
        for i in range(2, N - 1):
            for j in range(int(N/2)-int(k/2)-1,int(N/2)+ int(k/2)+1):
                u[i, j] = (Q(i, j) * (h ** 2) + jacobi(i, j)) / 4
                print(i,j)
            k=k+1

        S_new=np.matrix.sum(u)
        U=u
        print(iteracija)
        iteracija=iteracija +1
        #print(u)

plt.figure(2)
plt.imshow(U,cmap='gray')
plt.colorbar()
plt.savefig('trikotnik_jacobi_2.png')


Z=np.zeros((N,N))
for i in range(N):
    for j in range(N):
        Z[i][j]=u[i,j]
plt.figure(1)
plt.contourf(XX,YY,Z)
plt.colorbar()
plt.axis('equal')
plt.savefig('trikotnik_jacobi_1.png')

#calculation of volume flow
sum=0
for i in range(N):
    for j in range(N):
        sum=W[i,j]*U[i,j]+sum
sum=sum/(N**2)
print(sum)