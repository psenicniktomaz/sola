import matplotlib.pyplot as plt
import numpy as np
import scipy
from scipy import linalg as la
from PIL import Image


# funkcije/enacbe poimenovane kot v zvezku

# fi_1=fi_{i-1}^{n}
# fi_2=fi_{i}^{n}
# fi_3=fi_{i+1}^{n}
# fi_4=fi_{i}^{n-1}

# F_1=F_{i-1}^{n}
# F_2=F_{i}^{n}
# F_3=F_{i+1}^{n}

def ena(delta_t, delta_s, fi_1, fi_2, fi_3, fi_4, F_1, F_2, F_3):
    return 2 * fi_2 - fi_4 + delta_t * delta_t * ((F_3 - F_1) * (fi_3 - fi_1) / 2 + F_2 * (fi_3 - 2 * fi_2 + fi_1)) / (
        delta_s) ** 2


def dva(delta_t, delta_s, fi_1, fi_2, fi_3, fi_4, F_1, F_2):
    return F_2 * (2 + (fi_3 - fi_1) * (fi_3 - fi_1) / 4) - F_1 - delta_s * delta_s * (fi_2 - fi_4) * (fi_2 - fi_4) / (
        delta_t) ** 2


def tri(delta_s, fi_0, F_1):
    return F_1 + delta_s * np.sin(fi_0)


# privzel sem (ne tu ampak spodaj), da je sila od prejsnjega koraka
def pet_prava(delta_s, fi_1, fi_2, F_1):
    return fi_2 + 2 * delta_s * np.cos(fi_1) / F_1


def sest(fi_Nminus1, fi_Nminus2):
    return 2 * fi_Nminus1 - fi_Nminus2


# i=0, 1, 2, ... , N
# n=0, 1, 2, ...
# t_n=n*delta_t
# s_i=i*delta_s
# delta_s=1/N
# M naj bo stevilo casovnih tock
N = int(80)
M = 2000
delta_t = 0.01
delta_s = 1 / N

# zacetna vrednost kota
fi_0 = 1

# ---------------------------------------------------------------------
# matrika kotov
# vsebuje tudi n=-1
# torej ni velika (N+1)x(M+1), ampak (N+1)x(M+2)
MATfi = np.zeros((M + 2, N + 1))

# n=-1
MATfi[0] = fi_0 * np.ones(N + 1)
print('phi_0=\n', MATfi[0])
# n=0
MATfi[1] = fi_0 * np.ones(N + 1)

# matrika F-jev (sil)
# velika je (N+1)x(M+1) (od 0 do N oz. M)
MATsila = np.zeros((M + 1, N + 1))

for n in range(M):
    # prvi korak: obrniti tridiagonalno matriko A (N-1)x(N-1)
    A = np.diag(
        [-(2 + (MATfi[n + 1][i + 1] - MATfi[n + 1][i - 1]) * (MATfi[n + 1][i + 1] - MATfi[n + 1][i - 1]) / 4) for i in
         range(N - 1)]) + np.diag(np.ones(N - 2), k=-1) + np.diag(np.ones(N - 2), k=1)
    A[0][0] = -(1)  # +(MATfi[n+1][2]-MATfi[n+1][0])*(MATfi[n+1][2]-MATfi[n+1][0])/4)
    print('A=\n', A)
    # desna stran
    R = np.array(
        [-delta_s * delta_s * (MATfi[n + 1][i] - MATfi[n][i]) * (MATfi[n + 1][i] - MATfi[n][i]) / (delta_t) ** 2 for i
         in range(1, N)])
    R[0] = -delta_s * np.sin(MATfi[n + 1][0])
    print('R=\n', R)
    # resim sistem
    F = la.solve(A, R)
    print('F=\n', F)
    MATsila[n][1:N] = F

    # drugi korak: iz enacbe 3 dolocim F_0
    MATsila[n][0] = tri(delta_s, MATfi[n + 1][0], MATsila[n][1])

    # tretji korak: iz enacbe 1 dolocim fi kote pri naslednjem casu
    for i in range(1, N):
        MATfi[n + 1 + 1][i] = ena(delta_t, delta_s, MATfi[n + 1][i - 1], MATfi[n + 1][i], MATfi[n + 1][i + 1],
                                  MATfi[n - 1 + 1][i], MATsila[n][i - 1], MATsila[n][i], MATsila[n][i + 1])

    # cetrti korak: iz enacbe 6 dolocim kot na koncu
    MATfi[n + 1 + 1][N] = sest(MATfi[n + 1 + 1][N - 1], MATfi[n + 1 + 1][N - 2])

    # peti korak: iz enacbe 5 dolocim kot na zacetku
    MATfi[n + 1 + 1][0] = pet_prava(delta_s, MATfi[n + 1 + 1][1], MATfi[n + 1 + 1][2], MATsila[n][1])

# ponovim prva dva koraka, ker moram izracunati silo za zadnjo casovno tocko
n = M
# prvi korak: obrniti tridiagonalno matriko A (N-1)x(N-1)
A = np.diag(
    [-(2 + (MATfi[n + 1][i + 1] - MATfi[n + 1][i - 1]) * (MATfi[n + 1][i + 1] - MATfi[n + 1][i - 1]) / 4) for i in
     range(N - 1)]) + np.diag(np.ones(N - 2), k=-1) + np.diag(np.ones(N - 2), k=1)
A[0][0] = -(1)  # +(MATfi[n+1][2]-MATfi[n+1][0])*(MATfi[n+1][2]-MATfi[n+1][0])/4)
# desna stran
R = np.array([-delta_s * delta_s * (MATfi[n + 1][i] - MATfi[n - 1 + 1][i]) * (MATfi[n + 1][i] - MATfi[n - 1 + 1][i]) / (
    delta_t) ** 2 for i in range(1, N)])
R[0] = -delta_s * np.sin(MATfi[n + 1][0])
# resim sistem
F = la.solve(A, R)
MATsila[n][1:N] = F

# drugi korak: iz enacbe 3 dolocim F_0
MATsila[n][0] = tri(delta_s, MATfi[n + 1][0], MATsila[n][1])

# -----------------------------------------------------------
X=[]
Y=[]
t=[]

for n in range(M):
    print(n)
    x = [0]
    y = [0]
    for i in range(0, N, 1):
        x.append(x[i] + delta_s * np.cos(MATfi[n][i]))
        y.append(y[i] - delta_s * np.sin(MATfi[n][i]))
    X.append(x[N])
    Y.append(y[N])
    t.append(delta_t*n)

s=[]
for n in range(N):
    s.append(delta_s*n)
s.append(1)
t.append((M)*delta_t)


plt.figure(0)
plt.xlim(-0.6, 0.6)
plt.ylim(-1.1, 0.01)
plt.grid()
plt.plot(X, Y, 'o', markersize=1, alpha=0.7)
plt.savefig('vrv80_3.pdf')


S,T=np.meshgrid(s,t)

plt.figure(1)
plt.contourf(S,T,MATsila,levels=20)
plt.colorbar()
plt.xlabel('s')
plt.ylabel('t')
plt.savefig('vrv80_3_sila.pdf')