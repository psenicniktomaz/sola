import numpy as np
import matplotlib.pyplot as plt


N=6
delta_t=1
phi_0=0
h=1/(N-1)
delta_s=h
s_0=np.arange(0,-1-h/2,-h)

x_0=np.sin(phi_0)*s_0
y_0=np.cos(phi_0)*s_0
#print(x_0,y_0)



##### starting position
'''plt.figure(0)
plt.plot(x_0,y_0,'o',markersize=1)
plt.axis('equal')
plt.show()'''


phi_0=np.zeros(N-1)
for i in range(1,N,1):

    if y_0[i-1] > y_0[i] and x_0[i-1] > x_0[i]:
        phi_0[i-1]=np.arcsin(np.abs(x_0[i-1]-x_0[i])/delta_s)

    elif y_0[i-1] < y_0[i] and x_0[i-1] > x_0[i]:
        phi_0[i-1]=np.pi - np.arcsin(np.abs(x_0[i-1]-x_0[i])/delta_s)

    elif y_0[i - 1] > y_0[i] and x_0[i - 1] < x_0[i]:
        phi_0[i-1]=-np.arcsin(np.abs(x_0[i-1]-x_0[i])/delta_s)

    elif y_0[i - 1] < y_0[i] and x_0[i - 1] < x_0[i]:
        phi_0[i-1]=np.arcsin(np.abs(x_0[i-1]-x_0[i])/delta_s) -np.pi

print(phi_0)

#### first calculation of force in links
'''calculating A.F=b ; F is force vector'''
A=np.zeros((N-1,N-1))
A[0][0]=1
for i in range(1,N-2,1):
    A[i][i]=2 + ((phi_0[i+1] - phi_0[i-1])/(2*delta_s))**2
A[N-2][N-2]=2 +((-phi_0[N-2])/(2*delta_s))**2
for i in range(N-2):
    A[i][i+1]=-1
    A[i+1][i]=-1



b=np.zeros(N-1)
b[0]=delta_s * np.cos(phi_0[0])

F=np.linalg.solve(A,b)

print(A)
print(b)
print(F)