import numpy as np
import matplotlib.pyplot as plt


N=6
delta_t=0.1
phi_0=1.5
h=1/(N-1)
delta_s=h
s_0=np.arange(0,1+h/2,h)

x_0=np.cos(phi_0)*s_0
y_0=np.sin(phi_0)*s_0
#print(x_0,y_0)



##### starting position
'''plt.figure(0)
plt.plot(x_0,y_0,'o',markersize=1)
plt.axis('equal')
plt.show()'''


phi_0=np.zeros(N-1)
for i in range(1,N,1):

    if y_0[i-1] < y_0[i] and x_0[i-1] < x_0[i]:
        phi_0[i-1]=np.arccos(np.abs(x_0[i-1]-x_0[i])/delta_s)

    elif y_0[i-1] < y_0[i] and x_0[i-1] > x_0[i]:
        phi_0[i-1]=np.pi - np.arccos(np.abs(x_0[i-1]-x_0[i])/delta_s)

    elif y_0[i - 1] > y_0[i] and x_0[i - 1] < x_0[i]:
        phi_0[i-1]=-np.arccos(np.abs(x_0[i-1]-x_0[i])/delta_s)

    elif y_0[i - 1] > y_0[i] and x_0[i - 1] > x_0[i]:
        phi_0[i-1]=np.arccos(np.abs(x_0[i-1]-x_0[i])/delta_s) -np.pi

print(phi_0)

#### first calculation of force in links
'''calculating A.F=b ; F is force vector'''
A=np.zeros((N-1,N-1))
A[0][0]=1
for i in range(1,N-1,1):
    A[i][i]=2 + ((phi_0[i] - phi_0[i-1])/(2*delta_s))**2
for i in range(N-2):
    A[i][i+1]=-1
    A[i+1][i]=-1

b=np.zeros(N-1)
b[0]=delta_s * np.sin(phi_0[0])

F=np.linalg.solve(A,b)

print(A)
print(b)
print(F)

###### calculating new angles
phi_1=np.zeros(N-1)
for i in range(1,N-2,1):
    phi_1[i]=((F[i+1] -F[i-1])*(phi_0[i+1] - phi_0[i-1])/(2*delta_s**2)
              + F[i]*(phi_0[i+1] -2*phi_0[i] + phi_0[i-1])/(delta_s**2))*(delta_t**2) + phi_0[i]

phi_1[N-2]= 2*phi_1[N-3] - phi_1[N-4]
phi_1[0]=phi_1[2] -2*delta_s *np.cos(phi_1[1])/F[0] # dunno if F[0] or F[1]

print(phi_1)

### calculating the next force vector
for i in range(1,N-1,1):
    A[i][i]=2 + ((phi_1[i] - phi_1[i-1])/(2*delta_s))**2
print(A)

b[0]=b[0]=delta_s * np.sin(phi_1[0])
for i in range(1,N-1):
    b[i]=((phi_1[i]-phi_0[i])/delta_t)**2

print(b)
F=np.linalg.solve(A,b)
print(F)


##### calculating next angles, force and loop
for j in range(20):
    phi_2=np.zeros(N-1)
    for i in range(1,N-2,1):
        phi_2[i]=((F[i+1] -F[i-1])*(phi_1[i+1] - phi_1[i-1])/(2*delta_s**2)
                  + F[i]*(phi_1[i+1] -2*phi_1[i] + phi_1[i-1])/(delta_s**2))*(delta_t**2) + 2*phi_1[i] - phi_0[i]
    phi_2[N-2]= 2*phi_2[N-3] - phi_2[N-4]
    phi_2[0]=phi_2[2] -2*delta_s *np.cos(phi_2[1])/F[0] # dunno if F[0] or F[1]
    #print('phi=\t',phi_2)

    for i in range(1,N-1,1):
        A[i][i]=2 + ((phi_2[i] - phi_2[i-1])/(2*delta_s))**2
    #print('A=\t',A)

    b[0]=b[0]=delta_s * np.sin(phi_2[0])
    for i in range(1,N-1):
        b[i]=((phi_2[i]-phi_1[i])/delta_t)**2

    #print('b=\t',b)
    F=np.linalg.solve(A,b)
    #print('F=\t',F)

    phi_0=phi_1
    phi_1=phi_2