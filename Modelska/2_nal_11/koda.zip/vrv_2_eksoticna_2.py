import matplotlib.pyplot as plt
import numpy as np
import scipy
from scipy import linalg as la
from PIL import Image


# funkcije/enacbe poimenovane kot v zvezku

# fi_1=fi_{i-1}^{n}
# fi_2=fi_{i}^{n}
# fi_3=fi_{i+1}^{n}
# fi_4=fi_{i}^{n-1}

# F_1=F_{i-1}^{n}
# F_2=F_{i}^{n}
# F_3=F_{i+1}^{n}

def ena(delta_t, delta_s, fi_1, fi_2, fi_3, fi_4, F_1, F_2, F_3):
    return 2 * fi_2 - fi_4 + delta_t * delta_t * ((F_3 - F_1) * (fi_3 - fi_1) / 2 + F_2 * (fi_3 - 2 * fi_2 + fi_1)) / (
        delta_s) ** 2


def dva(delta_t, delta_s, fi_1, fi_2, fi_3, fi_4, F_1, F_2):
    return F_2 * (2 + (fi_3 - fi_1) * (fi_3 - fi_1) / 4) - F_1 - delta_s * delta_s * (fi_2 - fi_4) * (fi_2 - fi_4) / (
        delta_t) ** 2


def tri(delta_s, fi_0, F_1):
    return F_1 + delta_s * np.sin(fi_0)


# privzel sem (ne tu ampak spodaj), da je sila od prejsnjega koraka
def pet_prava(delta_s, fi_1, fi_2, F_1):
    return fi_2 + 2 * delta_s * np.cos(fi_1) / F_1


def sest(fi_Nminus1, fi_Nminus2):
    return 2 * fi_Nminus1 - fi_Nminus2


# i=0, 1, 2, ... , N
# n=0, 1, 2, ...
# t_n=n*delta_t
# s_i=i*delta_s
# delta_s=1/N
# M naj bo stevilo casovnih tock
N = int(40)
M = 3000
delta_t = 0.002
delta_s = 1 / N

# zacetna vrednost kota
fi_0 = 0.5

# ---------------------------------------------------------------------
# matrika kotov
# vsebuje tudi n=-1
# torej ni velika (N+1)x(M+1), ampak (N+1)x(M+2)
MATfi = np.zeros((M + 2, N + 1))

# n=-1
MATfi[0] = fi_0 * np.ones(N + 1)
print('phi_0=\n', MATfi[0])
# n=0
MATfi[1] = fi_0 * np.ones(N + 1)

# matrika F-jev (sil)
# velika je (N+1)x(M+1) (od 0 do N oz. M)
MATsila = np.zeros((M + 1, N + 1))

for n in range(M):
    # prvi korak: obrniti tridiagonalno matriko A (N-1)x(N-1)
    A = np.diag(
        [-(2 + (MATfi[n + 1][i + 1] - MATfi[n + 1][i - 1]) * (MATfi[n + 1][i + 1] - MATfi[n + 1][i - 1]) / 4) for i in
         range(N - 1)]) + np.diag(np.ones(N - 2), k=-1) + np.diag(np.ones(N - 2), k=1)
    A[0][0] = -(1)  # +(MATfi[n+1][2]-MATfi[n+1][0])*(MATfi[n+1][2]-MATfi[n+1][0])/4)
    print('A=\n', A)
    # desna stran
    R = np.array(
        [-delta_s * delta_s * (MATfi[n + 1][i] - MATfi[n][i]) * (MATfi[n + 1][i] - MATfi[n][i]) / (delta_t) ** 2 for i
         in range(1, N)])
    R[0] = -delta_s * np.sin(MATfi[n + 1][0])
    print('R=\n', R)
    # resim sistem
    F = la.solve(A, R)
    print('F=\n', F)
    MATsila[n][1:N] = F

    # drugi korak: iz enacbe 3 dolocim F_0
    MATsila[n][0] = tri(delta_s, MATfi[n + 1][0], MATsila[n][1])

    # tretji korak: iz enacbe 1 dolocim fi kote pri naslednjem casu
    for i in range(1, N):
        MATfi[n + 1 + 1][i] = ena(delta_t, delta_s, MATfi[n + 1][i - 1], MATfi[n + 1][i], MATfi[n + 1][i + 1],
                                  MATfi[n - 1 + 1][i], MATsila[n][i - 1], MATsila[n][i], MATsila[n][i + 1])

    # cetrti korak: iz enacbe 6 dolocim kot na koncu
    MATfi[n + 1 + 1][N] = sest(MATfi[n + 1 + 1][N - 1], MATfi[n + 1 + 1][N - 2])

    # peti korak: iz enacbe 5 dolocim kot na zacetku
    MATfi[n + 1 + 1][0] = pet_prava(delta_s, MATfi[n + 1 + 1][1], MATfi[n + 1 + 1][2], MATsila[n][1])

# ponovim prva dva koraka, ker moram izracunati silo za zadnjo casovno tocko
n = M
# prvi korak: obrniti tridiagonalno matriko A (N-1)x(N-1)
A = np.diag(
    [-(2 + (MATfi[n + 1][i + 1] - MATfi[n + 1][i - 1]) * (MATfi[n + 1][i + 1] - MATfi[n + 1][i - 1]) / 4) for i in
     range(N - 1)]) + np.diag(np.ones(N - 2), k=-1) + np.diag(np.ones(N - 2), k=1)
A[0][0] = -(1)  # +(MATfi[n+1][2]-MATfi[n+1][0])*(MATfi[n+1][2]-MATfi[n+1][0])/4)
# desna stran
R = np.array([-delta_s * delta_s * (MATfi[n + 1][i] - MATfi[n - 1 + 1][i]) * (MATfi[n + 1][i] - MATfi[n - 1 + 1][i]) / (
    delta_t) ** 2 for i in range(1, N)])
R[0] = -delta_s * np.sin(MATfi[n + 1][0])
# resim sistem
F = la.solve(A, R)
MATsila[n][1:N] = F

# drugi korak: iz enacbe 3 dolocim F_0
MATsila[n][0] = tri(delta_s, MATfi[n + 1][0], MATsila[n][1])

# -----------------------------------------------------------
for n in range(int(2*(M+2)/3)):
    if n % 143 == 0:
        print(n)
        x = [0]
        y = [0]
        for i in range(0, N, 1):
            x.append(x[i] + delta_s * np.cos(MATfi[n][i]))
            y.append(y[i] - delta_s * np.sin(MATfi[n][i]))
        plt.figure(0)
        plt.xlim(-1.1, 1.1)
        plt.ylim(-1.1, 0.01)
        plt.grid()
        plt.plot(x, y, 'o-', markersize=1, alpha=0.7)
    else:
        continue

plt.figure(0)
plt.savefig('vrv_2_eksoticna_1.pdf')

X=[]
Y=[]
for n in range(M+2):
    print(n)
    x = [0]
    y = [0]
    for i in range(0, N, 1):
        x.append(x[i] + delta_s * np.cos(MATfi[n][i]))
        y.append(y[i] - delta_s * np.sin(MATfi[n][i]))
    X.append(x[N])
    Y.append(y[N])

plt.figure(1)
plt.xlim(-1.1, 1.1)
plt.ylim(-1.1, 0.01)
plt.grid()
plt.plot(X, Y, 'o', markersize=1, alpha=0.7)
plt.savefig('vrv_2_eksoticna_2.pdf')



k=[]
tezisca_x=np.zeros((M+2,N))
tezisca_y=np.zeros((M+2,N))
pot=[]
v=[0]
for n in range(M+2):
    print(n)
    k.append(n*delta_t)
    x = [0]
    y = [0]
    x_t=[]
    y_t=[]
    for i in range(0, N, 1):
        x.append(x[i] + delta_s * np.cos(MATfi[n][i]))
        y.append(y[i] - delta_s * np.sin(MATfi[n][i]))
        x_t.append((x[i]+x[i+1])/2)
        y_t.append((y[i]+y[i+1])/2)
    ####potential energy
    tezisca_y[n]=y_t
    tezisca_x[n]=x_t
    pot.append(sum(tezisca_y[n]*delta_s)+0.5)# +0.5 inside, just our potential energy definition)

v_x=np.zeros((M+1,N))
v_y=np.zeros((M+1,N))
v=[0]
E_rot=[0]

t=[]
for n in range(M+1):
    ##### kinetic energy
    v_x[n]=((tezisca_x[n+1]-tezisca_x[n])/delta_t)**2
    v_y[n]=((tezisca_y[n+1]-tezisca_y[n])/delta_t)**2
    v.append(sum(delta_s*(v_x[n] +v_y[n])/2))
    ##### rotational energy
    dphi_dt=(MATfi[n+1]-MATfi[n])/delta_t
    E_rot.append(sum((delta_s**3)*(dphi_dt**2)/24))
    t.append(delta_t*n)

v[2]=v[1]/2 +v[3]/2 # manual correction
E_rot[2]=(E_rot[1] + E_rot[3])/2
E_rot[0]=0
v[0]=0


plt.figure(2)
plt.grid()
plt.plot(k, pot, 'o-', markersize=1, alpha=0.7,label=r'$E_{pot}$')
plt.plot(k, v, 'o-', markersize=1, alpha=0.7,label=r'$E_{kin}$')
plt.plot(k, E_rot, 'o-', markersize=1, alpha=0.7,label=r'$E_{rot}$')
plt.xlabel('t')
plt.ylabel('E')
plt.plot(k,np.array(pot)+np.array(v) +np.array(E_rot),'o-', markersize=1, alpha=0.7,label=r'$E_{all}$')
plt.legend(loc=0,frameon=False)
plt.savefig('vrv_2_eksoticna_3.pdf')

plt.figure(3)
plt.grid()
plt.plot(k, E_rot, 'o-', markersize=1, alpha=0.7,label=r'$E_{rot}$')
plt.xlabel('t')
plt.ylabel('E')
plt.legend(loc=0,frameon=False)
plt.savefig('vrv_2_eksoticna_4.pdf')

s=[]
for n in range(N+1):
    s.append(delta_s*n)

S,T=np.meshgrid(s,t)

plt.figure(4)
plt.contourf(S,T,MATsila,levels=30)
plt.colorbar()
plt.xlabel('s')
plt.ylabel('t')
plt.savefig('vrv_2_eksoticna_sila.pdf')